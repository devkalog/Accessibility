<?php
/**
 * Admin: settings page with compliance suggestions, page scanner, import/export.
 *
 * @package Aboutnet_A11y
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', 'abt_a11y_admin_menu' );
function abt_a11y_admin_menu() {
	add_menu_page( 'Προσβασιμότητα', 'Προσβασιμότητα', 'manage_options', 'abt-a11y', 'abt_a11y_render_settings', 'dashicons-universal-access-alt', 81 );
	add_submenu_page( 'abt-a11y', 'Ρυθμίσεις προσβασιμότητας', 'Ρυθμίσεις', 'manage_options', 'abt-a11y', 'abt_a11y_render_settings' );
	add_submenu_page( 'abt-a11y', 'Έλεγχος σελίδων', 'Έλεγχος σελίδων', 'manage_options', 'abt-a11y-scan', 'abt_a11y_render_scanner' );
}

/**
 * Readable label for a stored backing value: "#1a1a1a@0.4/8" becomes
 * "#1a1a1a · 40% · <glass> 8px" (in the admin's language).
 *
 * @param string $value Stored backing value.
 * @return string
 */
function abt_a11y_plate_label( $value ) {
	if ( ! preg_match( '/^(#[0-9a-f]{6})@([\d.]+)(?:\/(\d+))?$/i', $value, $m ) ) {
		return $value;
	}
	return $m[1] . ' · ' . round( (float) $m[2] * 100 ) . '%' . ( ! empty( $m[3] ) ? ' · γυαλί ' . (int) $m[3] . 'px' : '' );
}

add_action( 'admin_init', 'abt_a11y_register_setting' );
function abt_a11y_register_setting() {
	register_setting(
		'abt_a11y',
		ABT_A11Y_OPTION,
		array(
			'type'              => 'array',
			'sanitize_callback' => 'abt_a11y_sanitize_option',
			'default'           => abt_a11y_defaults(),
		)
	);
}

add_filter( 'plugin_action_links_' . plugin_basename( ABT_A11Y_FILE ), 'abt_a11y_action_links' );
function abt_a11y_action_links( $links ) {
	array_unshift(
		$links,
		'<a href="' . esc_url( admin_url( 'admin.php?page=abt-a11y' ) ) . '">Ρυθμίσεις</a>',
		'<a href="' . esc_url( admin_url( 'admin.php?page=abt-a11y-scan' ) ) . '">Έλεγχος</a>'
	);
	return $links;
}

add_action( 'admin_enqueue_scripts', 'abt_a11y_admin_assets' );
function abt_a11y_admin_assets( $hook ) {
	if ( false === strpos( (string) $hook, 'abt-a11y' ) ) {
		return;
	}
	wp_enqueue_style( 'abt-a11y-admin', ABT_A11Y_URL . 'assets/admin.css', array(), ABT_A11Y_VERSION );
	$deps = array();
	if ( false !== strpos( (string) $hook, 'abt-a11y-scan' ) ) {
		wp_enqueue_script( 'abt-a11y-checker', ABT_A11Y_URL . 'assets/checker.js', array(), ABT_A11Y_VERSION, true );
		$deps[] = 'abt-a11y-checker';
	}
	wp_enqueue_script( 'abt-a11y-admin', ABT_A11Y_URL . 'assets/admin.js', $deps, ABT_A11Y_VERSION, true );
	wp_localize_script(
		'abt-a11y-admin',
		'abtA11yAdmin',
		array(
			'ajax'     => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'abt_a11y_admin' ),
			'settings' => abt_a11y_get_settings(),
			'defaults' => abt_a11y_defaults(),
			'home'     => home_url( '/' ),
			'settingsUrl' => admin_url( 'admin.php?page=abt-a11y' ),
		)
	);
}

/* -------------------------------------------------------------------------
 * Field helpers. Every row carries the data the compliance check in admin.js
 * needs: data-rule, data-rec (recommended value) and the WCAG reference.
 * ---------------------------------------------------------------------- */

function abt_a11y_name( $path ) {
	$parts = explode( '.', $path );
	$name  = ABT_A11Y_OPTION;
	foreach ( $parts as $p ) {
		$name .= '[' . $p . ']';
	}
	return $name;
}

/**
 * @param array $args {key, label, help, wcag, rule, rec, control(html)}
 */
function abt_a11y_row( $args ) {
	$args = wp_parse_args(
		$args,
		array(
			'key'     => '',
			'label'   => '',
			'help'    => '',
			'wcag'    => '',
			'rule'    => '',
			'rec'     => null,
			'extra'   => array(),
			'control' => '',
		)
	);
	$attrs = ' data-key="' . esc_attr( $args['key'] ) . '" data-rule="' . esc_attr( $args['rule'] ) . '"';
	if ( null !== $args['rec'] ) {
		$attrs .= " data-rec='" . esc_attr( wp_json_encode( $args['rec'] ) ) . "'";
	}
	foreach ( $args['extra'] as $k => $v ) {
		$attrs .= ' data-' . esc_attr( $k ) . "='" . esc_attr( is_string( $v ) ? $v : wp_json_encode( $v ) ) . "'";
	}
	echo '<div class="abt-row"' . $attrs . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- attributes escaped above.
	$field_id = abt_a11y_field_id( $args['key'] );
	if ( false !== strpos( $args['control'], 'id="' . $field_id . '"' ) ) {
		echo '<div class="abt-row-head"><label class="abt-row-label" for="' . esc_attr( $field_id ) . '">' . esc_html( $args['label'] ) . '</label>';
	} else {
		echo '<div class="abt-row-head"><span class="abt-row-label">' . esc_html( $args['label'] ) . '</span>';
	}
	if ( $args['wcag'] ) {
		echo ' <span class="abt-wcag">WCAG ' . esc_html( $args['wcag'] ) . '</span>';
	}
	echo '<span class="abt-badge"></span></div>';
	echo '<div class="abt-row-control">' . $args['control'] . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts.
	if ( $args['help'] ) {
		echo '<p class="abt-help">' . wp_kses( $args['help'], array( 'code' => array(), 'strong' => array(), 'br' => array() ) ) . '</p>';
	}
	echo '<p class="abt-suggest" hidden><span class="abt-suggest-text"></span> <button type="button" class="button button-small abt-apply">Εφαρμογή πρότασης</button></p>';
	echo '</div>';
}

/**
 * Permanent mode: how many colour fixes the page checker has stored.
 */
function abt_a11y_baked_status() {
	$counts = abt_a11y_baked_counts();
	$pages  = $counts['pages'];
	$site   = $counts['site'];
	echo '<div class="abt-row abt-baked-status"><div class="abt-row-head"><span class="abt-row-label">Αποθηκευμένα χρώματα (μόνιμη λειτουργία)</span></div><p class="abt-help">';
	if ( $pages || $site ) {
		echo esc_html( sprintf( 'Διορθώσεις χρωμάτων για %d σελίδες και %d για όλο το site (header, footer).', $pages, $site ) );
	} else {
		echo 'Δεν έχουν αποθηκευτεί ακόμη. Ο Έλεγχος σελίδων τα αποθηκεύει όταν το plugin είναι σε μόνιμη λειτουργία.';
	}
	echo '</p><p><a class="button" href="' . esc_url( admin_url( 'admin.php?page=abt-a11y-scan' ) ) . '">Έλεγχος σελίδων</a> ';
	if ( $pages || $site ) {
		echo '<a class="button-link abt-baked-clear" href="' . esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=abt_a11y_baked_clear' ), 'abt_a11y_baked_clear' ) ) . '" onclick="return confirm(\'Διαγραφή των αποθηκευμένων χρωμάτων;\');">Διαγραφή αποθηκευμένων χρωμάτων</a>';
	}
	echo '</p></div>';
}

function abt_a11y_checkbox( $path, $checked, $text ) {
	return '<label><input type="hidden" name="' . esc_attr( abt_a11y_name( $path ) ) . '" value="0"><input type="checkbox" name="' . esc_attr( abt_a11y_name( $path ) ) . '" value="1" ' . checked( $checked, true, false ) . '> ' . esc_html( $text ) . '</label>';
}

/**
 * Stable id for a setting's control, so the row title can be its <label>.
 *
 * @param string $path Dotted setting path.
 * @return string
 */
function abt_a11y_field_id( $path ) {
	return 'abt-f-' . preg_replace( '/[^a-z0-9_-]/i', '-', (string) $path );
}

function abt_a11y_select( $path, $value, $options ) {
	$html = '<select id="' . esc_attr( abt_a11y_field_id( $path ) ) . '" name="' . esc_attr( abt_a11y_name( $path ) ) . '">';
	foreach ( $options as $k => $label ) {
		$html .= '<option value="' . esc_attr( $k ) . '" ' . selected( $value, $k, false ) . '>' . esc_html( $label ) . '</option>';
	}
	return $html . '</select>';
}

function abt_a11y_color( $path, $value ) {
	$name = abt_a11y_name( $path );
	return '<span class="abt-color"><input type="color" value="' . esc_attr( $value ) . '" aria-label="Επιλογή χρώματος" class="abt-color-picker"> <input type="text" class="abt-color-text" id="' . esc_attr( abt_a11y_field_id( $path ) ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" size="8" pattern="#?[0-9a-fA-F]{3}([0-9a-fA-F]{3})?" aria-label="Κωδικός χρώματος"></span>';
}

function abt_a11y_number( $path, $value, $min, $max, $step, $suffix = '' ) {
	return '<input type="number" id="' . esc_attr( abt_a11y_field_id( $path ) ) . '" name="' . esc_attr( abt_a11y_name( $path ) ) . '" value="' . esc_attr( $value ) . '" min="' . esc_attr( $min ) . '" max="' . esc_attr( $max ) . '" step="' . esc_attr( $step ) . '" class="small-text"> ' . esc_html( $suffix );
}

function abt_a11y_textarea( $path, $lines, $placeholder ) {
	return '<textarea id="' . esc_attr( abt_a11y_field_id( $path ) ) . '" name="' . esc_attr( abt_a11y_name( $path ) ) . '" rows="4" class="large-text code" placeholder="' . esc_attr( $placeholder ) . '">' . esc_textarea( implode( "\n", (array) $lines ) ) . '</textarea>';
}

/* -------------------------------------------------------------------------
 * Settings page
 * ---------------------------------------------------------------------- */

function abt_a11y_render_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s       = abt_a11y_get_settings();
	$d       = abt_a11y_defaults();
	$modules = abt_a11y_modules();
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$notice = isset( $_GET['abt-notice'] ) ? sanitize_key( $_GET['abt-notice'] ) : '';
	?>
	<div class="wrap abt-wrap">
		<h1>Aboutnet Accessibility <span class="abt-sub">Προσβασιμότητα · WCAG 2.1 επίπεδο AA</span></h1>
		<?php if ( 'imported' === $notice ) : ?>
			<div class="notice notice-success is-dismissible"><p>Οι ρυθμίσεις εισήχθησαν.</p></div>
		<?php elseif ( 'import-error' === $notice ) : ?>
			<div class="notice notice-error is-dismissible"><p>Το αρχείο ρυθμίσεων δεν ήταν έγκυρο JSON.</p></div>
		<?php elseif ( 'reset' === $notice ) : ?>
			<div class="notice notice-success is-dismissible"><p>Οι ρυθμίσεις επανήλθαν στις προτεινόμενες.</p></div>
		<?php elseif ( 'baked-cleared' === $notice ) : ?>
			<div class="notice notice-success is-dismissible"><p>Τα αποθηκευμένα χρώματα διαγράφηκαν.</p></div>
		<?php endif; ?>
		<?php settings_errors(); ?>
		<?php abt_a11y_conflict_notice(); ?>

		<div class="abt-summary">
			<div class="abt-summary-text" role="status" aria-live="polite"><strong class="abt-summary-count">…</strong> <span class="abt-summary-label">ρυθμίσεις σε συμμόρφωση</span></div>
			<div class="abt-summary-actions">
				<button type="button" class="button button-primary abt-apply-all">Εφαρμογή όλων των προτάσεων</button>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=abt-a11y-scan' ) ); ?>">Έλεγχος σελίδων</a>
			</div>
			<p class="abt-summary-note">Οι προτάσεις εφαρμόζονται στη φόρμα· πατήστε «Αποθήκευση» για να ισχύσουν.</p>
			<p class="abt-summary-note">Για να δείτε τι αλλάζει σε μια σελίδα: ανοίξτε τη στο site ως διαχειριστής και πατήστε <strong>Προσβασιμότητα</strong> στη μαύρη μπάρα. Ο αριθμός δίπλα δείχνει πόσες αλλαγές έγιναν.</p>
		</div>

		<nav class="abt-tabs" aria-label="Ενότητες ρυθμίσεων">
			<a href="#abt-general">Γενικά</a>
			<a href="#abt-modules">Διορθώσεις</a>
			<a href="#abt-contrast">Αντίθεση</a>
			<a href="#abt-links">Σύνδεσμοι</a>
			<a href="#abt-page-changes">Αλλαγές από τη σελίδα</a>
			<a href="#abt-strings">Κείμενα</a>
			<a href="#abt-controls">Slider &amp; focus</a>
			<a href="#abt-exclusions">Εξαιρέσεις</a>
			<a href="#abt-tools">Εργαλεία</a>
		</nav>

		<form method="post" action="options.php" class="abt-form" novalidate>
			<?php settings_fields( 'abt_a11y' ); ?>

			<section id="abt-general" class="abt-section">
				<h2>Γενικά</h2>
				<?php
				abt_a11y_row(
					array(
						'key'     => 'enabled',
						'label'   => 'Ενεργοποίηση διορθώσεων',
						'help'    => 'Όταν είναι ανενεργό, το plugin δεν αλλάζει τίποτα στο site. Ο έλεγχος σελίδων λειτουργεί κανονικά.',
						'rule'    => 'bool',
						'rec'     => true,
						'control' => abt_a11y_checkbox( 'enabled', $s['enabled'], 'Ενεργό' ),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'mode',
						'label'   => 'Τρόπος λειτουργίας',
						'help'    => '<strong>Γρήγορη:</strong> οι διορθώσεις γίνονται με JavaScript στον browser του επισκέπτη. Δουλεύει αμέσως, αλλά αν το script δεν τρέξει (π.χ. το καθυστερεί ένα plugin βελτιστοποίησης), οι διορθώσεις δεν υπάρχουν.<br>'
							. '<strong>Μόνιμη:</strong> οι διορθώσεις γράφονται στο HTML από τον server, πριν σταλεί η σελίδα, οπότε υπάρχουν και χωρίς JavaScript και τις βλέπει κάθε εργαλείο ελέγχου. Τα χρώματα (αντίθεση) χρειάζονται τη σελίδα «ζωγραφισμένη»: τα μετρά ο <strong>Έλεγχος σελίδων</strong> και τα αποθηκεύει ως CSS. Τρέξτε τον μετά την αλλαγή σε μόνιμη λειτουργία και όποτε αλλάζει το design.',
						'rule'    => 'enum',
						'rec'     => $s['mode'], // Both are compliant: the choice is the site owner's, never a suggestion.
						'extra'   => array( 'ok' => array( 'fast', 'static' ) ),
						'control' => abt_a11y_select(
							'mode',
							$s['mode'],
							array(
								'fast'   => 'Γρήγορη (JavaScript)',
								'static' => 'Μόνιμη (από τον server)',
							)
						),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'safety_net',
						'label'   => 'Δίχτυ ασφαλείας (μόνιμη λειτουργία)',
						'help'    => 'Ένα script που φορτώνει χωρίς να καθυστερεί τη σελίδα: τρέχει μετά τη φόρτωση, όταν ο browser είναι ελεύθερος, και επιτρέπει στα plugins βελτιστοποίησης να το καθυστερήσουν. Διορθώνει ό,τι προσθέτουν αργότερα άλλα scripts (popups, φίλτρα, sliders), τα χρώματα σε σελίδες που δεν έχουν περάσει από τον Έλεγχο σελίδων, και βάζει το κουμπί παύσης στα sliders. Χωρίς αυτό, οι επισκέπτες δεν φορτώνουν κανένα script του plugin.',
						'rule'    => 'bool',
						'rec'     => true,
						'control' => abt_a11y_checkbox( 'safety_net', $s['safety_net'], 'Ενεργό' ),
					)
				);
				abt_a11y_baked_status();
				abt_a11y_row(
					array(
						'key'     => 'kill_switch',
						'label'   => 'Προσωρινή απενεργοποίηση με ?abt-a11y=off',
						'help'    => 'Χρήσιμο για σύγκριση «πριν/μετά». Αν το επιτρέψετε σε όλους, οποιοσδήποτε επισκέπτης μπορεί να δει τη σελίδα χωρίς διορθώσεις.',
						'rule'    => 'enum',
						'rec'     => 'admins',
						'extra'   => array( 'ok' => array( 'admins', 'off' ), 'warn' => array( 'everyone' ) ),
						'control' => abt_a11y_select(
							'kill_switch',
							$s['kill_switch'],
							array(
								'admins'   => 'Μόνο για διαχειριστές',
								'everyone' => 'Για όλους',
								'off'      => 'Ποτέ',
							)
						),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'optimizer_optout',
						'label'   => 'Εξαίρεση από plugins βελτιστοποίησης',
						'help'    => 'Το WP Rocket, το LiteSpeed Cache κ.ά. μπορεί να καθυστερούν τα scripts μέχρι να αλληλεπιδράσει ο χρήστης. Τότε οι διορθώσεις δεν εφαρμόζονται έγκαιρα.',
						'rule'    => 'bool',
						'rec'     => true,
						'control' => abt_a11y_checkbox( 'optimizer_optout', $s['optimizer_optout'], 'Να μην καθυστερείται το script' ),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'delete_data',
						'label'   => 'Διαγραφή του plugin',
						'help'    => 'Ισχύει όταν διαγράφετε το plugin από τα <strong>Πρόσθετα → Διαγραφή</strong>. Η απενεργοποίηση κρατά όλες τις ρυθμίσεις.<br>'
							. '<strong>Με το τικ</strong> σβήνονται από τη βάση οι ρυθμίσεις, οι αλλαγές από τη σελίδα και ό,τι κρατά το WordPress για το plugin. <strong>Χωρίς το τικ</strong> οι ρυθμίσεις μένουν στη βάση και επανέρχονται αν το εγκαταστήσετε ξανά.<br>'
							. 'Και στις δύο περιπτώσεις το WordPress σβήνει τα αρχεία του plugin από τον server και αδειάζει η cache σελίδων (WP Rocket, LiteSpeed κ.ά.). Τα εναλλακτικά κείμενα που αποθηκεύσατε στη Βιβλιοθήκη Πολυμέσων μένουν: είναι πλέον περιεχόμενο του site.',
						'control' => abt_a11y_checkbox( 'delete_data', $s['delete_data'], 'Να σβήνεται κάθε ίχνος του plugin' ),
					)
				);
				?>
			</section>

			<section id="abt-modules" class="abt-section">
				<h2>Διορθώσεις</h2>
				<p class="abt-intro">Κάθε διόρθωση καλύπτει ένα κριτήριο WCAG. Για συμμόρφωση προτείνεται να είναι όλες ενεργές.</p>
				<?php
				foreach ( $modules as $key => $m ) {
					abt_a11y_row(
						array(
							'key'     => 'modules.' . $key,
							'label'   => $m['label'],
							'help'    => $m['desc'],
							'wcag'    => $m['wcag'],
							'rule'    => 'bool',
							'rec'     => true,
							'control' => abt_a11y_checkbox( 'modules.' . $key, ! empty( $s['modules'][ $key ] ), 'Ενεργό' ),
						)
					);
				}
				?>
			</section>

			<section id="abt-contrast" class="abt-section">
				<h2>Αντίθεση χρωμάτων</h2>
				<?php
				abt_a11y_row(
					array(
						'key'     => 'contrast_level',
						'label'   => 'Επίπεδο',
						'help'    => 'AA: 4,5:1 για κανονικό κείμενο, 3:1 για μεγάλο. Αυτό ζητούν η νομοθεσία (EN 301 549) και το WAVE. Το AAA (7:1) είναι αυστηρότερο και αλλάζει περισσότερα χρώματα.',
						'wcag'    => '1.4.3',
						'rule'    => 'enum',
						'rec'     => 'AA',
						'extra'   => array( 'ok' => array( 'AA', 'AAA' ) ),
						'control' => abt_a11y_select(
							'contrast_level',
							$s['contrast_level'],
							array(
								'AA'  => 'AA (προτείνεται)',
								'AAA' => 'AAA',
							)
						),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'contrast_margin',
						'label'   => 'Περιθώριο ασφαλείας',
						'help'    => 'Πόσο πάνω από το όριο να βγαίνει η νέα αντίθεση, ώστε στρογγυλοποιήσεις και antialiasing να μη ρίχνουν το αποτέλεσμα κάτω από 4,5:1.',
						'rule'    => 'min',
						'rec'     => 0.2,
						'extra'   => array( 'min' => 0.1 ),
						'control' => abt_a11y_number( 'contrast_margin', $s['contrast_margin'], 0, 1, 0.05 ),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'text_over_image',
						'label'   => 'Κείμενο πάνω σε φωτογραφία',
						'help'    => '«Διατήρηση»: το κείμενο κρατά το χρώμα του και η κάρτα παίρνει ένα συμπαγές χρώμα κάτω από τη φωτογραφία, ώστε η αντίθεση να ισχύει και αν δεν φορτώσει η εικόνα. «Αλλαγή χρώματος»: αλλάζει το χρώμα του κειμένου.',
						'rule'    => 'enum',
						'rec'     => 'keep',
						'extra'   => array( 'ok' => array( 'keep', 'recolor' ) ),
						'control' => abt_a11y_select(
							'text_over_image',
							$s['text_over_image'],
							array(
								'keep'    => 'Διατήρηση χρώματος κειμένου (προτείνεται)',
								'recolor' => 'Αλλαγή χρώματος κειμένου',
							)
						),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'image_fallback_dark',
						'label'   => 'Φόντο κάτω από φωτογραφία, για ανοιχτό κείμενο',
						'help'    => 'Πρέπει να έχει αντίθεση με λευκό κείμενο.',
						'rule'    => 'color-vs',
						'extra'   => array( 'against' => array( '#ffffff' ) ),
						'control' => abt_a11y_color( 'image_fallback_dark', $s['image_fallback_dark'] ),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'image_fallback_light',
						'label'   => 'Φόντο κάτω από φωτογραφία, για σκούρο κείμενο',
						'help'    => 'Πρέπει να έχει αντίθεση με σκούρο κείμενο (#333333).',
						'rule'    => 'color-vs',
						'extra'   => array( 'against' => array( '#333333' ) ),
						'control' => abt_a11y_color( 'image_fallback_light', $s['image_fallback_light'] ),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'palette_backgrounds',
						'label'   => 'Χρώματα φόντου του site',
						'help'    => 'Ένα ανά γραμμή (π.χ. #ffffff, #f2f2f2). Με αυτά ελέγχονται οι αντιστοιχίσεις χρωμάτων παρακάτω.',
						'rule'    => 'colors',
						'control' => abt_a11y_textarea( 'palette_backgrounds', $s['palette_backgrounds'], "#ffffff\n#f2f2f2" ),
					)
				);
				?>
				<div class="abt-row abt-repeater" data-key="palette" data-rule="palette">
					<div class="abt-row-head"><span class="abt-row-label">Αντιστοιχίσεις χρωμάτων</span> <span class="abt-wcag">WCAG 1.4.3</span><span class="abt-badge"></span></div>
					<p class="abt-help">Όταν ένα κείμενο με το «Αρχικό» χρώμα δεν έχει αρκετή αντίθεση, μπαίνει το «Νέο». Έτσι το site χρησιμοποιεί σταθερά τις ίδιες αποχρώσεις. Χωρίς αντιστοίχιση, το plugin διαλέγει μόνο του την πλησιέστερη απόχρωση. Ο έλεγχος σελίδων προτείνει αντιστοιχίσεις.</p>
					<table class="widefat abt-table">
						<thead><tr><th scope="col">Αρχικό χρώμα</th><th scope="col">Νέο χρώμα</th><th scope="col">Αντίθεση με τα φόντα</th><th scope="col"><span class="screen-reader-text">Ενέργειες</span></th></tr></thead>
						<tbody>
						<?php foreach ( $s['palette'] as $i => $row ) : ?>
							<tr class="abt-palette-row">
								<td><?php echo abt_a11y_color( 'palette.' . $i . '.from', $row['from'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
								<td><?php echo abt_a11y_color( 'palette.' . $i . '.to', $row['to'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
								<td class="abt-palette-ratio"></td>
								<td><button type="button" class="button-link abt-remove-row">Αφαίρεση</button></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p><button type="button" class="button abt-add-palette">Προσθήκη αντιστοίχισης</button></p>
					<p class="abt-suggest" hidden><span class="abt-suggest-text"></span> <button type="button" class="button button-small abt-apply">Εφαρμογή πρότασης</button></p>
				</div>
				<?php
				abt_a11y_row(
					array(
						'key'     => 'keep_selectors',
						'label'   => 'Κείμενα που κρατούν το χρώμα τους',
						'help'    => 'CSS selectors, ένας ανά γραμμή (π.χ. <code>.hero .elementor-heading-title</code>). Δεν αλλάζει το χρώμα τους. Αν είναι πάνω σε φωτογραφία, μπαίνει συμπαγές φόντο από κάτω. Αλλιώς μπορεί να μείνουν contrast errors.<br>Πιο εύκολα: ανοίξτε τη σελίδα στο site ως διαχειριστής, <strong>Προσβασιμότητα</strong> στη μαύρη μπάρα, κλικ στο κείμενο και «Να μείνει το αρχικό χρώμα».',
						'rule'    => 'selectors',
						'control' => abt_a11y_textarea( 'keep_selectors', $s['keep_selectors'], '.hero .elementor-heading-title' ),
					)
				);
				?>
			</section>

			<section id="abt-links" class="abt-section">
				<h2>Σύνδεσμοι</h2>
				<?php
				abt_a11y_row(
					array(
						'key'     => 'auto_labels',
						'label'   => 'Αυτόματα ονόματα από τη σελίδα προορισμού',
						'help'    => 'Για συνδέσμους με μόνο εικόνα ή φόντο, χρησιμοποιεί τον τίτλο της σελίδας, κατηγορίας ή brand που ανοίγουν.',
						'wcag'    => '2.4.4',
						'rule'    => 'bool',
						'rec'     => true,
						'control' => abt_a11y_checkbox( 'auto_labels', $s['auto_labels'], 'Ενεργό' ),
					)
				);
				?>
				<div class="abt-row abt-repeater" data-key="link_labels" data-rule="labels">
					<div class="abt-row-head"><span class="abt-row-label">Ετικέτες συνδέσμων</span> <span class="abt-wcag">WCAG 2.4.4</span><span class="abt-badge"></span></div>
					<p class="abt-help">Όνομα για συγκεκριμένους συνδέσμους (π.χ. εξωτερικά sites ή banners). Υπερισχύει της αυτόματης ετικέτας. Η γλώσσα είναι προαιρετική (el, en).</p>
					<table class="widefat abt-table">
						<thead><tr><th scope="col">Διεύθυνση (URL)</th><th scope="col">Όνομα συνδέσμου</th><th scope="col">Γλώσσα</th><th scope="col"><span class="screen-reader-text">Ενέργειες</span></th></tr></thead>
						<tbody>
						<?php foreach ( $s['link_labels'] as $i => $row ) : ?>
							<tr class="abt-label-row">
								<td><input type="url" class="regular-text" name="<?php echo esc_attr( abt_a11y_name( 'link_labels.' . $i . '.url' ) ); ?>" value="<?php echo esc_attr( $row['url'] ); ?>" aria-label="Διεύθυνση"></td>
								<td><input type="text" class="regular-text abt-label-text" name="<?php echo esc_attr( abt_a11y_name( 'link_labels.' . $i . '.label' ) ); ?>" value="<?php echo esc_attr( $row['label'] ); ?>" aria-label="Όνομα"></td>
								<td><input type="text" class="small-text" name="<?php echo esc_attr( abt_a11y_name( 'link_labels.' . $i . '.lang' ) ); ?>" value="<?php echo esc_attr( $row['lang'] ); ?>" aria-label="Γλώσσα" maxlength="5"></td>
								<td><button type="button" class="button-link abt-remove-row">Αφαίρεση</button></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p><button type="button" class="button abt-add-label">Προσθήκη ετικέτας</button></p>
					<p class="abt-suggest" hidden><span class="abt-suggest-text"></span></p>
				</div>
			</section>

			<section id="abt-page-changes" class="abt-section">
				<h2>Αλλαγές από τη σελίδα</h2>
				<p class="abt-help">Ό,τι αλλάξατε πάνω στη σελίδα: ανοίξτε μια σελίδα του site ως διαχειριστής, πατήστε <strong>Προσβασιμότητα</strong> στη μαύρη μπάρα και μετά κλικ σε οποιοδήποτε σημείο. Εδώ φαίνονται όλες μαζί και αφαιρούνται.</p>
				<?php
				$kinds = array(
					'name'  => 'Όνομα',
					'alt'   => 'Εναλλακτικό κείμενο',
					'hide'  => 'Κρυφό από αναγνώστες οθόνης',
					'color' => 'Χρώμα κειμένου',
					'plate' => 'Φόντο πίσω από το κείμενο',
				);
				?>
				<input type="hidden" id="abt-rules-json" name="<?php echo esc_attr( abt_a11y_name( 'rules_json' ) ); ?>" value="<?php echo esc_attr( wp_json_encode( $s['rules'], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ); ?>">
				<?php if ( empty( $s['rules'] ) ) : ?>
					<p class="abt-empty-rules"><em>Δεν υπάρχουν ακόμη αλλαγές από τη σελίδα.</em></p>
				<?php else : ?>
					<table class="widefat striped abt-table abt-rules">
						<thead><tr><th scope="col">Πού</th><th scope="col">Στοιχείο</th><th scope="col">Αλλαγή</th><th scope="col"><span class="screen-reader-text">Ενέργειες</span></th></tr></thead>
						<tbody>
						<?php foreach ( $s['rules'] as $rule ) : ?>
							<tr class="abt-rule-row" data-rule="<?php echo esc_attr( wp_json_encode( $rule, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) ); ?>">
								<td><?php echo 'site' === $rule['scope'] ? 'Όλο το site' : '<a href="' . esc_url( home_url( $rule['scope'] ) ) . '" target="_blank" rel="noopener">' . esc_html( urldecode( $rule['scope'] ) ) . '</a>'; ?></td>
								<td><?php echo esc_html( $rule['label'] ? $rule['label'] : '—' ); ?><?php echo '' !== $rule['lang'] ? ' <span class="abt-chip">' . esc_html( strtoupper( $rule['lang'] ) ) . '</span>' : ''; ?><br><code><?php echo esc_html( $rule['sel'] ); ?></code></td>
								<td><?php echo esc_html( $kinds[ $rule['kind'] ] ); ?>
									<?php if ( 'color' === $rule['kind'] || 'plate' === $rule['kind'] ) : ?>
										<span class="abt-chip"><i style="background:<?php echo esc_attr( strtok( $rule['value'], '@' ) ); ?>"></i><?php echo esc_html( 'plate' === $rule['kind'] ? abt_a11y_plate_label( $rule['value'] ) : $rule['value'] ); ?></span>
									<?php elseif ( 'hide' !== $rule['kind'] && 'plate' !== $rule['kind'] ) : ?>
										<br>«<?php echo esc_html( '' === $rule['value'] ? '(κενό: διακοσμητική)' : $rule['value'] ); ?>»
									<?php endif; ?>
								</td>
								<td><button type="button" class="button-link abt-remove-row">Αφαίρεση</button></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</section>

			<section id="abt-strings" class="abt-section">
				<h2>Κείμενα για αναγνώστες οθόνης</h2>
				<p class="abt-intro">Τα ονόματα που δίνει το plugin σε κουμπιά και πεδία. Η στήλη ανάλογα με τη γλώσσα της σελίδας: ελληνικά για <code>el</code>, αγγλικά για όλες τις άλλες.</p>
				<div class="abt-row" data-key="strings" data-rule="strings">
					<div class="abt-row-head"><span class="abt-row-label">Κείμενα</span><span class="abt-badge"></span></div>
					<table class="widefat abt-table abt-strings">
						<thead><tr><th scope="col">Χρήση</th><th scope="col">Ελληνικά</th><th scope="col">Αγγλικά</th></tr></thead>
						<tbody>
						<?php foreach ( abt_a11y_string_defaults() as $key => $def ) : ?>
							<tr>
								<th scope="row"><?php echo esc_html( $def['label'] ); ?></th>
								<td><input type="text" class="regular-text" name="<?php echo esc_attr( abt_a11y_name( 'strings.' . $key . '.el' ) ); ?>" value="<?php echo esc_attr( $s['strings'][ $key ]['el'] ); ?>" data-default="<?php echo esc_attr( $def['el'] ); ?>" aria-label="<?php echo esc_attr( $def['label'] . ' – ελληνικά' ); ?>"></td>
								<td><input type="text" class="regular-text" name="<?php echo esc_attr( abt_a11y_name( 'strings.' . $key . '.en' ) ); ?>" value="<?php echo esc_attr( $s['strings'][ $key ]['en'] ); ?>" data-default="<?php echo esc_attr( $def['en'] ); ?>" aria-label="<?php echo esc_attr( $def['label'] . ' – αγγλικά' ); ?>"></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
					<p class="abt-suggest" hidden><span class="abt-suggest-text"></span> <button type="button" class="button button-small abt-apply">Εφαρμογή πρότασης</button></p>
				</div>
			</section>

			<section id="abt-controls" class="abt-section">
				<h2>Κουμπί παύσης slider &amp; focus</h2>
				<?php
				abt_a11y_row(
					array(
						'key'     => 'pause_position',
						'label'   => 'Θέση κουμπιού παύσης',
						'rule'    => 'enum',
						'rec'     => 'bottom-right',
						'extra'   => array( 'ok' => array( 'bottom-right', 'bottom-left', 'top-right', 'top-left' ) ),
						'control' => abt_a11y_select(
							'pause_position',
							$s['pause_position'],
							array(
								'bottom-right' => 'Κάτω δεξιά',
								'bottom-left'  => 'Κάτω αριστερά',
								'top-right'    => 'Πάνω δεξιά',
								'top-left'     => 'Πάνω αριστερά',
							)
						),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'pause_size',
						'label'   => 'Μέγεθος κουμπιού παύσης',
						'help'    => 'Τουλάχιστον 24px για να πατιέται εύκολα (WCAG 2.2: 2.5.8). Προτείνεται 36px.',
						'wcag'    => '2.5.8',
						'rule'    => 'min',
						'rec'     => 36,
						'extra'   => array( 'min' => 24 ),
						'control' => abt_a11y_number( 'pause_size', $s['pause_size'], 16, 80, 1, 'px' ),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'pause_bg',
						'label'   => 'Χρώμα κουμπιού παύσης',
						'rule'    => 'color-pair-bg',
						'extra'   => array( 'pair' => 'pause_fg' ),
						'control' => abt_a11y_color( 'pause_bg', $s['pause_bg'] ),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'pause_fg',
						'label'   => 'Χρώμα εικονιδίου κουμπιού παύσης',
						'help'    => 'Πρέπει να έχει αντίθεση με το χρώμα του κουμπιού.',
						'wcag'    => '1.4.11',
						'rule'    => 'color-pair',
						'extra'   => array( 'pair' => 'pause_bg' ),
						'control' => abt_a11y_color( 'pause_fg', $s['pause_fg'] ),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'focus_color',
						'label'   => 'Χρώμα περιγράμματος focus',
						'help'    => 'Τουλάχιστον 3:1 απέναντι στα φόντα του site.',
						'wcag'    => '2.4.7, 1.4.11',
						'rule'    => 'color-vs-bgs',
						'extra'   => array( 'need' => 3 ),
						'control' => abt_a11y_color( 'focus_color', $s['focus_color'] ),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'focus_width',
						'label'   => 'Πάχος περιγράμματος focus',
						'rule'    => 'min',
						'rec'     => 3,
						'extra'   => array( 'min' => 2 ),
						'control' => abt_a11y_number( 'focus_width', $s['focus_width'], 1, 8, 1, 'px' ),
					)
				);
				?>
			</section>

			<section id="abt-exclusions" class="abt-section">
				<h2>Εξαιρέσεις</h2>
				<?php
				abt_a11y_row(
					array(
						'key'     => 'exclude_selectors',
						'label'   => 'Στοιχεία που δεν αγγίζονται',
						'help'    => 'CSS selectors, ένας ανά γραμμή. Ό,τι βρίσκεται μέσα τους δεν διορθώνεται, οπότε τα errors εκεί θα παραμείνουν.',
						'rule'    => 'empty',
						'rec'     => '',
						'control' => abt_a11y_textarea( 'exclude_selectors', $s['exclude_selectors'], '#cookie-banner' ),
					)
				);
				abt_a11y_row(
					array(
						'key'     => 'exclude_pages',
						'label'   => 'Σελίδες χωρίς διορθώσεις',
						'help'    => 'IDs σελίδων/άρθρων, χωρισμένα με κόμμα.',
						'rule'    => 'empty',
						'rec'     => '',
						'control' => '<input type="text" class="regular-text" id="' . esc_attr( abt_a11y_field_id( 'exclude_pages' ) ) . '" name="' . esc_attr( abt_a11y_name( 'exclude_pages' ) ) . '" value="' . esc_attr( implode( ', ', $s['exclude_pages'] ) ) . '" placeholder="12, 345">',
					)
				);
				?>
			</section>

			<?php submit_button( 'Αποθήκευση' ); ?>
		</form>

		<section id="abt-tools" class="abt-section">
			<h2>Εργαλεία</h2>
			<div class="abt-tools">
				<div>
					<h3>Εξαγωγή ρυθμίσεων</h3>
					<p>Αρχείο JSON για χρήση σε άλλο site.</p>
					<button type="button" class="button abt-export">Λήψη αρχείου</button>
				</div>
				<div>
					<h3>Εισαγωγή ρυθμίσεων</h3>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="abt_a11y_import">
						<?php wp_nonce_field( 'abt_a11y_import' ); ?>
						<label for="abt-import-json" class="screen-reader-text">Ρυθμίσεις JSON</label>
						<textarea id="abt-import-json" name="json" rows="4" class="large-text code" placeholder="{ ... }"></textarea>
						<p><button type="submit" class="button">Εισαγωγή</button></p>
					</form>
				</div>
				<div>
					<h3>Επαναφορά</h3>
					<p>Όλες οι ρυθμίσεις στις προτεινόμενες τιμές. Χάνονται αντιστοιχίσεις και ετικέτες.</p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" onsubmit="return confirm('Επαναφορά όλων των ρυθμίσεων;');">
						<input type="hidden" name="action" value="abt_a11y_reset">
						<?php wp_nonce_field( 'abt_a11y_reset' ); ?>
						<button type="submit" class="button">Επαναφορά</button>
					</form>
				</div>
			</div>
		</section>

		<template id="abt-palette-template">
			<tr class="abt-palette-row">
				<td><?php echo abt_a11y_color( 'palette.__i__.from', '#189896' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
				<td><?php echo abt_a11y_color( 'palette.__i__.to', '#116a68' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
				<td class="abt-palette-ratio"></td>
				<td><button type="button" class="button-link abt-remove-row">Αφαίρεση</button></td>
			</tr>
		</template>
		<template id="abt-label-template">
			<tr class="abt-label-row">
				<td><input type="url" class="regular-text" name="<?php echo esc_attr( abt_a11y_name( 'link_labels.__i__.url' ) ); ?>" value="" aria-label="Διεύθυνση"></td>
				<td><input type="text" class="regular-text abt-label-text" name="<?php echo esc_attr( abt_a11y_name( 'link_labels.__i__.label' ) ); ?>" value="" aria-label="Όνομα"></td>
				<td><input type="text" class="small-text" name="<?php echo esc_attr( abt_a11y_name( 'link_labels.__i__.lang' ) ); ?>" value="" aria-label="Γλώσσα" maxlength="5"></td>
				<td><button type="button" class="button-link abt-remove-row">Αφαίρεση</button></td>
			</tr>
		</template>
	</div>
	<?php
}

/* -------------------------------------------------------------------------
 * Scanner page
 * ---------------------------------------------------------------------- */

function abt_a11y_render_scanner() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap abt-wrap abt-scan">
		<h1>Έλεγχος σελίδων</h1>
		<p class="abt-intro">Ανοίγει τις σελίδες του site στο παρασκήνιο και μετράει τα <strong>Errors</strong> και <strong>Contrast Errors</strong> με τους κανόνες του WAVE (WebAIM), με και χωρίς τις διορθώσεις. Για την τελική επιβεβαίωση ελέγξτε μερικές σελίδες και με το ίδιο το WAVE.</p>
		<?php if ( abt_a11y_get_settings()['enabled'] && 'static' === abt_a11y_get_settings()['mode'] ) : ?>
			<div class="notice notice-info inline"><p><strong>Μόνιμη λειτουργία.</strong> Για κάθε σελίδα ο έλεγχος μετρά τα χρώματα που χρειάζονται διόρθωση και τα αποθηκεύει ως CSS. Μετά μετρά τη σελίδα όπως τη στέλνει ο server, <strong>χωρίς κανένα script του plugin</strong>: αυτό είναι το νούμερο «Με διορθώσεις». Ελέγξτε όλες τις σελίδες, σε υπολογιστή και κινητό, και ξανά όταν αλλάζει το design.</p></div>
		<?php endif; ?>

		<form class="abt-scan-form" onsubmit="return false;">
			<fieldset>
				<legend>Ποιες σελίδες</legend>
				<label><input type="radio" name="abt-source" value="sample" checked> Δείγμα: έως <input type="number" class="small-text" id="abt-per-type" value="5" min="1" max="200" aria-label="Σελίδες ανά τύπο"> ανά τύπο περιεχομένου</label><br>
				<label><input type="radio" name="abt-source" value="all"> Όλες οι σελίδες (μπορεί να πάρει αρκετή ώρα)</label><br>
				<label><input type="radio" name="abt-source" value="list"> Συγκεκριμένα URL</label>
				<label for="abt-url-list" class="screen-reader-text">Λίστα URL, ένα ανά γραμμή</label>
				<textarea id="abt-url-list" rows="3" class="large-text code" placeholder="<?php echo esc_attr( home_url( '/' ) ); ?>"></textarea>
			</fieldset>
			<fieldset>
				<legend>Οθόνη</legend>
				<label><input type="checkbox" id="abt-vp-desktop" checked> Υπολογιστής (1440px)</label>
				<label><input type="checkbox" id="abt-vp-mobile"> Κινητό (390px)</label>
			</fieldset>
			<fieldset>
				<legend>Επιλογές</legend>
				<label><input type="checkbox" id="abt-compare" checked> Σύγκριση με τη σελίδα χωρίς διορθώσεις</label><br>
				<label>Σελίδες ταυτόχρονα <input type="number" class="small-text" id="abt-concurrency" value="2" min="1" max="4"></label>
			</fieldset>
			<p>
				<button type="button" class="button button-primary" id="abt-scan-start">Έναρξη ελέγχου</button>
				<button type="button" class="button" id="abt-scan-stop" hidden>Διακοπή</button>
				<button type="button" class="button" id="abt-scan-csv" hidden>Εξαγωγή CSV</button>
			</p>
		</form>

		<div class="abt-progress" role="status" aria-live="polite">
			<progress id="abt-progress" max="1" value="0"></progress>
			<span id="abt-progress-text"></span>
		</div>

		<div class="abt-totals" id="abt-totals" hidden></div>

		<section class="abt-suggestions" id="abt-suggestions" hidden>
			<h2>Προτάσεις</h2>
			<div id="abt-suggestions-body"></div>
		</section>

		<h2 class="screen-reader-text">Αποτελέσματα ανά σελίδα</h2>
		<table class="widefat striped abt-results" id="abt-results" hidden>
			<thead>
				<tr>
					<th scope="col">Σελίδα</th>
					<th scope="col">Οθόνη</th>
					<th scope="col">Χωρίς διορθώσεις<br><small>errors / contrast</small></th>
					<th scope="col">Με διορθώσεις<br><small>errors / contrast</small></th>
					<th scope="col">Κατάσταση</th>
				</tr>
			</thead>
			<tbody></tbody>
		</table>
		<div id="abt-frames" class="abt-frames" aria-hidden="true"></div>
	</div>
	<?php
}

/* -------------------------------------------------------------------------
 * AJAX
 * ---------------------------------------------------------------------- */

function abt_a11y_ajax_guard() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'Δεν επιτρέπεται.' ), 403 );
	}
	check_ajax_referer( 'abt_a11y_admin', 'nonce' );
}

add_action( 'wp_ajax_abt_a11y_urls', 'abt_a11y_ajax_urls' );
function abt_a11y_ajax_urls() {
	abt_a11y_ajax_guard();
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in abt_a11y_ajax_guard().
	$all = isset( $_POST['mode'] ) && 'all' === $_POST['mode'];
	$per = isset( $_POST['per_type'] ) ? max( 1, min( 500, absint( $_POST['per_type'] ) ) ) : 5;
	// phpcs:enable
	$limit = $all ? 1000 : $per;

	$urls  = array();
	$add   = function ( $url, $type, $label ) use ( &$urls ) {
		if ( $url && ! is_wp_error( $url ) && ! isset( $urls[ $url ] ) && count( $urls ) < 5000 ) {
			$urls[ $url ] = array(
				'url'   => $url,
				'type'  => $type,
				'label' => wp_strip_all_tags( (string) $label ),
			);
		}
	};

	$langs = array( null );
	$wpml  = apply_filters( 'wpml_active_languages', null, array( 'skip_missing' => 0 ) );
	if ( is_array( $wpml ) && $wpml ) {
		$langs = array_keys( $wpml );
	}
	$current = apply_filters( 'wpml_current_language', null );

	$types = array();
	foreach ( get_post_types( array( 'public' => true ), 'objects' ) as $pt ) {
		if ( 'attachment' === $pt->name || ! is_post_type_viewable( $pt ) || in_array( $pt->name, array( 'elementor_library', 'e-landing-page', 'e-floating-buttons' ), true ) ) {
			continue;
		}
		$types[ $pt->name ] = $pt->labels->singular_name;
	}
	$taxes = array();
	foreach ( get_taxonomies( array( 'public' => true ), 'objects' ) as $tax ) {
		if ( ! is_taxonomy_viewable( $tax ) || in_array( $tax->name, array( 'post_format', 'elementor_library_type' ), true ) ) {
			continue;
		}
		$taxes[ $tax->name ] = $tax->labels->singular_name;
	}

	foreach ( $langs as $lang ) {
		if ( null !== $lang ) {
			do_action( 'wpml_switch_language', $lang );
		}
		$home = null !== $lang ? apply_filters( 'wpml_home_url', home_url( '/' ) ) : home_url( '/' );
		$add( $home, 'Αρχική', get_bloginfo( 'name' ) );

		foreach ( $types as $pt => $label ) {
			$args = array(
				'post_type'        => $pt,
				'post_status'      => 'publish',
				'posts_per_page'   => $limit,
				'orderby'          => 'date',
				'order'            => 'DESC',
				'fields'           => 'ids',
				'no_found_rows'    => true,
				'suppress_filters' => false,
			);
			if ( function_exists( 'pll_languages_list' ) ) {
				$args['lang'] = '';
			}
			foreach ( get_posts( $args ) as $id ) {
				$add( get_permalink( $id ), $label, get_the_title( $id ) );
			}
		}
		foreach ( $taxes as $tax => $label ) {
			$terms = get_terms(
				array(
					'taxonomy'   => $tax,
					'hide_empty' => true,
					'number'     => $limit,
				)
			);
			if ( is_wp_error( $terms ) ) {
				continue;
			}
			foreach ( $terms as $term ) {
				$add( get_term_link( $term ), $label, $term->name );
			}
		}
		$add( add_query_arg( 's', 'a', $home ), 'Αναζήτηση', 'Αποτελέσματα αναζήτησης' );
		$add( trailingslashit( $home ) . 'abt-a11y-' . wp_generate_password( 6, false, false ) . '/', '404', 'Σελίδα 404' );
	}
	if ( null !== $current && count( $langs ) > 1 ) {
		do_action( 'wpml_switch_language', $current );
	}

	wp_send_json_success( array_values( $urls ) );
}

add_action( 'wp_ajax_abt_a11y_add', 'abt_a11y_ajax_add' );
function abt_a11y_ajax_add() {
	abt_a11y_ajax_guard();
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in abt_a11y_ajax_guard().
	$type = isset( $_POST['type'] ) ? sanitize_key( $_POST['type'] ) : '';
	$raw  = get_option( ABT_A11Y_OPTION, array() );
	$s    = abt_a11y_sanitize( is_array( $raw ) ? $raw : array(), true );

	if ( 'palette' === $type ) {
		$from = abt_a11y_hex( isset( $_POST['from'] ) ? wp_unslash( $_POST['from'] ) : '', '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only a hex colour passes abt_a11y_hex().
		$to   = abt_a11y_hex( isset( $_POST['to'] ) ? wp_unslash( $_POST['to'] ) : '', '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only a hex colour passes abt_a11y_hex().
		if ( ! $from || ! $to ) {
			wp_send_json_error( array( 'message' => 'Μη έγκυρο χρώμα.' ) );
		}
		$s['palette'] = array_values(
			array_filter(
				$s['palette'],
				function ( $row ) use ( $from ) {
					return $row['from'] !== $from;
				}
			)
		);
		$s['palette'][] = array(
			'from' => $from,
			'to'   => $to,
		);
	} elseif ( 'label' === $type ) {
		$url   = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';
		$label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';
		$lang  = isset( $_POST['lang'] ) ? sanitize_key( wp_unslash( $_POST['lang'] ) ) : '';
		if ( ! $url || ! $label ) {
			wp_send_json_error( array( 'message' => 'Συμπληρώστε διεύθυνση και όνομα.' ) );
		}
		$s['link_labels']   = array_values(
			array_filter(
				$s['link_labels'],
				function ( $row ) use ( $url, $lang ) {
					return ! ( $row['url'] === $url && $row['lang'] === $lang );
				}
			)
		);
		$s['link_labels'][] = array(
			'url'   => $url,
			'label' => $label,
			'lang'  => $lang,
		);
	} elseif ( 'keep' === $type ) {
		$sel = isset( $_POST['selector'] ) ? abt_a11y_clean_selector( sanitize_text_field( wp_unslash( $_POST['selector'] ) ) ) : '';
		if ( ! $sel ) {
			wp_send_json_error( array( 'message' => 'Μη έγκυρος selector.' ) );
		}
		$s['keep_selectors'][] = $sel;
		$s['keep_selectors']   = array_values( array_unique( $s['keep_selectors'] ) );
	} elseif ( 'exclude' === $type ) {
		$sel = isset( $_POST['selector'] ) ? abt_a11y_clean_selector( sanitize_text_field( wp_unslash( $_POST['selector'] ) ) ) : '';
		if ( ! $sel ) {
			wp_send_json_error( array( 'message' => 'Μη έγκυρος selector.' ) );
		}
		$s['exclude_selectors'][] = $sel;
		$s['exclude_selectors']   = array_values( array_unique( $s['exclude_selectors'] ) );
	} else {
		wp_send_json_error( array( 'message' => 'Άγνωστη ενέργεια.' ) );
	}
	// phpcs:enable
	update_option( ABT_A11Y_OPTION, abt_a11y_sanitize( $s, true ) );
	wp_send_json_success( array( 'message' => 'Αποθηκεύτηκε.' ) );
}

/* -------------------------------------------------------------------------
 * Import / reset
 * ---------------------------------------------------------------------- */

add_action( 'wp_ajax_abt_a11y_bake', 'abt_a11y_ajax_bake' );
/**
 * Permanent mode: stores the colour fixes the page checker measured on one page.
 */
function abt_a11y_ajax_bake() {
	abt_a11y_ajax_guard();
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in abt_a11y_ajax_guard().
	$url  = isset( $_POST['url'] ) ? esc_url_raw( wp_unslash( $_POST['url'] ) ) : '';
	$vp   = isset( $_POST['vp'] ) && 'mobile' === $_POST['vp'] ? 'mobile' : 'desktop';
	$page = isset( $_POST['page'] ) ? (string) wp_unslash( $_POST['page'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- JSON, every selector and colour is validated by abt_a11y_sanitize_baked_rules().
	$site = isset( $_POST['site'] ) ? (string) wp_unslash( $_POST['site'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- as above.
	// phpcs:enable
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	$home = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	if ( '' === $url || preg_replace( '/^www\./', '', $host ) !== preg_replace( '/^www\./', '', $home ) || strlen( $page ) > 300000 || strlen( $site ) > 300000 ) {
		wp_send_json_error( array( 'message' => 'Μη έγκυρη σελίδα.' ) );
	}
	$page = json_decode( $page, true );
	$site = json_decode( $site, true );
	$n    = abt_a11y_store_baked( abt_a11y_path_of( $url ), $vp, is_array( $page ) ? $page : array(), is_array( $site ) ? $site : array() );
	wp_send_json_success( array( 'stored' => $n ) );
}

add_action( 'wp_ajax_abt_a11y_bake_done', 'abt_a11y_ajax_bake_done' );
function abt_a11y_ajax_bake_done() {
	abt_a11y_ajax_guard();
	abt_a11y_purge_page_caches();
	wp_send_json_success();
}

add_action( 'admin_post_abt_a11y_baked_clear', 'abt_a11y_baked_clear' );
function abt_a11y_baked_clear() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Δεν επιτρέπεται.' );
	}
	check_admin_referer( 'abt_a11y_baked_clear' );
	abt_a11y_baked_clear_all();
	abt_a11y_purge_page_caches();
	wp_safe_redirect( admin_url( 'admin.php?page=abt-a11y&abt-notice=baked-cleared' ) );
	exit;
}

add_action( 'admin_post_abt_a11y_import', 'abt_a11y_import' );
function abt_a11y_import() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Δεν επιτρέπεται.', 403 );
	}
	check_admin_referer( 'abt_a11y_import' );
	$json = isset( $_POST['json'] ) ? wp_unslash( $_POST['json'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- decoded and sanitised below.
	$data = json_decode( (string) $json, true );
	if ( ! is_array( $data ) ) {
		wp_safe_redirect( admin_url( 'admin.php?page=abt-a11y&abt-notice=import-error' ) );
		exit;
	}
	if ( isset( $data['settings'] ) && is_array( $data['settings'] ) ) {
		$data = $data['settings'];
	}
	update_option( ABT_A11Y_OPTION, abt_a11y_sanitize( $data, true ) );
	wp_safe_redirect( admin_url( 'admin.php?page=abt-a11y&abt-notice=imported' ) );
	exit;
}

add_action( 'admin_post_abt_a11y_reset', 'abt_a11y_reset' );
function abt_a11y_reset() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Δεν επιτρέπεται.', 403 );
	}
	check_admin_referer( 'abt_a11y_reset' );
	update_option( ABT_A11Y_OPTION, abt_a11y_defaults() );
	wp_safe_redirect( admin_url( 'admin.php?page=abt-a11y&abt-notice=reset' ) );
	exit;
}

/* -------------------------------------------------------------------------
 * Older site-specific fix still installed
 * ---------------------------------------------------------------------- */

add_action( 'admin_notices', 'abt_a11y_conflict_notice_global' );
function abt_a11y_conflict_notice_global() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $screen && false !== strpos( (string) $screen->id, 'abt-a11y' ) ) {
		return; // Shown inside the plugin's own pages instead.
	}
	abt_a11y_conflict_notice();
}

function abt_a11y_conflict_notice() {
	$conflict = abt_a11y_conflict();
	if ( '' === $conflict || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	echo '<div class="notice notice-warning"><p><strong>Προσβασιμότητα:</strong> υπάρχει ακόμη η παλιά διόρθωση <code>' . esc_html( $conflict ) . '</code>. '
		. 'Για να μη γίνονται οι διορθώσεις δύο φορές, το plugin περιμένει. Διαγράψτε το αρχείο και οι διορθώσεις του plugin ενεργοποιούνται αμέσως.</p></div>';
}
