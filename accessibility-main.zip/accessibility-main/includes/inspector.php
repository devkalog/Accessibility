<?php
/**
 * The on-page editor's entry point: an item in the admin bar on the front end that shows
 * administrators the remaining WAVE errors and every change the plugin made on the page,
 * and loads the editor (assets/inspector.js) to change any element.
 *
 * @package Aboutnet_A11y
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function abt_a11y_inspector_allowed() {
	return ! is_admin() && is_user_logged_in() && current_user_can( 'manage_options' ) && is_admin_bar_showing();
}

add_action( 'admin_bar_menu', 'abt_a11y_admin_bar', 90 );
/**
 * @param WP_Admin_Bar $bar Admin bar.
 */
function abt_a11y_admin_bar( $bar ) {
	if ( ! abt_a11y_inspector_allowed() ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	$off = isset( $_GET['abt-a11y'] ) && 'off' === $_GET['abt-a11y'];

	$bar->add_node(
		array(
			'id'    => 'abt-a11y',
			'title' => '<span class="ab-icon" aria-hidden="true"></span><span class="ab-label">Προσβασιμότητα</span>',
			'href'  => admin_url( 'admin.php?page=abt-a11y' ),
		)
	);
	if ( abt_a11y_enabled() ) {
		$bar->add_node(
			array(
				'parent' => 'abt-a11y',
				'id'     => 'abt-a11y-inspect',
				'title'  => 'Επεξεργασία στη σελίδα',
				'href'   => '#abt-a11y-inspect',
			)
		);
		$bar->add_node(
			array(
				'parent' => 'abt-a11y',
				'id'     => 'abt-a11y-off',
				'title'  => 'Η σελίδα χωρίς διορθώσεις',
				'href'   => add_query_arg( 'abt-a11y', 'off' ),
			)
		);
		if ( abt_a11y_static_mode() ) {
			$nojs = abt_a11y_scan_view( 'nojs' );
			$bar->add_node(
				array(
					'parent' => 'abt-a11y',
					'id'     => 'abt-a11y-nojs',
					'title'  => $nojs ? 'Η σελίδα με το script του plugin' : 'Η σελίδα χωρίς το script του plugin',
					'href'   => $nojs ? remove_query_arg( 'abt-a11y-nojs' ) : add_query_arg( 'abt-a11y-nojs', '1' ),
				)
			);
		}
	} elseif ( $off ) {
		$bar->add_node(
			array(
				'parent' => 'abt-a11y',
				'id'     => 'abt-a11y-on',
				'title'  => 'Η σελίδα με διορθώσεις',
				'href'   => remove_query_arg( 'abt-a11y' ),
			)
		);
	}
	$bar->add_node(
		array(
			'parent' => 'abt-a11y',
			'id'     => 'abt-a11y-settings',
			'title'  => 'Ρυθμίσεις',
			'href'   => admin_url( 'admin.php?page=abt-a11y' ),
		)
	);
	$bar->add_node(
		array(
			'parent' => 'abt-a11y',
			'id'     => 'abt-a11y-scan',
			'title'  => 'Έλεγχος σελίδων',
			'href'   => admin_url( 'admin.php?page=abt-a11y-scan' ),
		)
	);
}

add_action( 'wp_enqueue_scripts', 'abt_a11y_inspector_enqueue', 100 );
function abt_a11y_inspector_enqueue() {
	if ( ! abt_a11y_inspector_allowed() ) {
		return;
	}
	wp_enqueue_style( 'abt-a11y-inspector', ABT_A11Y_URL . 'assets/inspector.css', array(), ABT_A11Y_VERSION );
	if ( ! abt_a11y_enabled() || 'none' === abt_a11y_runtime_load() ) {
		return; // Only the admin bar icon is needed.
	}
	wp_enqueue_script( 'abt-a11y-inspector', ABT_A11Y_URL . 'assets/inspector.js', array( 'abt-a11y' ), ABT_A11Y_VERSION, true );
	wp_localize_script(
		'abt-a11y-inspector',
		'abtA11yInspector',
		array(
			'ajax'     => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'abt_a11y_admin' ),
			'settings' => admin_url( 'admin.php?page=abt-a11y' ),
			'media'    => admin_url( 'upload.php?search=' ),
			'checker'  => ABT_A11Y_URL . 'assets/checker.js?ver=' . ABT_A11Y_VERSION,
			'home'     => home_url( '/' ),
		)
	);
}
