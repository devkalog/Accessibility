<?php
/**
 * Permanent mode: the fixes are written into the page on the server, before it is sent,
 * so they are in the HTML itself and do not depend on JavaScript. The same rules as the
 * browser runtime (assets/runtime.js), pass for pass. Colour contrast cannot be measured
 * without rendering the page: those fixes are measured by the page checker in the
 * administrator's browser and stored as CSS (see "Baked colour fixes" below).
 *
 * @package Aboutnet_A11y
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once ABT_A11Y_DIR . 'includes/html.php';

const ABT_A11Y_BAKED = 'abt_a11y_baked';

function abt_a11y_static_mode() {
	return 'static' === abt_a11y_get_settings()['mode'];
}

/**
 * Admin-only views used by the page checker: "learn" (fixes measured in the browser, without
 * the stored colours) and "nojs" (only what the server sends, no runtime).
 *
 * @param string $view learn|nojs
 * @return bool
 */
function abt_a11y_scan_view( $view ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only view switch, administrators only.
	return isset( $_GET[ 'abt-a11y-' . $view ] ) && current_user_can( 'manage_options' );
}

/* -------------------------------------------------------------------------
 * Output buffer
 * ---------------------------------------------------------------------- */

add_action( 'template_redirect', 'abt_a11y_static_start', PHP_INT_MAX - 100 );
function abt_a11y_static_start() {
	if ( ! abt_a11y_static_mode() || ! abt_a11y_enabled() || is_feed() || is_robots() || is_embed() ) {
		return;
	}
	if ( function_exists( 'amp_is_request' ) && amp_is_request() ) {
		return;
	}
	if ( 'UTF-8' !== strtoupper( (string) get_bloginfo( 'charset' ) ) ) {
		return;
	}
	ob_start( 'abt_a11y_static_buffer' );
}

/**
 * Collects the page and fixes it once it is complete. Pages that are flushed early are
 * held until the end; anything that is not HTML, or larger than 4 MB, passes through.
 *
 * @param string $chunk
 * @param int    $phase
 * @return string
 */
function abt_a11y_static_buffer( $chunk, $phase ) {
	static $held = '', $pass = false;
	if ( $pass ) {
		return $chunk;
	}
	$held .= $chunk;
	if ( strlen( $held ) > 4 * 1024 * 1024 || ! abt_a11y_is_html_response() ) {
		$pass = true;
		$out  = $held;
		$held = '';
		return $out;
	}
	if ( ! ( $phase & PHP_OUTPUT_HANDLER_FINAL ) && ! ( $phase & PHP_OUTPUT_HANDLER_END ) ) {
		return '';
	}
	$html = $held;
	$held = '';
	try {
		return abt_a11y_static_fix( $html );
	} catch ( Throwable $e ) {
		return $html; // Never break a page: send it as it was.
	}
}

function abt_a11y_is_html_response() {
	foreach ( headers_list() as $header ) {
		if ( 0 === stripos( $header, 'content-type:' ) ) {
			return false !== stripos( $header, 'text/html' );
		}
	}
	return true;
}

/**
 * @param string $html
 * @return string
 */
function abt_a11y_static_fix( $html ) {
	if ( false === stripos( $html, '<body' ) && false === stripos( $html, '<html' ) ) {
		return $html;
	}
	$t0  = microtime( true );
	$doc = new ABT_A11y_Html( $html );
	if ( ! $doc->ok ) {
		return $html;
	}
	$fixer = new ABT_A11y_Static( $doc );
	$fixer->run();
	$out = $doc->output();
	if ( current_user_can( 'manage_options' ) ) {
		$out .= sprintf( "\n<!-- Aboutnet Accessibility: %d fixes on the server in %.1f ms -->", $fixer->count, ( microtime( true ) - $t0 ) * 1000 );
	}
	return $out;
}

/* -------------------------------------------------------------------------
 * The fixes
 * ---------------------------------------------------------------------- */

final class ABT_A11y_Static {

	const CONTROLS   = array( 'input', 'textarea', 'select' );
	const NO_CONTROL = array( 'image', 'submit', 'reset', 'button', 'hidden' );
	const HEADINGS   = array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' );

	/** @var ABT_A11y_Html */
	private $d;
	private $s;
	private $lang;
	private $marks;
	private $labels  = array();
	private $strings = array();
	private $excluded = array();
	private $twins   = null;
	private $lookups = 0;
	private $uid     = 0;
	private $base_host;
	private $base_url;
	public $count    = 0;

	const SOCIAL = array(
		'facebook.com'    => 'Facebook',
		'fb.com'          => 'Facebook',
		'instagram.com'   => 'Instagram',
		'linkedin.com'    => 'LinkedIn',
		'youtube.com'     => 'YouTube',
		'youtu.be'        => 'YouTube',
		'tiktok.com'      => 'TikTok',
		'x.com'           => 'X',
		'twitter.com'     => 'X',
		'pinterest.com'   => 'Pinterest',
		'vimeo.com'       => 'Vimeo',
		'threads.net'     => 'Threads',
		'wa.me'           => 'WhatsApp',
		'whatsapp.com'    => 'WhatsApp',
		'viber.com'       => 'Viber',
		'maps.google.com' => 'Google Maps',
		'goo.gl'          => 'Google Maps',
		'tripadvisor.com' => 'Tripadvisor',
		'spotify.com'     => 'Spotify',
		'behance.net'     => 'Behance',
		'dribbble.com'    => 'Dribbble',
		'github.com'      => 'GitHub',
		'telegram.me'     => 'Telegram',
		't.me'            => 'Telegram',
		'messenger.com'   => 'Messenger',
	);

	const GENERIC_TEXT = '/^(περισσότερα|μάθετε περισσότερα|δείτε (περισσότερα|εδώ)|διαβάστε (περισσότερα|εδώ)|εδώ|read more|learn more|more|click here|here|see more|view more|details|λεπτομέρειες|→|»|>)$/iu';

	public function __construct( ABT_A11y_Html $doc ) {
		$this->d     = $doc;
		$this->s     = abt_a11y_get_settings();
		$this->lang  = abt_a11y_lang();
		$this->marks = current_user_can( 'manage_options' );
		foreach ( $this->s['strings'] as $key => $pair ) {
			$this->strings[ $key ] = 'el' === $this->lang ? $pair['el'] : $pair['en'];
		}
		$labels = $this->s['auto_labels'] ? $GLOBALS['abt_a11y_labels'] : array();
		foreach ( $this->s['link_labels'] as $row ) {
			if ( '' === $row['lang'] || $row['lang'] === $this->lang ) {
				$labels[ $row['url'] ] = $row['label'];
			}
		}
		$this->base_host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$scheme          = is_ssl() ? 'https' : 'http';
		$uri             = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only parsed as a URL.
		$host            = isset( $_SERVER['HTTP_HOST'] ) ? strtolower( (string) wp_unslash( $_SERVER['HTTP_HOST'] ) ) : $this->base_host; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- only compared and parsed.
		if ( ! preg_match( '/^[a-z0-9.:\[\]-]+$/', $host ) ) {
			$host = $this->base_host;
		}
		$this->base_url = $scheme . '://' . $host . ( '/' === substr( $uri, 0, 1 ) ? $uri : '/' );
		foreach ( $labels as $url => $label ) {
			$label = self::clean( $label );
			if ( '' !== $label ) {
				$this->labels[ $this->norm_url( $url ) ] = $label;
			}
		}
	}

	private function t( $key, $fallback ) {
		return isset( $this->strings[ $key ] ) && '' !== trim( $this->strings[ $key ] ) ? trim( $this->strings[ $key ] ) : $fallback;
	}

	private function on( $module ) {
		return ! empty( $this->s['modules'][ $module ] );
	}

	private static function clean( $s ) {
		return ABT_A11y_Html::clean( $s );
	}

	private function set( $i, $name, $value ) {
		$this->d->set( $i, $name, $value );
	}

	private function mark( $i, $what ) {
		$this->count++;
		if ( $this->marks ) {
			$this->d->set( $i, 'data-abt-a11y', $what );
		}
	}

	private function keep_original( $i, $name, $value ) {
		if ( $this->marks ) {
			$this->d->set( $i, $name, $value );
		}
	}

	public function run() {
		$this->prepare_exclusions();
		$this->apply_rules();
		$passes = array(
			'lang'     => 'fix_lang',
			'aria'     => 'fix_aria',
			'svg'      => 'fix_svgs',
			'images'   => 'fix_images',
			'links'    => 'fix_links',
			'buttons'  => 'fix_buttons',
			'forms'    => 'fix_forms',
			'headings' => 'fix_headings',
		);
		foreach ( $passes as $module => $method ) {
			if ( $this->on( $module ) ) {
				$this->$method();
			}
		}
		if ( $this->on( 'skip' ) ) {
			$this->fix_skip_links();
		}
	}

	/* ---------------- Helpers ---------------- */

	private function prepare_exclusions() {
		foreach ( $this->s['exclude_selectors'] as $sel ) {
			$hits = $this->d->select( $sel );
			foreach ( (array) $hits as $i ) {
				$this->excluded[] = array( $i, $this->d->nodes[ $i ]['last'] );
			}
		}
	}

	private function excluded( $i ) {
		foreach ( $this->excluded as $r ) {
			if ( $i >= $r[0] && $i <= $r[1] ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Elements by tag, minus the excluded parts of the page.
	 *
	 * @return int[]
	 */
	private function q( $tags ) {
		$out = array();
		foreach ( (array) $tags as $t ) {
			// Inside SVG/MathML only <svg> and <a> are what the fixes mean; a <label> or <img> there is not HTML.
			$any_ns = 'a' === $t || 'svg' === $t;
			if ( ! empty( $this->d->by_tag[ $t ] ) ) {
				foreach ( $this->d->by_tag[ $t ] as $i ) {
					if ( $this->d->tag( $i ) === $t && ! $this->excluded( $i ) && ( $any_ns || ! $this->d->is_foreign( $i ) ) ) {
						$out[] = $i;
					}
				}
			}
		}
		sort( $out );
		return $out;
	}

	private function attr( $i, $name ) {
		return $this->d->attr( $i, $name );
	}

	private function non_empty( $i, $name ) {
		return $this->d->non_empty( $i, $name );
	}

	private function has( $i, $name ) {
		return $this->d->has( $i, $name );
	}

	private function svg_named( $svg ) {
		if ( $this->non_empty( $svg, 'aria-label' ) || $this->has( $svg, 'aria-labelledby' ) ) {
			return true;
		}
		foreach ( $this->d->children( $svg ) as $c ) {
			if ( 'title' === $this->d->tag( $c ) && $this->d->has_text( $c ) ) {
				return true;
			}
		}
		return false;
	}

	private function has_content( $i ) {
		if ( $this->d->has_text( $i ) ) {
			return true;
		}
		foreach ( $this->d->descendants( $i, array( 'img', 'input', 'area' ) ) as $j ) {
			if ( 'input' === $this->d->tag( $j ) && 'image' !== strtolower( (string) $this->attr( $j, 'type' ) ) ) {
				continue;
			}
			if ( $this->non_empty( $j, 'alt' ) ) {
				return true;
			}
		}
		foreach ( $this->d->descendants( $i, array( 'svg' ) ) as $j ) {
			if ( $this->svg_named( $j ) ) {
				return true;
			}
		}
		return false;
	}

	private function has_name( $i ) {
		return $this->has_content( $i ) || $this->non_empty( $i, 'aria-label' ) || $this->non_empty( $i, 'aria-labelledby' ) || $this->non_empty( $i, 'title' );
	}

	private static function cap( $s ) {
		$s = self::clean( $s );
		if ( '' === $s ) {
			return $s;
		}
		if ( function_exists( 'mb_substr' ) && function_exists( 'mb_strtoupper' ) ) {
			return mb_strtoupper( mb_substr( $s, 0, 1, 'UTF-8' ), 'UTF-8' ) . mb_substr( $s, 1, null, 'UTF-8' );
		}
		return ucfirst( $s );
	}

	private static function lower( $s ) {
		return function_exists( 'mb_strtolower' ) ? mb_strtolower( (string) $s, 'UTF-8' ) : strtolower( (string) $s );
	}

	public static function humanize( $s ) {
		$s = (string) $s;
		$d = rawurldecode( $s );
		if ( false !== $d && preg_match( '//u', $d ) ) {
			$s = $d;
		}
		$s     = preg_replace( '/[?#].*$/s', '', $s );
		$parts = array_values( array_filter( explode( '/', $s ), 'strlen' ) );
		$s     = $parts ? end( $parts ) : '';
		$s     = preg_replace( '/\.[a-z0-9]{2,5}$/i', '', $s );
		$s     = preg_replace( '/-\d+x\d+$/i', '', $s );
		$s     = preg_replace( '/-(scaled|min|removebg-preview|copy|e\d{10,})$/i', '', $s );
		$s     = preg_replace( '/[-_+]+/', ' ', $s );
		$s     = preg_replace( '/\s\d{1,2}$/', '', $s );
		return self::cap( $s );
	}

	/**
	 * Resolves a link against the page address, like new URL(href, document.baseURI).
	 *
	 * @return array|null wp_parse_url() parts.
	 */
	private function resolve( $href ) {
		$href = trim( (string) $href );
		if ( preg_match( '#^[a-z][a-z0-9+.-]*:#i', $href ) ) {
			$url = $href;
		} elseif ( '//' === substr( $href, 0, 2 ) ) {
			$url = ( is_ssl() ? 'https:' : 'http:' ) . $href;
		} else {
			$base = wp_parse_url( $this->base_url );
			if ( ! is_array( $base ) ) {
				return null;
			}
			$origin = $base['scheme'] . '://' . $base['host'] . ( isset( $base['port'] ) ? ':' . $base['port'] : '' );
			$bpath  = isset( $base['path'] ) ? $base['path'] : '/';
			if ( '' === $href ) {
				$url = $this->base_url;
			} elseif ( '/' === $href[0] ) {
				$url = $origin . $href;
			} elseif ( '?' === $href[0] ) {
				$url = $origin . $bpath . $href;
			} elseif ( '#' === $href[0] ) {
				$url = preg_replace( '/#.*$/', '', $this->base_url ) . $href;
			} else {
				$url = $origin . preg_replace( '#[^/]*$#', '', $bpath ) . $href;
			}
		}
		$parts = wp_parse_url( $url );
		return is_array( $parts ) ? $parts : null;
	}

	private function norm_url( $href ) {
		if ( '' === (string) $href ) {
			return '';
		}
		$u = $this->resolve( $href );
		if ( ! $u ) {
			return strtolower( (string) $href );
		}
		$host = isset( $u['host'] ) ? preg_replace( '/^www\./', '', strtolower( $u['host'] ) ) . ( isset( $u['port'] ) ? ':' . $u['port'] : '' ) : '';
		$path = isset( $u['path'] ) ? $u['path'] : '/';
		$dec  = rawurldecode( $path );
		$path = preg_match( '//u', $dec ) ? $dec : $path;
		$path = rtrim( $path, '/' );
		$path = '' === $path ? '/' : $path;
		$q    = '';
		if ( ! empty( $u['query'] ) ) {
			$pairs = array();
			foreach ( explode( '&', $u['query'] ) as $pair ) {
				if ( '' === $pair ) {
					continue;
				}
				$kv      = explode( '=', $pair, 2 );
				$pairs[] = urldecode( $kv[0] ) . '=' . ( isset( $kv[1] ) ? urldecode( $kv[1] ) : '' );
			}
			sort( $pairs );
			$q = $pairs ? '?' . implode( '&', $pairs ) : '';
		}
		return self::lower( $host . $path . $q );
	}

	private static function social_name( $host ) {
		$host = preg_replace( '/^www\./', '', strtolower( (string) $host ) );
		foreach ( self::SOCIAL as $domain => $name ) {
			if ( $host === $domain || substr( $host, -( strlen( $domain ) + 1 ) ) === '.' . $domain ) {
				return $name;
			}
		}
		return '';
	}

	private function mail_or_phone( $href ) {
		$low = strtolower( $href );
		if ( 0 === strpos( $low, 'mailto:' ) ) {
			$addr = explode( '?', substr( $href, 7 ) );
			return $this->t( 'email', 'Email' ) . ': ' . $addr[0];
		}
		if ( 0 === strpos( $low, 'tel:' ) ) {
			return $this->t( 'phone', 'Phone' ) . ': ' . substr( $href, 4 );
		}
		return '';
	}

	private function sure_url_label( $href ) {
		if ( '' === $href ) {
			return '';
		}
		$mp = $this->mail_or_phone( $href );
		if ( '' !== $mp ) {
			return $mp;
		}
		$u = $this->resolve( $href );
		return $u && isset( $u['host'] ) ? self::social_name( $u['host'] ) : '';
	}

	private function same_site( $u ) {
		if ( ! isset( $u['host'] ) ) {
			return true;
		}
		return preg_replace( '/^www\./', '', strtolower( $u['host'] ) ) === preg_replace( '/^www\./', '', $this->base_host );
	}

	/**
	 * A setting label, or the title of the page the link leads to (asked of WordPress).
	 */
	private function known_label( $href ) {
		$key = $this->norm_url( $href );
		if ( isset( $this->labels[ $key ] ) ) {
			return $this->labels[ $key ];
		}
		if ( ! $this->s['auto_labels'] || $this->lookups >= 60 ) {
			return '';
		}
		$u = $this->resolve( $href );
		if ( ! $u || empty( $u['scheme'] ) || ! in_array( strtolower( $u['scheme'] ), array( 'http', 'https' ), true ) || ! $this->same_site( $u ) ) {
			return '';
		}
		$this->lookups++;
		$abs   = $u['scheme'] . '://' . $u['host'] . ( isset( $u['port'] ) ? ':' . $u['port'] : '' ) . ( isset( $u['path'] ) ? $u['path'] : '/' ) . ( isset( $u['query'] ) ? '?' . $u['query'] : '' );
		$label = self::clean( abt_a11y_label_for_url( $abs ) );
		$this->labels[ $key ] = $label;
		return $label;
	}

	private function label_from_url( $href ) {
		if ( '' === $href ) {
			return '';
		}
		$known = $this->known_label( $href );
		if ( '' !== $known ) {
			return $known;
		}
		$mp = $this->mail_or_phone( $href );
		if ( '' !== $mp ) {
			return $mp;
		}
		$u = $this->resolve( $href );
		if ( ! $u ) {
			return '';
		}
		$host   = isset( $u['host'] ) ? $u['host'] : '';
		$social = self::social_name( $host );
		if ( '' !== $social ) {
			return $social;
		}
		$path = isset( $u['path'] ) ? $u['path'] : '';
		if ( preg_match( '/\.pdf$/i', $path ) ) {
			return self::humanize( $path ) . ' (PDF)';
		}
		$path = rtrim( $path, '/' );
		$same = $this->same_site( $u );
		$bare = preg_replace( '/^www\./', '', strtolower( $host ) );
		if ( '' === $path || ( $same && preg_match( '#^/[a-z]{2}(-[a-z]{2})?$#i', $path ) ) ) {
			return $same ? wp_strip_all_tags( (string) get_bloginfo( 'name' ) ) : $bare;
		}
		$name = self::humanize( $path );
		return $same ? $name : ( '' !== $name ? $name . ' – ' : '' ) . $bare;
	}

	private function element_type( $i ) {
		$tag  = $this->d->tag( $i );
		$type = strtolower( trim( (string) $this->attr( $i, 'type' ) ) );
		if ( 'button' === $tag ) {
			return in_array( $type, array( 'submit', 'reset', 'button' ), true ) ? $type : 'submit';
		}
		if ( 'input' === $tag ) {
			return '' === $type ? 'text' : $type;
		}
		if ( 'select' === $tag ) {
			return $this->has( $i, 'multiple' ) ? 'select-multiple' : 'select-one';
		}
		if ( 'textarea' === $tag ) {
			return 'textarea';
		}
		return (string) $this->attr( $i, 'type' );
	}

	private function form_of( $i ) {
		if ( ! in_array( $this->d->tag( $i ), array( 'button', 'input', 'select', 'textarea' ), true ) ) {
			return -1;
		}
		return $this->d->closest( $this->d->parent( $i ) >= 0 ? $this->d->parent( $i ) : $i, array( 'form' ) );
	}

	private function control_label( $i ) {
		$p    = $this->d->parent( $i );
		$bits = implode(
			' ',
			array(
				(string) $this->attr( $i, 'id' ),
				(string) $this->attr( $i, 'class' ),
				(string) $this->attr( $i, 'name' ),
				(string) $this->attr( $i, 'data-action' ),
				(string) $this->attr( $i, 'aria-controls' ),
				$p >= 0 ? (string) $this->attr( $p, 'class' ) : '',
			)
		);
		$icons = $this->d->descendants( $i, array( 'svg', 'i' ) );
		if ( $icons ) {
			$bits .= ' ' . (string) $this->attr( $icons[0], 'class' );
		}
		$bits     = self::lower( $bits );
		$type     = $this->element_type( $i );
		$expanded = 'true' === $this->attr( $i, 'aria-expanded' );
		if ( preg_match( '/close|dismiss|κλεισ/u', $bits ) ) {
			return $this->t( 'close', 'Close' );
		}
		if ( preg_match( '/search|αναζ|magnif/u', $bits ) ) {
			return ( false !== strpos( $bits, 'submit' ) || 'submit' === $type ) ? $this->t( 'submitSearch', 'Submit search' ) : $this->t( 'openSearch', 'Open search' );
		}
		if ( preg_match( '/pause|play/', $bits ) ) {
			return false !== strpos( $bits, 'pause' ) ? $this->t( 'pause', 'Pause' ) : $this->t( 'play', 'Play' );
		}
		if ( preg_match( '/swiper-button-prev|slick-prev|slider-prev|carousel-prev|arrow-prev|owl-prev|splide__arrow--prev/', $bits ) ) {
			return $this->t( 'prevSlide', 'Previous slide' );
		}
		if ( preg_match( '/swiper-button-next|slick-next|slider-next|carousel-next|arrow-next|owl-next|splide__arrow--next/', $bits ) ) {
			return $this->t( 'nextSlide', 'Next slide' );
		}
		if ( false !== strpos( $bits, 'flex-prev' ) ) {
			return $this->t( 'prevImage', 'Previous image' );
		}
		if ( false !== strpos( $bits, 'flex-next' ) ) {
			return $this->t( 'nextImage', 'Next image' );
		}
		if ( preg_match( '/(^|[\s_-])(prev|previous|left)([\s_-]|$)/', $bits ) ) {
			return $this->t( 'prev', 'Previous' );
		}
		if ( preg_match( '/(^|[\s_-])(next|right)([\s_-]|$)/', $bits ) ) {
			return $this->t( 'next', 'Next' );
		}
		if ( preg_match( '/menu|toggle|hamburger|burger|navbar|nav-/', $bits ) ) {
			return $expanded ? $this->t( 'closeMenu', 'Close menu' ) : $this->t( 'menu', 'Menu' );
		}
		if ( preg_match( '/scroll-?top|back-?to-?top|go-?top|to-?top/', $bits ) ) {
			return $this->t( 'backToTop', 'Back to top' );
		}
		if ( preg_match( '/cart|basket|καλαθ/u', $bits ) ) {
			return $this->t( 'cart', 'Cart' );
		}
		if ( preg_match( '/wishlist|favou?rite/', $bits ) ) {
			return $this->t( 'wishlist', 'Wishlist' );
		}
		if ( false !== strpos( $bits, 'share' ) ) {
			return $this->t( 'share', 'Share' );
		}
		if ( preg_match( '/expand|accordion|collapse/', $bits ) ) {
			return $this->t( 'expand', 'Expand' );
		}
		if ( preg_match( '/account|user|login|profile/', $bits ) ) {
			return $this->t( 'account', 'Account' );
		}
		if ( 'submit' === $type || ( $this->form_of( $i ) >= 0 && ( '' === $type || 'submit' === $type ) ) ) {
			return $this->t( 'submit', 'Submit' );
		}
		return '';
	}

	/* ---------------- Changes made with the on-page editor ---------------- */

	private function apply_rules() {
		$path = abt_a11y_current_path();
		$raw  = abt_a11y_current_path( true );
		foreach ( $this->s['rules'] as $r ) {
			if ( 'site' !== $r['scope'] && $r['scope'] !== $path && $r['scope'] !== $raw ) {
				continue;
			}
			if ( '' !== $r['lang'] && $r['lang'] !== $this->lang ) {
				continue;
			}
			if ( ! in_array( $r['kind'], array( 'name', 'alt', 'hide' ), true ) ) {
				continue; // Colours and backings are CSS.
			}
			$hits = $this->d->select( $r['sel'] );
			if ( null === $hits ) {
				continue; // Selector only the browser understands: the runtime applies it.
			}
			foreach ( $hits as $i ) {
				if ( $this->excluded( $i ) ) {
					continue;
				}
				$tag = $this->d->tag( $i );
				if ( 'name' === $r['kind'] ) {
					if ( 'svg' === $tag ) {
						$this->d->remove( $i, 'aria-hidden' );
						$this->set( $i, 'role', 'img' );
					}
					$this->set( $i, 'aria-label', $r['value'] );
				} elseif ( 'alt' === $r['kind'] ) {
					$img = -1;
					if ( 'img' === $tag || 'area' === $tag || ( 'input' === $tag && 'image' === strtolower( (string) $this->attr( $i, 'type' ) ) ) ) {
						$img = $i;
					} else {
						$imgs = $this->d->descendants( $i, array( 'img' ) );
						$img  = $imgs ? $imgs[0] : -1;
					}
					if ( $img >= 0 ) {
						$this->set( $img, 'alt', $r['value'] );
					}
				} else {
					$this->set( $i, 'aria-hidden', 'true' );
					if ( 'img' === $tag ) {
						$this->set( $i, 'alt', '' );
					}
					if ( ( 'a' === $tag && $this->has( $i, 'href' ) ) || in_array( $tag, array( 'button', 'input', 'select', 'textarea' ), true ) || $this->has( $i, 'tabindex' ) ) {
						$this->set( $i, 'tabindex', '-1' );
					}
				}
				$this->count++;
				if ( $this->marks ) {
					$this->set( $i, 'data-abt-a11y-rule', $r['kind'] );
				}
			}
		}
	}

	/* ---------------- Passes ---------------- */

	const LANG_RE = '/^[a-zA-Z]{2,3}(-[a-zA-Z0-9]{1,8})*$/';

	private function fix_lang() {
		$html = $this->d->by_tag['html'] ?? array();
		if ( $html ) {
			$root = $html[0];
			$l    = $this->attr( $root, 'lang' );
			if ( null === $l || ! preg_match( self::LANG_RE, trim( $l ) ) ) {
				$fixed = trim( str_replace( '_', '-', (string) $l ) );
				$this->keep_original( $root, 'data-abt-a11y-lang', (string) $l );
				$this->set( $root, 'lang', preg_match( self::LANG_RE, $fixed ) ? $fixed : ( $this->lang ? $this->lang : 'el' ) );
				$this->count++;
			}
		}
		foreach ( $this->d->nodes as $i => $n ) {
			if ( '#text' === $n['tag'] || 'html' === $n['tag'] || ! isset( $n['attrs']['lang'] ) || $this->excluded( $i ) ) {
				continue;
			}
			$v = (string) $n['attrs']['lang'];
			if ( '' === $v || preg_match( self::LANG_RE, trim( $v ) ) ) {
				continue;
			}
			$fixed = trim( str_replace( '_', '-', $v ) );
			$this->keep_original( $i, 'data-abt-a11y-lang', $v );
			if ( preg_match( self::LANG_RE, $fixed ) ) {
				$this->set( $i, 'lang', $fixed );
			} else {
				$this->d->remove( $i, 'lang' );
			}
			$this->count++;
		}
	}

	private function fix_aria() {
		foreach ( $this->d->nodes as $i => $n ) {
			if ( '#text' === $n['tag'] || $this->excluded( $i ) ) {
				continue;
			}
			foreach ( array( 'aria-labelledby', 'aria-describedby' ) as $attr ) {
				if ( ! isset( $n['attrs'][ $attr ] ) ) {
					continue;
				}
				$ids = preg_split( '/\s+/', trim( (string) $n['attrs'][ $attr ] ), -1, PREG_SPLIT_NO_EMPTY );
				$ok  = array();
				foreach ( $ids as $id ) {
					if ( isset( $this->d->ids[ $id ] ) ) {
						$ok[] = $id;
					}
				}
				if ( $ids && count( $ok ) === count( $ids ) ) {
					continue;
				}
				$this->keep_original( $i, 'data-abt-a11y-aria', $attr . '=' . $n['attrs'][ $attr ] );
				if ( $ok ) {
					$this->set( $i, $attr, implode( ' ', $ok ) );
				} else {
					$this->d->remove( $i, $attr );
				}
				$this->count++;
			}
			if ( isset( $n['attrs']['role'] ) && 'menu' === $n['attrs']['role'] ) {
				$items = false;
				foreach ( $this->d->descendants( $i ) as $j ) {
					$role = $this->attr( $j, 'role' );
					if ( in_array( $role, array( 'menuitem', 'menuitemcheckbox', 'menuitemradio' ), true ) ) {
						$items = true;
						break;
					}
				}
				if ( ! $items ) {
					$this->set( $i, 'data-abt-role', 'menu' );
					$this->d->remove( $i, 'role' );
					$this->count++;
				}
			}
		}
	}

	private function svg_exempt( $svg ) {
		if ( 'true' === $this->attr( $svg, 'aria-hidden' ) ) {
			return true;
		}
		if ( 'presentation' === strtolower( (string) $this->attr( $svg, 'role' ) ) ) {
			return true;
		}
		if ( $this->has( $svg, 'aria-label' ) || $this->has( $svg, 'aria-labelledby' ) ) {
			return true;
		}
		foreach ( $this->d->children( $svg ) as $c ) {
			if ( 'title' === $this->d->tag( $c ) ) {
				return true;
			}
		}
		return false;
	}

	private function fix_svgs() {
		foreach ( $this->q( 'svg' ) as $svg ) {
			if ( $this->svg_exempt( $svg ) ) {
				continue;
			}
			$this->set( $svg, 'aria-hidden', 'true' );
			$this->set( $svg, 'focusable', 'false' );
			$this->mark( $svg, 'svg-hidden' );
		}
	}

	private function fix_images() {
		$icons = array(
			array( '/directions?_car|driving/i', 'car', 'Driving directions' ),
			array( '/directions?_walk|walking/i', 'walking', 'Walking directions' ),
			array( '/directions?_transit|transit/i', 'transit', 'Transit directions' ),
			array( '/directions?_bike|bicycl|cycling/i', 'bike', 'Cycling directions' ),
		);
		foreach ( $this->q( 'img' ) as $img ) {
			if ( $this->has( $img, 'alt' ) || 'true' === $this->attr( $img, 'aria-hidden' ) ) {
				continue;
			}
			$role = strtolower( (string) $this->attr( $img, 'role' ) );
			if ( 'presentation' === $role || 'none' === $role || $this->has( $img, 'aria-label' ) || $this->has( $img, 'aria-labelledby' ) ) {
				continue;
			}
			$src = (string) ( $this->attr( $img, 'src' ) ?? $this->attr( $img, 'data-src' ) );
			if ( '' === $src ) {
				$src = (string) $this->attr( $img, 'data-src' );
			}
			foreach ( $icons as $ic ) {
				if ( preg_match( $ic[0], $src ) ) {
					$this->set( $img, 'alt', $this->t( $ic[1], $ic[2] ) );
					$this->mark( $img, 'alt-icon' );
					continue 2;
				}
			}
			$ctl = $this->d->closest( $img, array( 'a', 'button', 'label' ) );
			if ( $ctl >= 0 && $this->d->has_text( $ctl ) ) {
				$this->set( $img, 'alt', '' );
				$this->mark( $img, 'alt-empty' );
				continue;
			}
			if ( $this->non_empty( $img, 'title' ) ) {
				$this->set( $img, 'alt', self::clean( $this->attr( $img, 'title' ) ) );
				$this->mark( $img, 'alt-title' );
				continue;
			}
			$fig = $this->d->closest( $img, array( 'figure' ) );
			if ( $fig >= 0 ) {
				$caps = $this->d->descendants( $fig, array( 'figcaption' ) );
				if ( $caps && $this->d->has_text( $caps[0] ) ) {
					$this->set( $img, 'alt', '' );
					$this->mark( $img, 'alt-empty' );
					continue;
				}
			}
			$w = $this->attr( $img, 'width' );
			$h = $this->attr( $img, 'height' );
			if ( ( null !== $w && is_numeric( $w ) && (int) $w <= 3 ) || ( null !== $h && is_numeric( $h ) && (int) $h <= 3 ) || preg_match( '#(^|/)(spacer|space|blank|pixel)\.#i', $src ) ) {
				$this->set( $img, 'alt', '' );
				$this->mark( $img, 'alt-empty' );
				continue;
			}
			if ( $ctl >= 0 && 'a' === $this->d->tag( $ctl ) ) {
				$this->set( $img, 'alt', '' );
				$this->mark( $img, 'alt-empty' );
				continue;
			}
			$this->set( $img, 'alt', self::humanize( $src ) );
			$this->mark( $img, 'alt-filename' );
		}
		foreach ( $this->q( 'input' ) as $in ) {
			if ( 'image' !== strtolower( (string) $this->attr( $in, 'type' ) ) || $this->non_empty( $in, 'alt' ) ) {
				continue;
			}
			$alt = self::clean( (string) $this->attr( $in, 'value' ) );
			if ( '' === $alt ) {
				$alt = self::clean( (string) $this->attr( $in, 'title' ) );
			}
			$this->set( $in, 'alt', '' !== $alt ? $alt : $this->t( 'submit', 'Submit' ) );
			$this->mark( $in, 'named' );
		}
		foreach ( $this->q( 'area' ) as $a ) {
			if ( ! $this->has( $a, 'href' ) || $this->has( $a, 'alt' ) ) {
				continue;
			}
			$alt = self::clean( (string) $this->attr( $a, 'title' ) );
			$this->set( $a, 'alt', '' !== $alt ? $alt : $this->label_from_url( (string) $this->attr( $a, 'href' ) ) );
			$this->mark( $a, 'named' );
		}
	}

	private function twin_text( $href ) {
		$key = $this->norm_url( $href );
		if ( '' === $key ) {
			return '';
		}
		if ( null === $this->twins ) {
			$this->twins = array();
			foreach ( $this->d->by_tag['a'] ?? array() as $a ) {
				if ( 'a' !== $this->d->tag( $a ) || ! $this->has( $a, 'href' ) || ! $this->d->has_text( $a ) ) {
					continue;
				}
				$tx = $this->d->text_of( $a );
				$len = function_exists( 'mb_strlen' ) ? mb_strlen( $tx, 'UTF-8' ) : strlen( $tx );
				if ( '' === $tx || $len > 120 || preg_match( self::GENERIC_TEXT, $tx ) ) {
					continue;
				}
				$k = $this->norm_url( (string) $this->attr( $a, 'href' ) );
				if ( '' !== $k && ! isset( $this->twins[ $k ] ) ) {
					$this->twins[ $k ] = $tx;
				}
			}
		}
		return isset( $this->twins[ $key ] ) ? $this->twins[ $key ] : '';
	}

	private function is_redundant_image_link( $a ) {
		if ( ! $this->d->descendants( $a, array( 'img' ) ) ) {
			return false;
		}
		$key = $this->norm_url( (string) $this->attr( $a, 'href' ) );
		$box = $this->d->parent( $a );
		for ( $depth = 0; $box >= 0 && $depth < 5; $depth++, $box = $this->d->parent( $box ) ) {
			$links = array();
			foreach ( $this->d->descendants( $box, array( 'a' ) ) as $l ) {
				if ( $this->has( $l, 'href' ) ) {
					$links[] = $l;
				}
			}
			if ( count( $links ) > 6 ) {
				return false;
			}
			foreach ( $links as $l ) {
				if ( $l !== $a && $this->norm_url( (string) $this->attr( $l, 'href' ) ) === $key && $this->d->has_text( $l ) ) {
					return true;
				}
			}
		}
		return false;
	}

	private function bg_image_name( $i ) {
		$nodes = array_merge( array( $i ), array_slice( $this->d->descendants( $i ), 0, 20 ) );
		foreach ( $nodes as $n ) {
			$style = (string) $this->attr( $n, 'style' );
			if ( preg_match( '/url\(\s*["\']?([^"\')]+)["\']?\s*\)/i', $style, $m ) ) {
				return self::humanize( $m[1] );
			}
			foreach ( array( 'data-bg', 'data-background', 'data-background-image', 'data-bg-image' ) as $attr ) {
				$v = (string) $this->attr( $n, $attr );
				if ( '' !== $v ) {
					if ( preg_match( '/url\(\s*["\']?([^"\')]+)["\']?\s*\)/i', $v, $m ) ) {
						$v = $m[1];
					}
					return self::humanize( $v );
				}
			}
		}
		return '';
	}

	private function fix_links() {
		foreach ( $this->q( 'a' ) as $a ) {
			if ( ! $this->has( $a, 'href' ) || $this->has_name( $a ) ) {
				continue;
			}
			$href = (string) $this->attr( $a, 'href' );
			if ( $this->is_redundant_image_link( $a ) ) {
				$this->set( $a, 'aria-hidden', 'true' );
				$this->set( $a, 'tabindex', '-1' );
				$this->mark( $a, 'duplicate-link' );
				foreach ( $this->d->descendants( $a, array( 'img' ) ) as $img ) {
					if ( ! $this->has( $img, 'alt' ) ) {
						$this->set( $img, 'alt', '' );
					}
				}
				continue;
			}
			$label  = '';
			$source = 'named';
			$imgs   = $this->d->descendants( $a, array( 'img' ) );
			$img    = $imgs ? $imgs[0] : -1;
			if ( $img >= 0 && $this->non_empty( $img, 'title' ) ) {
				$label = self::clean( $this->attr( $img, 'title' ) );
			}
			if ( '' === $label ) {
				$key = $this->norm_url( $href );
				if ( isset( $this->labels[ $key ] ) && '' !== $this->labels[ $key ] ) {
					$label  = $this->labels[ $key ];
					$source = 'named-setting';
				}
			}
			if ( '' === $label && ( '#' === $href || preg_match( '/^javascript:/i', $href ) || $this->has( $a, 'role' ) ) ) {
				$label = $this->control_label( $a );
			}
			if ( '' === $label ) {
				$label = $this->twin_text( $href );
			}
			if ( '' === $label && preg_match( '/^#./', $href ) ) {
				$target = $this->d->ids[ substr( $href, 1 ) ] ?? -1;
				if ( $target >= 0 ) {
					$hd = in_array( $this->d->tag( $target ), self::HEADINGS, true ) ? $target : -1;
					if ( $hd < 0 ) {
						$hs = $this->d->descendants( $target, self::HEADINGS );
						$hd = $hs ? $hs[0] : -1;
					}
					if ( $hd >= 0 ) {
						$label = $this->d->text_of( $hd );
					}
				}
			}
			if ( '' === $label ) {
				$label = $this->sure_url_label( $href );
			}
			if ( '' === $label ) {
				$label  = $this->label_from_url( $href );
				$source = 'named-url';
			}
			if ( '' === $label ) {
				$label = $this->control_label( $a );
				if ( '' === $label ) {
					$label = $this->bg_image_name( $a );
				}
				if ( '' === $label ) {
					$label = $this->t( 'link', 'Link' );
				}
				$source = 'named-guess';
			}
			if ( $img >= 0 ) {
				$this->set( $img, 'alt', $label );
				foreach ( $imgs as $other ) {
					if ( $other !== $img && ! $this->has( $other, 'alt' ) ) {
						$this->set( $other, 'alt', '' );
					}
				}
			} else {
				$this->set( $a, 'aria-label', $label );
			}
			$this->mark( $a, $source );
		}
	}

	private function fix_buttons() {
		foreach ( $this->q( 'button' ) as $b ) {
			if ( $this->has_name( $b ) ) {
				continue;
			}
			$label = $this->control_label( $b );
			if ( '' === $label ) {
				$ctl    = preg_split( '/\s+/', trim( (string) $this->attr( $b, 'aria-controls' ) ) );
				$target = '' !== $ctl[0] && isset( $this->d->ids[ $ctl[0] ] ) ? $this->d->ids[ $ctl[0] ] : -1;
				if ( $target >= 0 ) {
					$hs    = $this->d->descendants( $target, array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'legend' ) );
					$label = $hs ? $this->d->text_of( $hs[0] ) : self::clean( (string) $this->attr( $target, 'aria-label' ) );
				}
			}
			$this->set( $b, 'aria-label', '' !== $label ? $label : $this->t( 'button', 'Button' ) );
			$this->mark( $b, '' !== $label ? 'named' : 'named-guess' );
		}
		foreach ( $this->q( 'input' ) as $in ) {
			$type = strtolower( (string) $this->attr( $in, 'type' ) );
			if ( ! in_array( $type, array( 'submit', 'button', 'reset' ), true ) ) {
				continue;
			}
			if ( $this->non_empty( $in, 'value' ) || $this->non_empty( $in, 'aria-label' ) || $this->non_empty( $in, 'aria-labelledby' ) || $this->non_empty( $in, 'title' ) ) {
				continue;
			}
			$label = 'reset' === $type ? $this->t( 'reset', 'Reset' ) : $this->control_label( $in );
			$this->set( $in, 'aria-label', '' !== $label ? $label : $this->t( 'submit', 'Submit' ) );
			$this->mark( $in, 'named' );
		}
	}

	private function is_control( $i ) {
		$tag = $this->d->tag( $i );
		if ( 'textarea' === $tag || 'select' === $tag ) {
			return true;
		}
		return 'input' === $tag && ! in_array( strtolower( (string) $this->attr( $i, 'type' ) ), self::NO_CONTROL, true );
	}

	private function controls() {
		$out = array();
		foreach ( $this->q( self::CONTROLS ) as $i ) {
			if ( $this->is_control( $i ) ) {
				$out[] = $i;
			}
		}
		return $out;
	}

	private function labels_for( $c ) {
		$list = array();
		$id   = $this->attr( $c, 'id' );
		if ( null !== $id && '' !== $id ) {
			foreach ( $this->d->by_tag['label'] ?? array() as $l ) {
				if ( 'label' === $this->d->tag( $l ) && $this->attr( $l, 'for' ) === $id ) {
					$list[] = $l;
				}
			}
		}
		$p    = $this->d->parent( $c );
		$wrap = $p >= 0 ? $this->d->closest( $p, array( 'label' ) ) : -1;
		if ( $wrap >= 0 && ! in_array( $wrap, $list, true ) && ( ! $this->has( $wrap, 'for' ) || $this->attr( $wrap, 'for' ) === $id ) ) {
			$list[] = $wrap;
		}
		return $list;
	}

	/** Visible as far as the HTML says (hidden attribute or an inline display/visibility). */
	private function visible( $i ) {
		if ( $this->has( $i, 'hidden' ) ) {
			return false;
		}
		$style = strtolower( (string) $this->attr( $i, 'style' ) );
		return ! preg_match( '/(^|;)\s*(display\s*:\s*none|visibility\s*:\s*hidden)/', $style );
	}

	private function field_name( $c, $labels ) {
		$tx = '';
		foreach ( $labels as $l ) {
			$tx = $this->d->text_of( $l );
			if ( '' !== $tx ) {
				break;
			}
		}
		if ( '' === $tx ) {
			$tx = self::clean( (string) $this->attr( $c, 'placeholder' ) );
		}
		if ( '' === $tx ) {
			$tx = self::clean( (string) $this->attr( $c, 'aria-placeholder' ) );
		}
		$tag = $this->d->tag( $c );
		if ( '' === $tx && 'select' === $tag ) {
			$opts = $this->d->descendants( $c, array( 'option' ) );
			if ( $opts ) {
				$first = $this->d->text_of( $opts[0] );
				$value = $this->has( $opts[0], 'value' ) ? (string) $this->attr( $opts[0], 'value' ) : $first;
				if ( '' !== $first && ( '' === $value || '0' === $value ) ) {
					$tx = $first;
				}
			}
		}
		if ( '' === $tx ) {
			$form = $this->form_of( $c );
			if ( 'search' === $this->element_type( $c ) || 's' === $this->attr( $c, 'name' ) || ( $form >= 0 && 'search' === $this->attr( $form, 'role' ) ) ) {
				$tx = $this->t( 'searchField', 'Search' );
			}
		}
		if ( '' === $tx ) {
			$n = (string) $this->attr( $c, 'name' );
			if ( '' === $n ) {
				$n = (string) $this->attr( $c, 'id' );
			}
			$n = preg_replace( '/^form_fields\[|\]$/', '', $n );
			$n = preg_replace( '/^field_[0-9a-f]+$/i', '', $n );
			$n = preg_replace( '/\[\]$/', '', $n );
			if ( '' !== $n && ! preg_match( '/^\d+$/', $n ) ) {
				$tx = self::humanize( $n );
			}
		}
		if ( '' === $tx ) {
			$prev = $this->previous_element( $c );
			if ( $prev >= 0 && ! $this->is_control_tag( $prev ) && $this->d->has_text( $prev ) ) {
				$pt  = $this->d->text_of( $prev );
				$len = function_exists( 'mb_strlen' ) ? mb_strlen( $pt, 'UTF-8' ) : strlen( $pt );
				if ( '' !== $pt && $len < 80 ) {
					$tx = $pt;
				}
			}
		}
		if ( '' !== $tx ) {
			return $tx;
		}
		return 'select' === $tag ? $this->t( 'select', 'Select' ) : $this->t( 'field', 'Form field' );
	}

	private function is_control_tag( $i ) {
		return in_array( $this->d->tag( $i ), self::CONTROLS, true ) && $this->is_control( $i );
	}

	private function previous_element( $i ) {
		$p = $this->d->parent( $i );
		if ( $p < 0 ) {
			return -1;
		}
		$prev = -1;
		foreach ( $this->d->children( $p ) as $c ) {
			if ( $c === $i ) {
				return $prev;
			}
			$prev = $c;
		}
		return -1;
	}

	private function fix_duplicate_ids() {
		$seen = array();
		foreach ( $this->controls() as $c ) {
			$id = $this->attr( $c, 'id' );
			if ( null === $id || '' === $id ) {
				continue;
			}
			if ( ! isset( $seen[ $id ] ) ) {
				$seen[ $id ] = $c;
				continue;
			}
			$form = $this->d->closest( $c, array( 'form' ) );
			if ( $form < 0 ) {
				$form = $this->d->parent( $c );
			}
			do {
				$new = $id . '-abt' . ( ++$this->uid );
			} while ( isset( $this->d->ids[ $new ] ) );
			$this->keep_original( $c, 'data-abt-a11y-id', $id );
			$this->set( $c, 'id', $new );
			$this->count++;
			if ( $form < 0 ) {
				continue;
			}
			foreach ( $this->d->descendants( $form ) as $el ) {
				if ( 'label' === $this->d->tag( $el ) && $this->attr( $el, 'for' ) === $id ) {
					$this->set( $el, 'for', $new );
				}
				foreach ( array( 'aria-controls', 'aria-describedby', 'aria-labelledby' ) as $a ) {
					$v = $this->attr( $el, $a );
					if ( null !== $v && false !== strpos( ' ' . $v . ' ', ' ' . $id . ' ' ) ) {
						$this->set( $el, $a, trim( str_replace( ' ' . $id . ' ', ' ' . $new . ' ', ' ' . $v . ' ' ) ) );
					}
				}
			}
		}
	}

	private function fix_forms() {
		$this->fix_duplicate_ids();
		foreach ( $this->controls() as $c ) {
			$labels = $this->labels_for( $c );
			if ( count( $labels ) > 1 ) {
				$keep = -1;
				foreach ( $labels as $l ) {
					if ( $keep < 0 && $this->has_content( $l ) && $this->visible( $l ) ) {
						$keep = $l;
					}
				}
				if ( $keep < 0 ) {
					$keep = $labels[0];
				}
				$id = $this->attr( $c, 'id' );
				foreach ( $labels as $l ) {
					if ( $l === $keep || $this->attr( $l, 'for' ) !== $id ) {
						continue;
					}
					$this->set( $l, 'data-abt-for', (string) $id );
					$this->d->remove( $l, 'for' );
					$this->count++;
				}
				$labels = array( $keep );
			}
			$name = $this->field_name( $c, $labels );
			foreach ( $labels as $l ) {
				if ( ! $this->has_content( $l ) && ! $this->d->has_appended( $l ) && $this->d->append_sr_text( $l, $name ) ) {
					$this->count++;
				}
			}
			$named = false;
			foreach ( $labels as $l ) {
				if ( $this->visible( $l ) ) {
					$named = true;
				}
			}
			if ( ! $named && ! $this->non_empty( $c, 'title' ) && ! $this->non_empty( $c, 'aria-labelledby' ) && ! $this->non_empty( $c, 'aria-label' ) ) {
				$this->set( $c, 'aria-label', $name );
				$this->mark( $c, 'named' );
			}
		}
		foreach ( $this->q( 'label' ) as $l ) {
			$for = $this->attr( $l, 'for' );
			if ( null !== $for && '' !== $for ) {
				$ctl = $this->d->ids[ $for ] ?? -1;
			} else {
				$ctl = -1;
				foreach ( $this->d->descendants( $l, self::CONTROLS ) as $x ) {
					if ( $this->is_control( $x ) ) {
						$ctl = $x;
						break;
					}
				}
			}
			if ( $ctl < 0 || $this->has_content( $l ) || $this->d->has_appended( $l ) ) {
				continue;
			}
			if ( $this->d->append_sr_text( $l, $this->field_name( $ctl, array() ) ) ) {
				$this->count++;
			}
		}
	}

	private function fix_headings() {
		foreach ( $this->q( self::HEADINGS ) as $h ) {
			if ( $this->has_content( $h ) || $this->non_empty( $h, 'aria-label' ) || $this->has( $h, 'aria-labelledby' ) ) {
				continue;
			}
			$tag = $this->d->tag( $h );
			if ( $this->d->rename( $h, 'div' ) ) {
				$this->set( $h, 'data-abt-a11y', 'empty-' . $tag );
				$this->count++;
			}
		}
		foreach ( $this->q( 'th' ) as $th ) {
			if ( $this->has_content( $th ) || $this->non_empty( $th, 'aria-label' ) || $this->has( $th, 'aria-labelledby' ) ) {
				continue;
			}
			$index = 0;
			$p     = $this->d->parent( $th );
			if ( $p >= 0 ) {
				foreach ( $this->d->children( $p ) as $c ) {
					if ( in_array( $this->d->tag( $c ), array( 'td', 'th' ), true ) ) {
						$index++;
					}
					if ( $c === $th ) {
						break;
					}
				}
			}
			$this->set( $th, 'aria-label', $this->t( 'column', 'Column' ) . ' ' . max( 1, $index ) );
			$this->mark( $th, 'named' );
		}
	}

	private function fix_skip_links() {
		foreach ( $this->d->by_tag['a'] ?? array() as $a ) {
			$href = $this->attr( $a, 'href' );
			if ( null === $href || '#' !== substr( $href, 0, 1 ) || 'a' !== $this->d->tag( $a ) || ! $this->d->has_text( $a ) ) {
				continue;
			}
			if ( ! preg_match( '/skip|jump|μετάβαση|παράλειψη/iu', $this->d->text_of( $a ) ) ) {
				continue;
			}
			$id = rawurldecode( substr( $href, 1 ) );
			if ( '' !== $id && isset( $this->d->ids[ $id ] ) ) {
				continue;
			}
			$named = false;
			foreach ( $this->d->by_tag['a'] ?? array() as $x ) {
				if ( $this->attr( $x, 'name' ) === $id && '' !== $id ) {
					$named = true;
					break;
				}
			}
			if ( $named ) {
				continue;
			}
			$main = $this->find_main();
			if ( $main < 0 ) {
				continue;
			}
			if ( ! $this->non_empty( $main, 'id' ) ) {
				$this->set( $main, 'id', 'abt-main' );
			}
			$this->keep_original( $a, 'data-abt-a11y-skip', $href );
			$this->set( $a, 'href', '#' . $this->attr( $main, 'id' ) );
			$this->count++;
		}
	}

	private $main = null;

	private function find_main() {
		if ( null === $this->main ) {
			$this->main = $this->first_main();
		}
		return $this->main;
	}

	private function first_main() {
		foreach ( $this->d->nodes as $i => $n ) {
			if ( '#text' === $n['tag'] ) {
				continue;
			}
			$classes = isset( $n['attrs']['class'] ) ? ' ' . preg_replace( '/\s+/', ' ', $n['attrs']['class'] ) . ' ' : '';
			$id      = isset( $n['attrs']['id'] ) ? $n['attrs']['id'] : '';
			if ( 'main' === $n['tag'] || ( isset( $n['attrs']['role'] ) && 'main' === $n['attrs']['role'] ) || 'content' === $id || 'main' === $id || false !== strpos( $classes, ' site-main ' ) || false !== strpos( $classes, ' site-content ' ) ) {
				return $i;
			}
		}
		// Elementor full-width templates (Hello Elementor and others): the page's own content.
		foreach ( $this->d->nodes as $i => $n ) {
			if ( '#text' !== $n['tag'] && isset( $n['attrs']['data-elementor-type'] ) && in_array( $n['attrs']['data-elementor-type'], array( 'wp-page', 'wp-post', 'single-page', 'single-post', 'single', 'product', 'archive', 'product-archive' ), true ) ) {
				return $i;
			}
		}
		return -1;
	}
}

/* -------------------------------------------------------------------------
 * Baked colour fixes (CSS)
 *
 * The page checker renders each page in the administrator's browser, lets the runtime
 * find the colour fixes, and stores them here as selector → colour, per page or for the
 * whole site (header, footer) and per screen size. They are printed as a short inline
 * stylesheet, so visitors get them with no script at all.
 * ---------------------------------------------------------------------- */

/**
 * Stored colour fixes for the whole site (header, footer): vp => rules. Small, autoloaded.
 *
 * @return array
 */
function abt_a11y_baked_site() {
	$site = get_option( ABT_A11Y_BAKED . '_site', array() );
	return is_array( $site ) ? $site : array();
}

/**
 * The option that holds one page's colour fixes. One small option per page, not loaded
 * with the other options, so each request reads only its own page.
 *
 * @param string $path
 * @return string
 */
function abt_a11y_baked_key( $path ) {
	return 'abt_a11y_bk_' . md5( (string) $path );
}

/**
 * @param string $path
 * @return array vp => rules
 */
function abt_a11y_baked_page( $path ) {
	$row = get_option( abt_a11y_baked_key( $path ), array() );
	return is_array( $row ) && isset( $row['path'] ) && $row['path'] === $path ? $row : array();
}

/**
 * How many pages and site-wide rules are stored (for the settings screen).
 *
 * @return array{pages:int,site:int}
 */
function abt_a11y_baked_counts() {
	global $wpdb;
	$pages = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'abt_a11y_bk_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- a count for the settings screen, no API for it.
	$site  = 0;
	foreach ( abt_a11y_baked_site() as $rules ) {
		$site += count( (array) $rules );
	}
	return array(
		'pages' => $pages,
		'site'  => $site,
	);
}

/**
 * Removes every stored colour fix.
 */
function abt_a11y_baked_clear_all() {
	global $wpdb;
	$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'abt_a11y_bk_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- finding the plugin's own options to delete them.
	foreach ( (array) $names as $name ) {
		delete_option( $name );
	}
	delete_option( ABT_A11Y_BAKED . '_site' );
	delete_option( ABT_A11Y_BAKED ); // Older single-option format, if any.
}

/**
 * One baked rule list: selector => [c => text colour, bg => background, op => 1].
 *
 * @param mixed $rules
 * @return array
 */
function abt_a11y_sanitize_baked_rules( $rules ) {
	$out = array();
	if ( ! is_array( $rules ) ) {
		return $out;
	}
	foreach ( $rules as $sel => $props ) {
		$sel = abt_a11y_clean_selector( (string) $sel );
		// Unbalanced brackets would void the whole grouped rule in the stylesheet.
		if ( '' === $sel || ! is_array( $props ) || substr_count( $sel, '(' ) !== substr_count( $sel, ')' ) || substr_count( $sel, '[' ) !== substr_count( $sel, ']' ) ) {
			continue;
		}
		$clean = array();
		if ( isset( $props['c'] ) && '' !== abt_a11y_hex( $props['c'], '' ) ) {
			$clean['c'] = abt_a11y_hex( $props['c'], '' );
		}
		if ( isset( $props['bg'] ) && '' !== abt_a11y_hex( $props['bg'], '' ) ) {
			$clean['bg'] = abt_a11y_hex( $props['bg'], '' );
		}
		if ( ! empty( $props['op'] ) ) {
			$clean['op'] = 1;
		}
		if ( $clean ) {
			$out[ $sel ] = $clean;
		}
		if ( count( $out ) >= 300 ) {
			break;
		}
	}
	return $out;
}

/**
 * CSS for one rule list. Text colours leave the theme's own hover and focus colours on
 * links and buttons, like the runtime does.
 *
 * @param array $rules
 * @return string
 */
function abt_a11y_baked_css( $rules ) {
	$colors = array();
	$bgs    = array();
	$ops    = array();
	foreach ( $rules as $sel => $p ) {
		if ( isset( $p['c'] ) ) {
			$colors[ $p['c'] ][] = $sel;
		}
		if ( isset( $p['bg'] ) ) {
			$bgs[ $p['bg'] ][] = $sel;
		}
		if ( ! empty( $p['op'] ) ) {
			$ops[] = $sel;
		}
	}
	$css = '';
	foreach ( $colors as $hex => $sels ) {
		$css .= abt_a11y_color_css( $sels, $hex );
	}
	foreach ( $bgs as $hex => $sels ) {
		$css .= ':is(' . implode( ',', $sels ) . '){background-color:' . $hex . '!important}';
	}
	if ( $ops ) {
		$css .= ':is(' . implode( ',', $ops ) . '){opacity:1!important}';
	}
	return $css;
}

function abt_a11y_color_css( $selectors, $hex ) {
	$not = ':not(:is(a,button,[role="button"]):hover):not(:is(a,button,[role="button"]):focus-visible):not(:is(a,button,[role="button"]):hover *):not(:is(a,button,[role="button"]):focus-visible *)';
	return ':is(' . implode( ',', (array) $selectors ) . ')' . $not . '{color:' . $hex . '!important}';
}

/**
 * Wraps desktop and mobile rules in media queries when both were measured.
 *
 * @param array $by_vp vp => rules
 * @return string
 */
function abt_a11y_baked_vp_css( $by_vp ) {
	$d = isset( $by_vp['desktop'] ) ? abt_a11y_baked_css( $by_vp['desktop'] ) : '';
	$m = isset( $by_vp['mobile'] ) ? abt_a11y_baked_css( $by_vp['mobile'] ) : '';
	if ( '' !== $d && '' !== $m ) {
		return '@media (min-width:768px){' . $d . '}@media (max-width:767.98px){' . $m . '}';
	}
	return $d . $m;
}

/**
 * Colours and backings chosen in the on-page editor, as CSS.
 *
 * @return string
 */
function abt_a11y_rules_css() {
	$s    = abt_a11y_get_settings();
	$path = abt_a11y_current_path();
	$raw  = abt_a11y_current_path( true );
	$css  = '';
	foreach ( $s['rules'] as $r ) {
		if ( 'site' !== $r['scope'] && $r['scope'] !== $path && $r['scope'] !== $raw ) {
			continue;
		}
		if ( 'color' === $r['kind'] ) {
			$css .= abt_a11y_color_css( array( $r['sel'] ), $r['value'] );
		} elseif ( 'plate' === $r['kind'] && preg_match( '/^(#[0-9a-f]{6})@([0-9.]+)(?:\/(\d+))?$/', $r['value'], $m ) ) {
			$rgba = 'rgba(' . hexdec( substr( $m[1], 1, 2 ) ) . ',' . hexdec( substr( $m[1], 3, 2 ) ) . ',' . hexdec( substr( $m[1], 5, 2 ) ) . ',' . (float) $m[2] . ')';
			// A text element gets a thin ring of the backing, a box gets rounded corners.
			$text  = preg_match( '/(^|[\s>])(a|span|strong|em|b|i|small|label|h[1-6]|p|li)([.#:\[][^\s>]*)?$/', $r['sel'] );
			$decor = $text ? 'box-shadow:0 0 0 .25em ' . $rgba . '!important;border-radius:2px!important;' : 'border-radius:8px!important;';
			$blur  = ! empty( $m[3] ) ? 'backdrop-filter:blur(' . (int) $m[3] . 'px)!important;-webkit-backdrop-filter:blur(' . (int) $m[3] . 'px)!important;' : '';
			$css  .= ':is(' . $r['sel'] . '){background-color:' . $rgba . '!important;' . $decor . $blur . '}';
		}
	}
	return $css;
}

/**
 * The permanent mode's stylesheet for the page being viewed.
 *
 * @return string
 */
function abt_a11y_static_css() {
	// Stored colour fixes belong to the contrast fix: off with it. The editor's own colours stay.
	$css = abt_a11y_rules_css();
	if ( abt_a11y_scan_view( 'learn' ) || empty( abt_a11y_get_settings()['modules']['contrast'] ) ) {
		return $css; // The checker is measuring again: it must see the page without the stored colours.
	}
	$css .= abt_a11y_baked_vp_css( abt_a11y_baked_site() );
	$css .= abt_a11y_baked_vp_css( abt_a11y_baked_page( abt_a11y_current_path() ) );
	return $css;
}

/**
 * Stores what the checker measured on one page.
 *
 * @param string $path  Page path.
 * @param string $vp    desktop|mobile
 * @param array  $page  Rules for this page.
 * @param array  $site  Rules for the whole site (header, footer).
 * @return int Number of rules stored.
 */
function abt_a11y_store_baked( $path, $vp, $page, $site ) {
	$page = abt_a11y_sanitize_baked_rules( $page );
	$site = abt_a11y_sanitize_baked_rules( $site );
	$key  = abt_a11y_baked_key( $path );
	$row  = abt_a11y_baked_page( $path );
	if ( $page ) {
		$row['path'] = $path;
		$row[ $vp ]  = $page;
		$row['t']    = time();
		update_option( $key, $row, false );
	} else {
		unset( $row[ $vp ] );
		if ( empty( $row['desktop'] ) && empty( $row['mobile'] ) ) {
			delete_option( $key );
		} else {
			update_option( $key, $row, false );
		}
	}
	if ( $site ) {
		$all        = abt_a11y_baked_site();
		$merged     = array_merge( isset( $all[ $vp ] ) ? (array) $all[ $vp ] : array(), $site );
		$all[ $vp ] = abt_a11y_sanitize_baked_rules( array_slice( $merged, -300, null, true ) );
		update_option( ABT_A11Y_BAKED . '_site', $all, true );
	}
	return count( $page ) + count( $site );
}
