<?php
/**
 * Back end of the on-page editor: saves the changes an administrator picks on
 * the page itself, writes image descriptions to the Media Library and looks up
 * suggestions (destination page titles, attachment details).
 *
 * @package Aboutnet_A11y
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @param string $src Image URL as the browser loaded it.
 * @param int    $hint Attachment id read from the markup (wp-image-123), if any.
 * @return int
 */
function abt_a11y_attachment_from_src( $src, $hint = 0 ) {
	if ( $hint && 'attachment' === get_post_type( $hint ) && wp_attachment_is_image( $hint ) ) {
		return (int) $hint;
	}
	$src = esc_url_raw( (string) $src );
	if ( '' === $src ) {
		return 0;
	}
	$src   = preg_replace( '/[?#].*$/', '', $src );
	$tries = array( $src );
	$base  = preg_replace( '/-\d+x\d+(?=\.[a-z0-9]+$)/i', '', $src );
	$tries[] = $base;
	$tries[] = preg_replace( '/(\.[a-z0-9]+)$/i', '-scaled$1', $base );
	// Image optimisers often serve example.jpg.webp or example.webp for example.jpg.
	$tries[] = preg_replace( '/\.(jpe?g|png)\.webp$/i', '.$1', $base );
	foreach ( array( 'jpg', 'jpeg', 'png' ) as $ext ) {
		$tries[] = preg_replace( '/\.webp$/i', '.' . $ext, $base );
	}
	foreach ( array_unique( $tries ) as $url ) {
		$id = attachment_url_to_postid( $url );
		if ( $id && wp_attachment_is_image( $id ) ) {
			return (int) $id;
		}
	}
	return 0;
}

add_action( 'wp_ajax_abt_a11y_lookup', 'abt_a11y_ajax_lookup' );
function abt_a11y_ajax_lookup() {
	abt_a11y_ajax_guard();
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in abt_a11y_ajax_guard().
	$out = array();
	if ( ! empty( $_POST['url'] ) ) {
		$url          = esc_url_raw( wp_unslash( $_POST['url'] ) );
		$out['title'] = abt_a11y_label_for_url( $url );
		foreach ( abt_a11y_get_settings()['link_labels'] as $row ) {
			if ( untrailingslashit( $row['url'] ) === untrailingslashit( $url ) ) {
				$out['saved'] = $row['label'];
			}
		}
	}
	if ( ! empty( $_POST['src'] ) ) {
		$id = abt_a11y_attachment_from_src( wp_unslash( $_POST['src'] ), isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0 ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- esc_url_raw() in abt_a11y_attachment_from_src().
		if ( $id ) {
			$post         = get_post( $id );
			$out['media'] = array(
				'id'      => $id,
				'alt'     => (string) get_post_meta( $id, '_wp_attachment_image_alt', true ),
				'title'   => $post ? wp_strip_all_tags( $post->post_title ) : '',
				'caption' => $post ? wp_strip_all_tags( $post->post_excerpt ) : '',
				'edit'    => current_user_can( 'edit_post', $id ) ? get_edit_post_link( $id, 'raw' ) : '',
			);
		}
	}
	// phpcs:enable
	wp_send_json_success( $out );
}

add_action( 'wp_ajax_abt_a11y_media_alt', 'abt_a11y_ajax_media_alt' );
function abt_a11y_ajax_media_alt() {
	abt_a11y_ajax_guard();
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in abt_a11y_ajax_guard().
	$id  = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
	$alt = isset( $_POST['alt'] ) ? sanitize_text_field( wp_unslash( $_POST['alt'] ) ) : '';
	// phpcs:enable
	if ( ! $id || ! wp_attachment_is_image( $id ) || ! current_user_can( 'edit_post', $id ) ) {
		wp_send_json_error( array( 'message' => 'Η εικόνα δεν βρέθηκε στη Βιβλιοθήκη Πολυμέσων.' ) );
	}
	update_post_meta( $id, '_wp_attachment_image_alt', $alt );
	wp_send_json_success( array( 'message' => 'Αποθηκεύτηκε στη Βιβλιοθήκη Πολυμέσων.' ) );
}

add_action( 'wp_ajax_abt_a11y_rule', 'abt_a11y_ajax_rule' );
function abt_a11y_ajax_rule() {
	abt_a11y_ajax_guard();
	// phpcs:disable WordPress.Security.NonceVerification.Missing -- checked in abt_a11y_ajax_guard().
	$op   = isset( $_POST['op'] ) ? sanitize_key( $_POST['op'] ) : 'save';
	$rule = array(
		'sel'   => isset( $_POST['sel'] ) ? wp_unslash( $_POST['sel'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised by abt_a11y_sanitize_rules().
		'kind'  => isset( $_POST['kind'] ) ? sanitize_key( $_POST['kind'] ) : '',
		'value' => isset( $_POST['value'] ) ? wp_unslash( $_POST['value'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised by abt_a11y_sanitize_rules().
		'scope' => isset( $_POST['scope'] ) ? sanitize_text_field( wp_unslash( $_POST['scope'] ) ) : 'site',
		'label' => isset( $_POST['label'] ) ? wp_unslash( $_POST['label'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised by abt_a11y_sanitize_rules().
		'lang'  => isset( $_POST['lang'] ) ? sanitize_key( $_POST['lang'] ) : '',
	);
	// phpcs:enable
	$clean = abt_a11y_sanitize_rules( array( $rule ) );
	if ( 'delete' !== $op && ! $clean ) {
		wp_send_json_error( array( 'message' => 'Η αλλαγή δεν είναι έγκυρη.' ) );
	}
	$raw = get_option( ABT_A11Y_OPTION, array() );
	$s   = abt_a11y_sanitize( is_array( $raw ) ? $raw : array(), true );
	$lang = ( 'name' === $rule['kind'] || 'alt' === $rule['kind'] ) && preg_match( '/^[a-z]{2}$/', $rule['lang'] ) ? $rule['lang'] : '';
	$key  = abt_a11y_rule_key( abt_a11y_clean_selector( (string) $rule['sel'] ), $rule['kind'], 'site' === $rule['scope'] ? 'site' : abt_a11y_clean_path( $rule['scope'] ), $lang );

	$s['rules'] = array_values(
		array_filter(
			$s['rules'],
			function ( $r ) use ( $key ) {
				return abt_a11y_rule_key( $r['sel'], $r['kind'], $r['scope'], $r['lang'] ) !== $key;
			}
		)
	);
	if ( 'delete' !== $op ) {
		$s['rules'][] = $clean[0];
	}
	update_option( ABT_A11Y_OPTION, abt_a11y_sanitize( $s, true ) );
	wp_send_json_success( array( 'message' => 'delete' === $op ? 'Η αλλαγή αφαιρέθηκε.' : 'Αποθηκεύτηκε.' ) );
}
