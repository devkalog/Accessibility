<?php
/**
 * Settings: schema, defaults, recommended (compliant) values and sanitisation.
 *
 * @package Aboutnet_A11y
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const ABT_A11Y_OPTION = 'abt_a11y_settings';

/**
 * The fix modules, with the WCAG success criterion each one serves.
 *
 * @return array<string,array{label:string,desc:string,wcag:string}>
 */
function abt_a11y_modules() {
	return array(
		'svg'      => array(
			'label' => 'Εικονίδια SVG',
			'desc'  => 'Κρύβει τα διακοσμητικά SVG από τους αναγνώστες οθόνης (aria-hidden). Χωρίς αυτό το WAVE τα μετράει ως «Missing alternative text».',
			'wcag'  => '1.1.1',
		),
		'images'   => array(
			'label' => 'Εικόνες χωρίς alt',
			'desc'  => 'Προσθέτει alt σε εικόνες που δεν έχουν: κενό για διακοσμητικές, αλλιώς από title, λεζάντα ή όνομα αρχείου.',
			'wcag'  => '1.1.1',
		),
		'links'    => array(
			'label' => 'Σύνδεσμοι χωρίς όνομα',
			'desc'  => 'Δίνει όνομα σε συνδέσμους που έχουν μόνο εικόνα, εικονίδιο ή φόντο (από τη σελίδα προορισμού, τις ετικέτες σας ή τον ίδιο σύνδεσμο).',
			'wcag'  => '2.4.4',
		),
		'buttons'  => array(
			'label' => 'Κουμπιά χωρίς όνομα',
			'desc'  => 'Δίνει όνομα σε κουμπιά με μόνο εικονίδιο (μενού, αναζήτηση, κλείσιμο, βέλη κ.λπ.).',
			'wcag'  => '4.1.2',
		),
		'forms'    => array(
			'label' => 'Πεδία φορμών',
			'desc'  => 'Ετικέτες σε πεδία χωρίς label, κείμενο σε κενά labels και διόρθωση διπλών id όταν μια σελίδα έχει δύο ίδιες φόρμες.',
			'wcag'  => '1.3.1, 3.3.2',
		),
		'headings' => array(
			'label' => 'Κενές επικεφαλίδες και κελιά πίνακα',
			'desc'  => 'Αφαιρεί τη σημασιολογία από κενές επικεφαλίδες και δίνει όνομα σε κενά <th>.',
			'wcag'  => '1.3.1',
		),
		'aria'     => array(
			'label' => 'ARIA',
			'desc'  => 'Διορθώνει aria-labelledby/aria-describedby που δείχνουν σε ανύπαρκτα στοιχεία και role="menu" χωρίς στοιχεία μενού.',
			'wcag'  => '1.3.1, 4.1.2',
		),
		'lang'     => array(
			'label' => 'Γλώσσα σελίδας',
			'desc'  => 'Διορθώνει μη έγκυρες τιμές lang (π.χ. el_GR → el-GR).',
			'wcag'  => '3.1.1',
		),
		'skip'     => array(
			'label' => 'Σύνδεσμος «Μετάβαση στο περιεχόμενο»',
			'desc'  => 'Αν ο skip link δείχνει σε στοιχείο που δεν υπάρχει, τον στρέφει στο κύριο περιεχόμενο.',
			'wcag'  => '2.4.1',
		),
		'contrast' => array(
			'label' => 'Αντίθεση χρωμάτων',
			'desc'  => 'Βρίσκει κείμενα με χαμηλή αντίθεση και τα διορθώνει με την πλησιέστερη απόχρωση (ή με τις αντιστοιχίσεις χρωμάτων σας).',
			'wcag'  => '1.4.3',
		),
		'pause'    => array(
			'label' => 'Κουμπί παύσης στα carousels',
			'desc'  => 'Προσθέτει κουμπί παύσης/συνέχισης σε κάθε slider που κινείται αυτόματα (Swiper, Slick).',
			'wcag'  => '2.2.2',
		),
		'focus'    => array(
			'label' => 'Ορατό focus πληκτρολογίου',
			'desc'  => 'Εμφανίζει περίγραμμα στο στοιχείο που έχει το focus όταν ο επισκέπτης κινείται με το πληκτρολόγιο.',
			'wcag'  => '2.4.7',
		),
	);
}

/**
 * Visitor-facing texts used by the fixes, per site language.
 *
 * @return array<string,array{label:string,el:string,en:string}>
 */
function abt_a11y_string_defaults() {
	return array(
		'menu'         => array( 'label' => 'Κουμπί μενού', 'el' => 'Μενού', 'en' => 'Menu' ),
		'closeMenu'    => array( 'label' => 'Κλείσιμο μενού', 'el' => 'Κλείσιμο μενού', 'en' => 'Close menu' ),
		'close'        => array( 'label' => 'Κλείσιμο', 'el' => 'Κλείσιμο', 'en' => 'Close' ),
		'openSearch'   => array( 'label' => 'Άνοιγμα αναζήτησης', 'el' => 'Άνοιγμα αναζήτησης', 'en' => 'Open search' ),
		'submitSearch' => array( 'label' => 'Υποβολή αναζήτησης', 'el' => 'Υποβολή αναζήτησης', 'en' => 'Submit search' ),
		'searchField'  => array( 'label' => 'Πεδίο αναζήτησης', 'el' => 'Αναζήτηση', 'en' => 'Search' ),
		'prev'         => array( 'label' => 'Προηγούμενο', 'el' => 'Προηγούμενο', 'en' => 'Previous' ),
		'next'         => array( 'label' => 'Επόμενο', 'el' => 'Επόμενο', 'en' => 'Next' ),
		'prevSlide'    => array( 'label' => 'Προηγούμενη διαφάνεια', 'el' => 'Προηγούμενη διαφάνεια', 'en' => 'Previous slide' ),
		'nextSlide'    => array( 'label' => 'Επόμενη διαφάνεια', 'el' => 'Επόμενη διαφάνεια', 'en' => 'Next slide' ),
		'prevImage'    => array( 'label' => 'Προηγούμενη εικόνα', 'el' => 'Προηγούμενη εικόνα', 'en' => 'Previous image' ),
		'nextImage'    => array( 'label' => 'Επόμενη εικόνα', 'el' => 'Επόμενη εικόνα', 'en' => 'Next image' ),
		'pause'        => array( 'label' => 'Παύση slider', 'el' => 'Παύση αυτόματης εναλλαγής', 'en' => 'Pause slideshow' ),
		'play'         => array( 'label' => 'Συνέχεια slider', 'el' => 'Συνέχεια αυτόματης εναλλαγής', 'en' => 'Play slideshow' ),
		'submit'       => array( 'label' => 'Υποβολή φόρμας', 'el' => 'Υποβολή', 'en' => 'Submit' ),
		'reset'        => array( 'label' => 'Επαναφορά φόρμας', 'el' => 'Επαναφορά', 'en' => 'Reset' ),
		'button'       => array( 'label' => 'Κουμπί (γενικό)', 'el' => 'Κουμπί', 'en' => 'Button' ),
		'field'        => array( 'label' => 'Πεδίο φόρμας (γενικό)', 'el' => 'Πεδίο φόρμας', 'en' => 'Form field' ),
		'select'       => array( 'label' => 'Λίστα επιλογής', 'el' => 'Επιλογή', 'en' => 'Select' ),
		'backToTop'    => array( 'label' => 'Επιστροφή επάνω', 'el' => 'Επιστροφή στην κορυφή', 'en' => 'Back to top' ),
		'cart'         => array( 'label' => 'Καλάθι', 'el' => 'Καλάθι', 'en' => 'Cart' ),
		'wishlist'     => array( 'label' => 'Αγαπημένα', 'el' => 'Αγαπημένα', 'en' => 'Wishlist' ),
		'account'      => array( 'label' => 'Λογαριασμός', 'el' => 'Ο λογαριασμός μου', 'en' => 'My account' ),
		'share'        => array( 'label' => 'Κοινοποίηση', 'el' => 'Κοινοποίηση', 'en' => 'Share' ),
		'expand'       => array( 'label' => 'Ανάπτυξη', 'el' => 'Ανάπτυξη', 'en' => 'Expand' ),
		'link'         => array( 'label' => 'Σύνδεσμος (γενικό)', 'el' => 'Σύνδεσμος', 'en' => 'Link' ),
		'email'        => array( 'label' => 'Email', 'el' => 'Email', 'en' => 'Email' ),
		'phone'        => array( 'label' => 'Τηλέφωνο', 'el' => 'Τηλέφωνο', 'en' => 'Phone' ),
		'column'       => array( 'label' => 'Στήλη πίνακα', 'el' => 'Στήλη', 'en' => 'Column' ),
		'car'          => array( 'label' => 'Οδηγίες (αυτοκίνητο)', 'el' => 'Οδηγίες με αυτοκίνητο', 'en' => 'Driving directions' ),
		'walking'      => array( 'label' => 'Οδηγίες (με τα πόδια)', 'el' => 'Οδηγίες με τα πόδια', 'en' => 'Walking directions' ),
		'transit'      => array( 'label' => 'Οδηγίες (συγκοινωνία)', 'el' => 'Οδηγίες με συγκοινωνία', 'en' => 'Transit directions' ),
		'bike'         => array( 'label' => 'Οδηγίες (ποδήλατο)', 'el' => 'Οδηγίες με ποδήλατο', 'en' => 'Cycling directions' ),
	);
}

/**
 * Default settings. Every default is also the recommended (compliant) value.
 *
 * @return array
 */
function abt_a11y_defaults() {
	$modules = array();
	foreach ( abt_a11y_modules() as $key => $unused ) {
		$modules[ $key ] = true;
	}
	$strings = array();
	foreach ( abt_a11y_string_defaults() as $key => $s ) {
		$strings[ $key ] = array(
			'el' => $s['el'],
			'en' => $s['en'],
		);
	}
	return array(
		'enabled'              => true,
		'mode'                 => 'fast',
		'safety_net'           => true,
		'modules'              => $modules,
		'contrast_level'       => 'AA',
		'contrast_margin'      => 0.2,
		'text_over_image'      => 'keep',
		'image_fallback_dark'  => '#1a1a1a',
		'image_fallback_light' => '#ffffff',
		'palette'              => array(),
		'palette_backgrounds'  => array( '#ffffff' ),
		'keep_selectors'       => array(),
		'exclude_selectors'    => array(),
		'exclude_pages'        => array(),
		'auto_labels'          => true,
		'link_labels'          => array(),
		'rules'                => array(),
		'strings'              => $strings,
		'pause_position'       => 'bottom-right',
		'pause_size'           => 36,
		'pause_bg'             => '#1a1a1a',
		'pause_fg'             => '#ffffff',
		'focus_color'          => '#1a5fb4',
		'focus_width'          => 3,
		'kill_switch'          => 'admins',
		'optimizer_optout'     => true,
		'delete_data'          => false,
	);
}

/**
 * Saved settings merged over the defaults.
 *
 * @return array
 */
function abt_a11y_get_settings() {
	static $cache = null;
	if ( null !== $cache ) {
		return $cache;
	}
	$saved = get_option( ABT_A11Y_OPTION, array() );
	$cache = abt_a11y_sanitize( is_array( $saved ) ? $saved : array(), true );
	return $cache;
}

/* -------------------------------------------------------------------------
 * Sanitisation
 * ---------------------------------------------------------------------- */

function abt_a11y_hex( $value, $fallback ) {
	$value = is_string( $value ) ? trim( $value ) : '';
	if ( preg_match( '/^#?([0-9a-f]{3}|[0-9a-f]{6})$/i', $value, $m ) ) {
		$hex = strtolower( $m[1] );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		return '#' . $hex;
	}
	return $fallback;
}

/**
 * Lines from a textarea or array, trimmed, non-empty, unique.
 *
 * @param mixed $value
 * @param int   $max
 * @return string[]
 */
function abt_a11y_lines( $value, $max = 200 ) {
	if ( is_string( $value ) ) {
		$value = preg_split( '/\r\n|\r|\n/', $value );
	}
	if ( ! is_array( $value ) ) {
		return array();
	}
	$out = array();
	foreach ( $value as $line ) {
		if ( ! is_scalar( $line ) ) {
			continue;
		}
		$line = trim( wp_strip_all_tags( (string) $line ) );
		if ( '' !== $line && ! in_array( $line, $out, true ) ) {
			$out[] = $line;
		}
		if ( count( $out ) >= $max ) {
			break;
		}
	}
	return $out;
}

/**
 * A CSS selector list we are willing to pass to querySelectorAll()/closest().
 * Anything with markup, braces or at-rules is dropped.
 *
 * @param string $selector
 * @return string
 */
function abt_a11y_clean_selector( $selector ) {
	$selector = trim( (string) $selector );
	if ( '' === $selector || strlen( $selector ) > 300 || preg_match( '/[<{};@\\\\]/', $selector ) ) {
		return '';
	}
	return $selector;
}

/**
 * @param array $input
 * @param bool  $merge_defaults Fill missing keys with defaults (reading) instead of
 *                              treating missing checkboxes as "off" (saving a form).
 * @return array
 */
function abt_a11y_sanitize( $input, $merge_defaults = false ) {
	$d   = abt_a11y_defaults();
	$in  = is_array( $input ) ? $input : array();
	$out = array();

	$bool = function ( $key ) use ( $in, $d, $merge_defaults ) {
		if ( ! array_key_exists( $key, $in ) ) {
			return $merge_defaults ? (bool) $d[ $key ] : false;
		}
		return in_array( $in[ $key ], array( true, 1, '1', 'on', 'yes', 'true' ), true );
	};

	$out['enabled']    = $bool( 'enabled' );
	$out['mode']       = isset( $in['mode'] ) && in_array( $in['mode'], array( 'fast', 'static' ), true ) ? $in['mode'] : $d['mode'];
	$out['safety_net'] = $bool( 'safety_net' );

	$out['modules'] = array();
	$mods           = isset( $in['modules'] ) && is_array( $in['modules'] ) ? $in['modules'] : array();
	foreach ( $d['modules'] as $key => $default ) {
		if ( array_key_exists( $key, $mods ) ) {
			$out['modules'][ $key ] = in_array( $mods[ $key ], array( true, 1, '1', 'on', 'yes', 'true' ), true );
		} else {
			$out['modules'][ $key ] = $merge_defaults ? (bool) $default : false;
		}
	}

	$out['contrast_level']  = isset( $in['contrast_level'] ) && in_array( $in['contrast_level'], array( 'AA', 'AAA' ), true ) ? $in['contrast_level'] : $d['contrast_level'];
	$margin                 = isset( $in['contrast_margin'] ) && is_numeric( $in['contrast_margin'] ) ? (float) $in['contrast_margin'] : $d['contrast_margin'];
	$out['contrast_margin'] = round( max( 0, min( 1, $margin ) ), 2 );
	$out['text_over_image'] = isset( $in['text_over_image'] ) && in_array( $in['text_over_image'], array( 'keep', 'recolor' ), true ) ? $in['text_over_image'] : $d['text_over_image'];

	foreach ( array( 'image_fallback_dark', 'image_fallback_light', 'pause_bg', 'pause_fg', 'focus_color' ) as $key ) {
		$out[ $key ] = abt_a11y_hex( isset( $in[ $key ] ) ? $in[ $key ] : '', $d[ $key ] );
	}

	$out['palette'] = array();
	if ( isset( $in['palette'] ) && is_array( $in['palette'] ) ) {
		foreach ( $in['palette'] as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$from = abt_a11y_hex( isset( $row['from'] ) ? $row['from'] : '', '' );
			$to   = abt_a11y_hex( isset( $row['to'] ) ? $row['to'] : '', '' );
			if ( $from && $to && $from !== $to ) {
				$out['palette'][] = array(
					'from' => $from,
					'to'   => $to,
				);
			}
			if ( count( $out['palette'] ) >= 100 ) {
				break;
			}
		}
	}

	$bgs = array();
	foreach ( abt_a11y_lines( isset( $in['palette_backgrounds'] ) ? $in['palette_backgrounds'] : $d['palette_backgrounds'], 20 ) as $hex ) {
		$hex = abt_a11y_hex( $hex, '' );
		if ( $hex && ! in_array( $hex, $bgs, true ) ) {
			$bgs[] = $hex;
		}
	}
	$out['palette_backgrounds'] = $bgs ? $bgs : $d['palette_backgrounds'];

	foreach ( array( 'keep_selectors', 'exclude_selectors' ) as $key ) {
		$out[ $key ] = array_values( array_filter( array_map( 'abt_a11y_clean_selector', abt_a11y_lines( isset( $in[ $key ] ) ? $in[ $key ] : array(), 50 ) ) ) );
	}

	$pages = isset( $in['exclude_pages'] ) ? $in['exclude_pages'] : array();
	if ( is_string( $pages ) ) {
		$pages = preg_split( '/[\s,]+/', $pages );
	}
	$out['exclude_pages'] = array_values( array_unique( array_filter( array_map( 'absint', (array) $pages ) ) ) );

	$out['auto_labels'] = $bool( 'auto_labels' );

	$out['link_labels'] = array();
	if ( isset( $in['link_labels'] ) && is_array( $in['link_labels'] ) ) {
		foreach ( $in['link_labels'] as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$url   = isset( $row['url'] ) ? esc_url_raw( trim( (string) $row['url'] ) ) : '';
			$label = isset( $row['label'] ) ? sanitize_text_field( (string) $row['label'] ) : '';
			$lang  = isset( $row['lang'] ) ? sanitize_key( (string) $row['lang'] ) : '';
			if ( '' !== $url && '' !== $label ) {
				$out['link_labels'][] = array(
					'url'   => $url,
					'label' => $label,
					'lang'  => substr( $lang, 0, 5 ),
				);
			}
			if ( count( $out['link_labels'] ) >= 300 ) {
				break;
			}
		}
	}

	// Changes made with the on-page editor. The settings form sends
	// them as one JSON field so a long list never hits PHP's max_input_vars.
	if ( isset( $in['rules_json'] ) && is_string( $in['rules_json'] ) ) {
		$decoded     = json_decode( $in['rules_json'], true ); // options.php has already unslashed it.
		$in['rules'] = is_array( $decoded ) ? $decoded : array();
	}
	$out['rules'] = abt_a11y_sanitize_rules( isset( $in['rules'] ) ? $in['rules'] : array() );

	$out['strings'] = array();
	$strings        = isset( $in['strings'] ) && is_array( $in['strings'] ) ? $in['strings'] : array();
	foreach ( $d['strings'] as $key => $pair ) {
		foreach ( array( 'el', 'en' ) as $lang ) {
			$value                          = isset( $strings[ $key ][ $lang ] ) ? sanitize_text_field( (string) $strings[ $key ][ $lang ] ) : '';
			$out['strings'][ $key ][ $lang ] = '' !== $value ? $value : $pair[ $lang ];
		}
	}

	$out['pause_position'] = isset( $in['pause_position'] ) && in_array( $in['pause_position'], array( 'bottom-right', 'bottom-left', 'top-right', 'top-left' ), true ) ? $in['pause_position'] : $d['pause_position'];
	$out['pause_size']     = isset( $in['pause_size'] ) ? max( 16, min( 80, absint( $in['pause_size'] ) ) ) : $d['pause_size'];
	$out['focus_width']    = isset( $in['focus_width'] ) ? max( 1, min( 8, absint( $in['focus_width'] ) ) ) : $d['focus_width'];
	$out['kill_switch']    = isset( $in['kill_switch'] ) && in_array( $in['kill_switch'], array( 'admins', 'everyone', 'off' ), true ) ? $in['kill_switch'] : $d['kill_switch'];
	$out['optimizer_optout'] = $bool( 'optimizer_optout' );
	$out['delete_data']      = $bool( 'delete_data' );

	return $out;
}

/**
 * Page address used to scope a change to one page: "/", "/about/", "/en/product/x/".
 *
 * @param string $path Path or URL.
 * @return string '' when unusable.
 */
function abt_a11y_clean_path( $path ) {
	$path = (string) $path;
	if ( preg_match( '#^https?://#i', $path ) ) {
		$path = (string) wp_parse_url( $path, PHP_URL_PATH );
	}
	$path = preg_replace( '/[?#].*$/', '', $path );
	if ( preg_match( '/[<>"\'\s]/', $path ) || strlen( $path ) > 400 ) {
		return '';
	}
	$path = trim( $path, '/' );
	return '' === $path ? '/' : '/' . $path . '/';
}

/**
 * @param mixed $rules Raw rules.
 * @return array<int,array{sel:string,kind:string,value:string,scope:string,label:string}>
 */
function abt_a11y_rule_key( $sel, $kind, $scope, $lang ) {
	return $sel . '|' . $kind . '|' . $scope . '|' . $lang;
}

/**
 * Cleans the list of changes made with the on-page editor.
 *
 * @param mixed $rules Raw rules.
 * @return array
 */
function abt_a11y_sanitize_rules( $rules ) {
	$out = array();
	if ( ! is_array( $rules ) ) {
		return $out;
	}
	foreach ( $rules as $r ) {
		if ( ! is_array( $r ) ) {
			continue;
		}
		$sel  = abt_a11y_clean_selector( isset( $r['sel'] ) ? (string) $r['sel'] : '' );
		$kind = isset( $r['kind'] ) && in_array( $r['kind'], array( 'name', 'alt', 'hide', 'color', 'plate' ), true ) ? $r['kind'] : '';
		if ( '' === $sel || '' === $kind ) {
			continue;
		}
		$value = isset( $r['value'] ) ? (string) $r['value'] : '';
		if ( 'color' === $kind ) {
			$value = abt_a11y_hex( $value, '' );
			if ( '' === $value ) {
				continue;
			}
		} elseif ( 'plate' === $kind ) {
			// Backing colour and opacity, e.g. "#1a1a1a@0.6", and an optional glass blur in px: "#1a1a1a@0.4/8".
			if ( ! preg_match( '/^(#?[0-9a-f]{3,6})@(0(?:\.\d{1,2})?|1(?:\.0+)?)(?:\/(\d{1,2}))?$/i', trim( $value ), $m ) || '' === abt_a11y_hex( $m[1], '' ) || (float) $m[2] < 0.01 ) {
				continue;
			}
			$blur  = isset( $m[3] ) ? min( 40, (int) $m[3] ) : 0;
			$value = abt_a11y_hex( $m[1], '' ) . '@' . rtrim( rtrim( number_format( (float) $m[2], 2, '.', '' ), '0' ), '.' ) . ( $blur ? '/' . $blur : '' );
		} else {
			$value = substr( sanitize_text_field( $value ), 0, 300 );
		}
		if ( 'name' === $kind && '' === $value ) {
			continue;
		}
		$scope = isset( $r['scope'] ) ? (string) $r['scope'] : 'site';
		$scope = 'site' === $scope ? 'site' : abt_a11y_clean_path( $scope );
		if ( '' === $scope ) {
			continue;
		}
		// Names and alt texts are written in one language: on a multilingual site they apply
		// only to pages in that language. Colours, backings and hiding apply to every language.
		$lang = '';
		if ( ( 'name' === $kind || 'alt' === $kind ) && isset( $r['lang'] ) && preg_match( '/^[a-z]{2}$/', (string) $r['lang'] ) ) {
			$lang = (string) $r['lang'];
		}
		$key         = abt_a11y_rule_key( $sel, $kind, $scope, $lang );
		$out[ $key ] = array(
			'sel'   => $sel,
			'kind'  => $kind,
			'value' => $value,
			'scope' => $scope,
			'lang'  => $lang,
			'label' => isset( $r['label'] ) ? substr( sanitize_text_field( (string) $r['label'] ), 0, 120 ) : '',
		);
	}
	return array_slice( array_values( $out ), -3000 );
}

/**
 * An older, site-specific fix that does the same job (e.g. the karabinis-a11y-fixes
 * mu-plugin). While it runs, this plugin stays out of the way so nothing is fixed twice.
 *
 * @return string Human-readable name of the conflicting code, or '' if none.
 */
function abt_a11y_conflict() {
	if ( defined( 'KM_A11Y_LOADED' ) && ! ( defined( 'KM_A11Y_DISABLE' ) && KM_A11Y_DISABLE ) ) {
		return 'wp-content/mu-plugins/karabinis-a11y-fixes.php';
	}
	return (string) apply_filters( 'abt_a11y_conflict', '' );
}

/**
 * Settings API callback: a saved form has every checkbox it shows, so a missing
 * key there means "unchecked".
 *
 * @param mixed $input
 * @return array
 */
function abt_a11y_sanitize_option( $input ) {
	return abt_a11y_sanitize( is_array( $input ) ? $input : array(), false );
}
