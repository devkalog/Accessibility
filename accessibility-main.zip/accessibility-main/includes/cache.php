<?php
/**
 * Empties the page caches of common caching plugins and hosts.
 *
 * Cached pages hold the plugin's script and settings. They are emptied when the plugin is
 * activated, deactivated or deleted, so visitors get the site with (or without) the
 * plugin right away and no cached page keeps loading files that are no longer there.
 * Also loaded by uninstall.php, when the rest of the plugin is not.
 *
 * @package Aboutnet_A11y
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'abt_a11y_purge_page_caches' ) ) {
	/**
	 * Purges every page cache it recognises. Each call is guarded: plugins that are not
	 * installed are skipped, and an error in one of them does not stop the others.
	 */
	function abt_a11y_purge_page_caches() {
		$calls = array(
			// WP Rocket.
			function () {
				if ( function_exists( 'rocket_clean_domain' ) ) {
					rocket_clean_domain();
				}
				if ( function_exists( 'rocket_clean_minify' ) ) {
					rocket_clean_minify();
				}
			},
			// W3 Total Cache.
			function () {
				if ( function_exists( 'w3tc_flush_all' ) ) {
					w3tc_flush_all();
				}
			},
			// WP Super Cache.
			function () {
				if ( function_exists( 'wp_cache_clear_cache' ) ) {
					wp_cache_clear_cache();
				}
			},
			// Autoptimize.
			function () {
				if ( class_exists( 'autoptimizeCache' ) && method_exists( 'autoptimizeCache', 'clearall' ) ) {
					autoptimizeCache::clearall();
				}
			},
			// SiteGround Optimizer.
			function () {
				if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
					sg_cachepress_purge_cache();
				}
			},
			// WP-Optimize.
			function () {
				if ( function_exists( 'wpo_cache_flush' ) ) {
					wpo_cache_flush();
				}
			},
			// Swift Performance.
			function () {
				if ( class_exists( 'Swift_Performance_Cache' ) && method_exists( 'Swift_Performance_Cache', 'clear_all_cache' ) ) {
					Swift_Performance_Cache::clear_all_cache();
				}
			},
			// WP Engine.
			function () {
				if ( class_exists( 'WpeCommon' ) ) {
					if ( method_exists( 'WpeCommon', 'purge_memcached' ) ) {
						WpeCommon::purge_memcached();
					}
					if ( method_exists( 'WpeCommon', 'purge_varnish_cache' ) ) {
						WpeCommon::purge_varnish_cache();
					}
				}
			},
			// Plugins that purge on an action: LiteSpeed Cache, Cache Enabler, Breeze,
			// WP Fastest Cache, Nginx Helper, Hummingbird.
			function () {
				foreach ( array( 'litespeed_purge_all', 'cache_enabler_clear_complete_cache', 'breeze_clear_all_cache', 'wpfc_clear_all_cache', 'rt_nginx_helper_purge_all', 'wphb_clear_page_cache' ) as $action ) {
					if ( has_action( $action ) ) {
						do_action( $action );
					}
				}
			},
		);
		foreach ( $calls as $call ) {
			try {
				$call();
			} catch ( Throwable $e ) {
				continue;
			}
		}
		/**
		 * After the plugin has asked the known caches to empty. Hook here for a host
		 * cache it does not know (Varnish, Cloudflare, a CDN).
		 */
		do_action( 'abt_a11y_purge_caches' );
	}
}
