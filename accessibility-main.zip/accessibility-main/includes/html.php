<?php
/**
 * A small, fast HTML reader for the permanent mode.
 *
 * It reads the finished page once (tags, attributes, text) and builds a light element
 * tree with the parts of the HTML parsing rules that matter for the fixes (void elements,
 * implied end tags, raw text such as scripts, SVG/MathML). Changes are recorded against
 * byte offsets and written back by rewriting only the tags that change, so the rest of
 * the page leaves the server byte for byte as the theme produced it. Nothing is ever
 * re-serialised from a DOM, which is how DOM-based rewriting usually breaks markup.
 *
 * @package Aboutnet_A11y
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ABT_A11y_Html {

	const VOID = array(
		'area'   => 1,
		'base'   => 1,
		'br'     => 1,
		'col'    => 1,
		'embed'  => 1,
		'hr'     => 1,
		'img'    => 1,
		'input'  => 1,
		'keygen' => 1,
		'link'   => 1,
		'meta'   => 1,
		'param'  => 1,
		'source' => 1,
		'track'  => 1,
		'wbr'    => 1,
	);

	// Elements whose content is not markup. Text counts as text content, except in <template>.
	const RAW = array(
		'script'    => 1,
		'style'     => 1,
		'textarea'  => 1,
		'title'     => 1,
		'xmp'       => 1,
		'iframe'    => 1,
		'noembed'   => 1,
		'noframes'  => 1,
		'noscript'  => 1,
		'template'  => 1,
		'plaintext' => 1,
	);

	// Start tags that close an open <p>.
	const CLOSES_P = array(
		'address'    => 1,
		'article'    => 1,
		'aside'      => 1,
		'blockquote' => 1,
		'details'    => 1,
		'dialog'     => 1,
		'div'        => 1,
		'dl'         => 1,
		'fieldset'   => 1,
		'figcaption' => 1,
		'figure'     => 1,
		'footer'     => 1,
		'form'       => 1,
		'h1'         => 1,
		'h2'         => 1,
		'h3'         => 1,
		'h4'         => 1,
		'h5'         => 1,
		'h6'         => 1,
		'header'     => 1,
		'hgroup'     => 1,
		'hr'         => 1,
		'main'       => 1,
		'menu'       => 1,
		'nav'        => 1,
		'ol'         => 1,
		'p'          => 1,
		'pre'        => 1,
		'section'    => 1,
		'summary'    => 1,
		'table'      => 1,
		'ul'         => 1,
		'li'         => 1,
		'dd'         => 1,
		'dt'         => 1,
	);

	// HTML start tags that end SVG/MathML content.
	const BREAKOUT = array(
		'b'          => 1,
		'big'        => 1,
		'blockquote' => 1,
		'body'       => 1,
		'br'         => 1,
		'center'     => 1,
		'code'       => 1,
		'dd'         => 1,
		'div'        => 1,
		'dl'         => 1,
		'dt'         => 1,
		'em'         => 1,
		'embed'      => 1,
		'h1'         => 1,
		'h2'         => 1,
		'h3'         => 1,
		'h4'         => 1,
		'h5'         => 1,
		'h6'         => 1,
		'head'       => 1,
		'hr'         => 1,
		'i'          => 1,
		'img'        => 1,
		'li'         => 1,
		'listing'    => 1,
		'menu'       => 1,
		'meta'       => 1,
		'nobr'       => 1,
		'ol'         => 1,
		'p'          => 1,
		'pre'        => 1,
		'ruby'       => 1,
		's'          => 1,
		'small'      => 1,
		'span'       => 1,
		'strong'     => 1,
		'strike'     => 1,
		'sub'        => 1,
		'sup'        => 1,
		'table'      => 1,
		'tt'         => 1,
		'u'          => 1,
		'ul'         => 1,
		'var'        => 1,
	);

	const HEADING = array(
		'h1' => 1,
		'h2' => 1,
		'h3' => 1,
		'h4' => 1,
		'h5' => 1,
		'h6' => 1,
	);

	const SCOPE = array(
		'button'   => 1,
		'table'    => 1,
		'td'       => 1,
		'th'       => 1,
		'caption'  => 1,
		'html'     => 1,
		'template' => 1,
		'object'   => 1,
		'marquee'  => 1,
		'svg'      => 1,
		'math'     => 1,
	);

	/** @var string */
	public $html;

	/**
	 * Nodes in document order. Elements: tag, s/e (opening tag), cs (closing tag start or -1),
	 * ce, attrs (name => decoded value, first wins), spans (name => [start, end] of the raw
	 * attribute), ne (end of the tag name), p (parent), last (last descendant), fg (in SVG/MathML).
	 * Text: tag '#text', s/e, p.
	 *
	 * @var array<int,array>
	 */
	public $nodes = array();

	/** @var array<int,bool> Element => has non-blank text somewhere inside. */
	public $text = array();

	/** @var array<string,int> First element with each id. */
	public $ids = array();

	/** @var array<string,int[]> Elements by tag name. */
	public $by_tag = array();

	/** @var array<int,array> Pending edits per element. */
	private $edits = array();

	/** @var array<int,int[]> Lazily built child lists. */
	private $kids = array();

	/** @var bool */
	public $ok = false;

	/** @var array<string,int> How many elements of each tag are open, to skip stack scans. */
	private $open_count = array();

	/**
	 * @param string $html
	 */
	public function __construct( $html ) {
		$this->html = (string) $html;
		$this->ok   = $this->parse();
	}

	/* ------------------------------------------------------------------ *
	 * Parsing
	 * ------------------------------------------------------------------ */

	private function parse() {
		$h     = $this->html;
		$len   = strlen( $h );
		$pos   = 0;
		$stack = array();
		$text_start = 0;

		while ( $pos < $len ) {
			$lt = strpos( $h, '<', $pos );
			if ( false === $lt ) {
				break;
			}
			$next = $lt + 1 < $len ? $h[ $lt + 1 ] : '';
			if ( '!' === $next ) {
				$this->add_text( $text_start, $lt, $stack );
				if ( 0 === substr_compare( $h, '<!--', $lt, 4 ) ) {
					$end = strpos( $h, '-->', $lt + 4 );
					$pos = false === $end ? $len : $end + 3;
				} else {
					$end = strpos( $h, '>', $lt + 2 );
					$pos = false === $end ? $len : $end + 1;
				}
				$text_start = $pos;
				continue;
			}
			if ( '?' === $next ) {
				$this->add_text( $text_start, $lt, $stack );
				$end        = strpos( $h, '>', $lt + 2 );
				$pos        = false === $end ? $len : $end + 1;
				$text_start = $pos;
				continue;
			}
			if ( '/' === $next ) {
				if ( ! preg_match( '/\G<\/([a-zA-Z][^\s\/>]*)[^>]*>/', $h, $m, 0, $lt ) ) {
					if ( preg_match( '/\G<\/[^a-zA-Z>][^>]*>/', $h, $m2, 0, $lt ) || preg_match( '/\G<\/>/', $h, $m2, 0, $lt ) ) {
						$this->add_text( $text_start, $lt, $stack );
						$pos        = $lt + strlen( $m2[0] );
						$text_start = $pos;
						continue;
					}
					$pos = $lt + 1;
					continue;
				}
				$this->add_text( $text_start, $lt, $stack );
				$this->close( strtolower( $m[1] ), $lt, $lt + strlen( $m[0] ), $stack );
				$pos        = $lt + strlen( $m[0] );
				$text_start = $pos;
				continue;
			}
			// The whole start tag in one match, attributes as the HTML tokenizer reads them.
			if ( ! preg_match( '/\G<([a-zA-Z][^\s\/>]*)((?:[\s\/]*+(?:[^\s\/>=][^\s\/>=]*+|=[^\s\/>=]*+)(?:\s*+=\s*+(?:"[^"]*+"|\'[^\']*+\'|[^\s>]*+))?+)*+)([\s\/]*+)>/', $h, $m, 0, $lt ) ) {
				if ( preg_match( '/\G<[a-zA-Z]/', $h, $mx, 0, $lt ) ) {
					// End of file inside a tag: the browser drops it.
					$this->add_text( $text_start, $lt, $stack );
					$text_start = $len;
					break;
				}
				$pos = $lt + 1; // A "<" that starts no tag is text.
				continue;
			}
			$tag    = strtolower( $m[1] );
			$name_e = $lt + 1 + strlen( $m[1] );
			$p      = $lt + strlen( $m[0] );
			$self   = false !== strpos( $m[3], '/' ) && '/' === substr( rtrim( $m[3] ), -1 );
			$attrs = '' === $m[2] ? array() : self::read_attrs( $m[2] );
			$spans = null; // Attribute positions are only worked out for tags that change.
			$this->add_text( $text_start, $lt, $stack );
			$idx        = $this->open( $tag, $lt, $p, $name_e, $attrs, $spans, $self, $stack );
			$pos        = $p;
			$text_start = $pos;

			$foreign = ! empty( $this->nodes[ $idx ]['fg'] );
			if ( isset( self::RAW[ $tag ] ) && ( ! $foreign || 'script' === $tag || 'style' === $tag ) && empty( $this->nodes[ $idx ]['void'] ) ) {
				if ( 'plaintext' === $tag ) {
					$end = $len;
				} else {
					$end = $this->find_closer( $tag, $pos );
				}
				if ( 'template' !== $tag ) {
					$this->add_raw_text( $pos, false === $end ? $len : $end, $idx );
				}
				if ( false === $end || $end >= $len ) {
					$pos = $len;
				} else {
					preg_match( '/\G<\/[a-zA-Z][^\s\/>]*[^>]*>?/', $h, $mc, 0, $end );
					$close_end = $end + ( $mc ? strlen( $mc[0] ) : 0 );
					$this->close( $tag, $end, $close_end, $stack );
					$pos = $close_end;
				}
				$text_start = $pos;
			}
		}
		$this->add_text( $text_start, $len, $stack );
		while ( $stack ) {
			$top                        = array_pop( $stack );
			$this->nodes[ $top ]['last'] = count( $this->nodes ) - 1;
		}

		// Text flags, bottom-up: nodes come in document order, so children follow parents.
		for ( $i = count( $this->nodes ) - 1; $i >= 0; $i-- ) {
			$n = $this->nodes[ $i ];
			if ( '#text' === $n['tag'] ) {
				if ( $n['p'] >= 0 ) {
					$this->text[ $n['p'] ] = true;
				}
			} elseif ( ! empty( $this->text[ $i ] ) && $n['p'] >= 0 ) {
				$this->text[ $n['p'] ] = true;
			}
		}
		return true;
	}

	const ATTR_RE = '/([\s\/]*)([^\s\/>=][^\s\/>=]*|=[^\s\/>=]*)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]*)))?/';

	/**
	 * Attributes of a start tag (the text after the tag name), decoded; the first of a
	 * repeated name wins, as in the browser.
	 *
	 * @param string $raw
	 * @return array<string,string>
	 */
	private static function read_attrs( $raw ) {
		$attrs = array();
		if ( preg_match_all( self::ATTR_RE, $raw, $all, PREG_SET_ORDER ) ) {
			foreach ( $all as $mm ) {
				$name = strtolower( $mm[2] );
				if ( isset( $attrs[ $name ] ) ) {
					continue;
				}
				if ( isset( $mm[3] ) && '' !== $mm[3] ) {
					$v = $mm[3];
				} elseif ( isset( $mm[4] ) && '' !== $mm[4] ) {
					$v = $mm[4];
				} elseif ( isset( $mm[5] ) ) {
					$v = $mm[5];
				} else {
					$v = '';
				}
				$attrs[ $name ] = false === strpos( $v, '&' ) ? $v : html_entity_decode( $v, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
			}
		}
		return $attrs;
	}

	/**
	 * Byte positions of each attribute in a start tag, for rewriting it.
	 *
	 * @return array<string,int[]>
	 */
	private function spans( $n ) {
		$spans = array();
		$raw   = substr( $this->html, $n['ne'], $n['e'] - $n['ne'] );
		if ( preg_match_all( self::ATTR_RE, $raw, $all, PREG_SET_ORDER | PREG_OFFSET_CAPTURE ) ) {
			foreach ( $all as $mm ) {
				$name = strtolower( $mm[2][0] );
				if ( ! isset( $spans[ $name ] ) ) {
					$spans[ $name ] = array( $n['ne'] + $mm[0][1] + strlen( $mm[1][0] ), $n['ne'] + $mm[0][1] + strlen( $mm[0][0] ) );
				}
			}
		}
		return $spans;
	}

	private function find_closer( $tag, $from ) {
		// A regex, not stripos(): before PHP 8.2 stripos() lowercases the rest of the page on every call.
		if ( preg_match( '#</' . $tag . '[\s/>]#i', $this->html, $m, PREG_OFFSET_CAPTURE, $from ) ) {
			return $m[0][1];
		}
		return false;
	}

	private function add_text( $s, $e, $stack ) {
		if ( $e <= $s || strspn( $this->html, " \t\n\r\f", $s, $e - $s ) === $e - $s ) {
			return;
		}
		if ( ! self::blank( substr( $this->html, $s, $e - $s ) ) ) {
			$this->nodes[] = array(
				'tag' => '#text',
				's'   => $s,
				'e'   => $e,
				'p'   => $stack ? end( $stack ) : -1,
			);
		}
	}

	private function add_raw_text( $s, $e, $parent ) {
		if ( $e > $s && ! self::blank( substr( $this->html, $s, $e - $s ), true ) ) {
			$this->nodes[] = array(
				'tag' => '#text',
				's'   => $s,
				'e'   => $e,
				'p'   => $parent,
				'raw' => true,
			);
		}
	}

	/**
	 * Whether a stretch of text is empty for the purpose of "has text": only whitespace,
	 * including no-break spaces, as the browser's textContent with \s removed.
	 *
	 * @param string $s
	 * @param bool   $raw Raw text is not decoded.
	 * @return bool
	 */
	public static function blank( $s, $raw = false ) {
		if ( ! $raw && false !== strpos( $s, '&' ) ) {
			$s = html_entity_decode( $s, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
		}
		if ( ! preg_match( '/[^\s]/', $s ) ) {
			return true;
		}
		return ! preg_match( '/[^\s\x{00A0}\x{1680}\x{2000}-\x{200A}\x{2028}\x{2029}\x{202F}\x{205F}\x{3000}\x{FEFF}]/u', $s );
	}

	private function in_scope( $stack, $tag, $extra = array() ) {
		if ( empty( $this->open_count[ $tag ] ) ) {
			return -1;
		}
		for ( $i = count( $stack ) - 1; $i >= 0; $i-- ) {
			$t = $this->nodes[ $stack[ $i ] ]['tag'];
			if ( $t === $tag ) {
				return $i;
			}
			if ( isset( self::SCOPE[ $t ] ) || isset( $extra[ $t ] ) ) {
				return -1;
			}
		}
		return -1;
	}

	private function pop_to( &$stack, $i, $closer_s = -1, $closer_e = -1 ) {
		$last = count( $this->nodes ) - 1;
		while ( count( $stack ) > $i ) {
			$top                        = array_pop( $stack );
			$this->nodes[ $top ]['last'] = $last;
			$this->open_count[ $this->nodes[ $top ]['tag'] ]--;
			if ( count( $stack ) === $i && $closer_s >= 0 ) {
				$this->nodes[ $top ]['cs'] = $closer_s;
				$this->nodes[ $top ]['ce'] = $closer_e;
			}
		}
	}

	private function open( $tag, $s, $e, $name_e, $attrs, $spans, $self, &$stack ) {
		$parent_fg      = false;
		$closed_heading = false;
		if ( $stack ) {
			$top       = $this->nodes[ end( $stack ) ];
			$parent_fg = ! empty( $top['fg'] ) || 'svg' === $top['tag'] || 'math' === $top['tag'];
		}
		if ( $parent_fg && isset( self::BREAKOUT[ $tag ] ) ) {
			for ( $i = count( $stack ) - 1; $i >= 0; $i-- ) {
				$n = $this->nodes[ $stack[ $i ] ];
				if ( empty( $n['fg'] ) && 'svg' !== $n['tag'] && 'math' !== $n['tag'] ) {
					break;
				}
			}
			$this->pop_to( $stack, $i + 1 );
			$parent_fg = false;
		}
		if ( ! $parent_fg ) {
			if ( isset( self::CLOSES_P[ $tag ] ) ) {
				$i = $this->in_scope( $stack, 'p' );
				if ( $i >= 0 ) {
					$this->pop_to( $stack, $i );
				}
			}
			if ( 'li' === $tag ) {
				$i = $this->in_scope( $stack, 'li', array( 'ol' => 1, 'ul' => 1 ) );
				if ( $i >= 0 ) {
					$this->pop_to( $stack, $i );
				}
			} elseif ( 'dd' === $tag || 'dt' === $tag ) {
				foreach ( array( 'dd', 'dt' ) as $t ) {
					$i = $this->in_scope( $stack, $t, array( 'dl' => 1 ) );
					if ( $i >= 0 ) {
						$this->pop_to( $stack, $i );
					}
				}
			} elseif ( 'option' === $tag || 'optgroup' === $tag ) {
				if ( $stack && 'option' === $this->nodes[ end( $stack ) ]['tag'] ) {
					$this->pop_to( $stack, count( $stack ) - 1 );
				}
				if ( 'optgroup' === $tag && $stack && 'optgroup' === $this->nodes[ end( $stack ) ]['tag'] ) {
					$this->pop_to( $stack, count( $stack ) - 1 );
				}
			} elseif ( 'tr' === $tag || 'td' === $tag || 'th' === $tag || 'tbody' === $tag || 'thead' === $tag || 'tfoot' === $tag ) {
				$targets = 'tr' === $tag ? array( 'td', 'th', 'tr' ) : ( 'td' === $tag || 'th' === $tag ? array( 'td', 'th' ) : array( 'td', 'th', 'tr', 'tbody', 'thead', 'tfoot' ) );
				for ( $i = count( $stack ) - 1; $i >= 0; $i-- ) {
					$t = $this->nodes[ $stack[ $i ] ]['tag'];
					if ( 'table' === $t ) {
						break;
					}
					if ( in_array( $t, $targets, true ) ) {
						$this->pop_to( $stack, $i );
						break;
					}
				}
			} elseif ( 'a' === $tag ) {
				$i = $this->in_scope( $stack, 'a' );
				if ( $i >= 0 ) {
					$this->pop_to( $stack, $i );
				}
			} elseif ( 'button' === $tag ) {
				$i = $this->in_scope( $stack, 'button' );
				if ( $i >= 0 ) {
					$this->pop_to( $stack, $i );
				}
			} elseif ( isset( self::HEADING[ $tag ] ) && $stack && isset( self::HEADING[ $this->nodes[ end( $stack ) ]['tag'] ] ) ) {
				$this->pop_to( $stack, count( $stack ) - 1 );
				$closed_heading = true;
			}
		}

		$idx           = count( $this->nodes );
		$void          = ( ! $parent_fg && 'svg' !== $tag && 'math' !== $tag ) ? isset( self::VOID[ $tag ] ) : $self;
		if ( ( 'svg' === $tag || 'math' === $tag ) && $self ) {
			$void = true;
		}
		$this->nodes[] = array(
			'tag'   => $tag,
			's'     => $s,
			'e'     => $e,
			'ne'    => $name_e,
			'attrs' => $attrs,
			'spans' => $spans,
			'p'     => $stack ? end( $stack ) : -1,
			'last'  => $idx,
			'cs'    => -1,
			'ce'    => -1,
			'fg'    => $parent_fg,
			'void'  => $void,
			'hc'    => $closed_heading,
		);
		$this->by_tag[ $tag ][] = $idx;
		if ( isset( $attrs['id'] ) && '' !== $attrs['id'] && ! isset( $this->ids[ $attrs['id'] ] ) ) {
			$this->ids[ $attrs['id'] ] = $idx;
		}
		if ( ! $void ) {
			$stack[] = $idx;
			$this->open_count[ $tag ] = isset( $this->open_count[ $tag ] ) ? $this->open_count[ $tag ] + 1 : 1;
		}
		return $idx;
	}

	private function close( $tag, $s, $e, &$stack ) {
		if ( empty( $this->open_count[ $tag ] ) ) {
			return;
		}
		for ( $i = count( $stack ) - 1; $i >= 0; $i-- ) {
			if ( $this->nodes[ $stack[ $i ] ]['tag'] === $tag ) {
				$this->pop_to( $stack, $i, $s, $e );
				return;
			}
		}
	}

	/* ------------------------------------------------------------------ *
	 * Reading
	 * ------------------------------------------------------------------ */

	public function is_el( $i ) {
		return isset( $this->nodes[ $i ] ) && '#text' !== $this->nodes[ $i ]['tag'];
	}

	public function tag( $i ) {
		return $this->nodes[ $i ]['tag'];
	}

	public function parent( $i ) {
		return $this->nodes[ $i ]['p'];
	}

	public function has( $i, $name ) {
		return array_key_exists( $name, $this->nodes[ $i ]['attrs'] );
	}

	/**
	 * @return string|null
	 */
	public function attr( $i, $name ) {
		return array_key_exists( $name, $this->nodes[ $i ]['attrs'] ) ? (string) $this->nodes[ $i ]['attrs'][ $name ] : null;
	}

	public function non_empty( $i, $name ) {
		$v = $this->attr( $i, $name );
		return null !== $v && '' !== trim( $v );
	}

	public function has_text( $i ) {
		return ! empty( $this->text[ $i ] );
	}

	/**
	 * Element indices inside $i, in document order.
	 *
	 * @return int[]
	 */
	public function descendants( $i, $tags = null ) {
		$out  = array();
		$last = $this->nodes[ $i ]['last'];
		if ( null !== $tags ) {
			foreach ( (array) $tags as $t ) {
				if ( empty( $this->by_tag[ $t ] ) ) {
					continue;
				}
				$list = $this->by_tag[ $t ];
				// The list is in document order: find the first index after $i.
				$lo = 0;
				$hi = count( $list );
				while ( $lo < $hi ) {
					$mid = ( $lo + $hi ) >> 1;
					if ( $list[ $mid ] <= $i ) {
						$lo = $mid + 1;
					} else {
						$hi = $mid;
					}
				}
				for ( $k = $lo, $n = count( $list ); $k < $n && $list[ $k ] <= $last; $k++ ) {
					$out[] = $list[ $k ];
				}
			}
			if ( count( (array) $tags ) > 1 ) {
				sort( $out );
			}
			return $out;
		}
		for ( $j = $i + 1; $j <= $last; $j++ ) {
			if ( '#text' !== $this->nodes[ $j ]['tag'] ) {
				$out[] = $j;
			}
		}
		return $out;
	}

	public function children( $i ) {
		if ( isset( $this->kids[ $i ] ) ) {
			return $this->kids[ $i ];
		}
		$out  = array();
		$last = $this->nodes[ $i ]['last'];
		for ( $j = $i + 1; $j <= $last; ) {
			$n = $this->nodes[ $j ];
			if ( '#text' === $n['tag'] ) {
				$j++;
				continue;
			}
			$out[] = $j;
			$j     = $n['last'] + 1;
		}
		$this->kids[ $i ] = $out;
		return $out;
	}

	public function contains( $outer, $inner ) {
		return $inner > $outer && $inner <= $this->nodes[ $outer ]['last'];
	}

	/**
	 * Closest ancestor-or-self with one of the tags.
	 *
	 * @param int      $i
	 * @param string[] $tags
	 * @return int -1 if none.
	 */
	public function closest( $i, $tags ) {
		for ( $e = $i; $e >= 0; $e = $this->nodes[ $e ]['p'] ) {
			if ( in_array( $this->nodes[ $e ]['tag'], $tags, true ) ) {
				return $e;
			}
		}
		return -1;
	}

	/**
	 * The text content of an element, decoded, whitespace collapsed.
	 *
	 * @return string
	 */
	public function text_of( $i ) {
		$last = $this->nodes[ $i ]['last'];
		$out  = '';
		$more = '';
		for ( $j = $i + 1; $j <= $last; $j++ ) {
			$n = $this->nodes[ $j ];
			if ( '#text' === $n['tag'] ) {
				$t    = substr( $this->html, $n['s'], $n['e'] - $n['s'] );
				$out .= empty( $n['raw'] ) && false !== strpos( $t, '&' ) ? html_entity_decode( $t, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) : $t;
			} elseif ( isset( $this->edits[ $j ]['append_text'] ) ) {
				$more .= ' ' . $this->edits[ $j ]['append_text'];
			}
		}
		if ( isset( $this->edits[ $i ]['append_text'] ) ) {
			$more .= ' ' . $this->edits[ $i ]['append_text'];
		}
		return self::clean( $out . $more );
	}

	public static function esc( $s ) {
		return htmlspecialchars( (string) $s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
	}

	public static function clean( $s ) {
		$s = preg_replace( '/[\s\x{00A0}\x{1680}\x{2000}-\x{200A}\x{2028}\x{2029}\x{202F}\x{205F}\x{3000}\x{FEFF}]+/u', ' ', (string) $s );
		return trim( null === $s ? '' : $s );
	}

	/** Index among the element children of its parent with the same tag (1-based). */
	public function nth_of_type( $i, $from_end = false ) {
		$p = $this->nodes[ $i ]['p'];
		if ( $p < 0 ) {
			return 1;
		}
		$k    = 0;
		$pos  = 0;
		$tag  = $this->nodes[ $i ]['tag'];
		$list = $this->children( $p );
		foreach ( $list as $c ) {
			if ( $this->nodes[ $c ]['tag'] === $tag ) {
				$k++;
				if ( $c === $i ) {
					$pos = $k;
				}
			}
		}
		return $from_end ? $k - $pos + 1 : $pos;
	}

	public function nth_child( $i, $from_end = false ) {
		$p = $this->nodes[ $i ]['p'];
		if ( $p < 0 ) {
			return 1;
		}
		$list = $this->children( $p );
		$pos  = array_search( $i, $list, true );
		return $from_end ? count( $list ) - $pos : $pos + 1;
	}

	/* ------------------------------------------------------------------ *
	 * Changes
	 * ------------------------------------------------------------------ */

	public function set( $i, $name, $value ) {
		$this->nodes[ $i ]['attrs'][ $name ] = (string) $value;
		$this->edits[ $i ]['set'][ $name ]   = (string) $value;
		unset( $this->edits[ $i ]['remove'][ $name ] );
		if ( 'id' === $name && '' !== $value && ! isset( $this->ids[ $value ] ) ) {
			$this->ids[ $value ] = $i;
		}
	}

	public function remove( $i, $name ) {
		if ( ! array_key_exists( $name, $this->nodes[ $i ]['attrs'] ) ) {
			return;
		}
		unset( $this->nodes[ $i ]['attrs'][ $name ] );
		unset( $this->edits[ $i ]['set'][ $name ] );
		$this->edits[ $i ]['remove'][ $name ] = true;
	}

	/**
	 * Adds visually hidden text at the end of an element (a label for screen readers).
	 */
	public function append_sr_text( $i, $text ) {
		// Never inside SVG/MathML: an HTML <span> there would end the SVG and change how the
		// rest of the page is read.
		if ( ! empty( $this->nodes[ $i ]['fg'] ) || isset( self::RAW[ $this->nodes[ $i ]['tag'] ] ) ) {
			return false;
		}
		$this->edits[ $i ]['append']      = '<span class="abt-a11y-sr" data-abt-a11y="label-text">' . self::esc( $text ) . '</span>';
		$this->edits[ $i ]['append_text'] = $text;
		for ( $e = $i; $e >= 0; $e = $this->nodes[ $e ]['p'] ) {
			$this->text[ $e ] = true;
		}
		return true;
	}

	public function has_appended( $i ) {
		return isset( $this->edits[ $i ]['append'] );
	}

	/**
	 * Renames an element, opening and closing tag. Only when its closing tag is in the source.
	 */
	public function rename( $i, $tag ) {
		$n = $this->nodes[ $i ];
		// Only where the browser is certain to read the renamed element the same way: its own
		// closing tag is in the source, it did not close another heading by opening, and there
		// is no heading or stray closing tag of the new name inside.
		if ( $n['cs'] < 0 || ! empty( $n['fg'] ) || ! empty( $n['hc'] ) || ! preg_match( '#^</' . preg_quote( $n['tag'], '#' ) . '[\s>]#i', substr( $this->html, $n['cs'], 5 ) . '>' ) ) {
			return false;
		}
		$inner = substr( $this->html, $n['e'], $n['cs'] - $n['e'] );
		if ( false !== stripos( $inner, '</' . $tag ) || preg_match( '#</?h[1-6][\s/>]#i', $inner ) ) {
			return false;
		}
		// Everything inside must be closed by its own tag: a heading's closing tag also closes
		// elements left open inside it, a </div> would not.
		for ( $j = $i + 1; $j <= $n['last']; $j++ ) {
			$c = $this->nodes[ $j ];
			if ( '#text' !== $c['tag'] && empty( $c['void'] ) && $c['cs'] < 0 ) {
				return false;
			}
		}
		$this->edits[ $i ]['rename'] = $tag;
		$this->nodes[ $i ]['tag']    = $tag;
		return true;
	}

	public function is_foreign( $i ) {
		return ! empty( $this->nodes[ $i ]['fg'] );
	}

	public function changed() {
		return ! empty( $this->edits );
	}

	/**
	 * The page with the changes written in.
	 *
	 * @return string
	 */
	public function output() {
		if ( ! $this->edits ) {
			return $this->html;
		}
		$h       = $this->html;
		$patches = array(); // [start, end, replacement]
		foreach ( $this->edits as $i => $ed ) {
			$n = $this->nodes[ $i ];
			if ( ! empty( $ed['set'] ) || ! empty( $ed['remove'] ) || isset( $ed['rename'] ) ) {
				$patches[] = array( $n['s'], $n['e'], $this->rebuild_open( $n, $ed ) );
			}
			if ( isset( $ed['append'] ) ) {
				$at        = $n['cs'] >= 0 ? $n['cs'] : $n['e'];
				$patches[] = array( $at, $at, $ed['append'] );
			}
			if ( isset( $ed['rename'] ) && $n['cs'] >= 0 ) {
				$patches[] = array( $n['cs'], $n['ce'], '</' . $ed['rename'] . '>' );
			}
		}
		usort(
			$patches,
			function ( $a, $b ) {
				return $a[0] === $b[0] ? $a[1] - $b[1] : $a[0] - $b[0];
			}
		);
		$out = '';
		$pos = 0;
		foreach ( $patches as $p ) {
			if ( $p[0] < $pos ) {
				continue; // Overlapping edits should not happen; never corrupt the page if they do.
			}
			$out .= substr( $h, $pos, $p[0] - $pos ) . $p[2];
			$pos  = $p[1];
		}
		return $out . substr( $h, $pos );
	}

	private function rebuild_open( $n, $ed ) {
		$h          = $this->html;
		$n['spans'] = $this->spans( $n );
		$s     = $n['s'];
		$tag   = substr( $h, $s, $n['e'] - $s );
		$local = array(); // [start, end, replacement], relative to the tag.
		$set   = isset( $ed['set'] ) ? $ed['set'] : array();
		$rm    = isset( $ed['remove'] ) ? $ed['remove'] : array();
		$add   = '';
		foreach ( $set as $name => $value ) {
			$chunk = $name . '="' . self::esc( $value ) . '"';
			if ( isset( $n['spans'][ $name ] ) ) {
				$local[] = array( $n['spans'][ $name ][0] - $s, $n['spans'][ $name ][1] - $s, $chunk );
			} else {
				$add .= ' ' . $chunk;
			}
		}
		foreach ( $rm as $name => $unused ) {
			if ( isset( $n['spans'][ $name ] ) ) {
				$local[] = array( $n['spans'][ $name ][0] - $s, $n['spans'][ $name ][1] - $s, '' );
			}
		}
		// New attributes go after the last attribute (or the tag name), before any "/>".
		$insert_at = $n['ne'] - $s;
		foreach ( $n['spans'] as $span ) {
			$insert_at = max( $insert_at, $span[1] - $s );
		}
		if ( '' !== $add ) {
			$local[] = array( $insert_at, $insert_at, $add );
		}
		if ( isset( $ed['rename'] ) ) {
			$local[] = array( 1, $n['ne'] - $s, $ed['rename'] );
		}
		usort(
			$local,
			function ( $a, $b ) {
				return $b[0] === $a[0] ? $b[1] - $a[1] : $b[0] - $a[0];
			}
		);
		foreach ( $local as $l ) {
			$tag = substr( $tag, 0, $l[0] ) . $l[2] . substr( $tag, $l[1] );
		}
		return $tag;
	}

	/* ------------------------------------------------------------------ *
	 * CSS selectors (the subset the editor and the settings produce)
	 * ------------------------------------------------------------------ */

	/** @var array<string,array|false> */
	private static $parsed = array();

	/**
	 * Every element that matches a selector list, in document order, or null when the
	 * selector uses something this reader does not support (it then runs in the browser only).
	 *
	 * @param string $selector
	 * @return int[]|null
	 */
	public function select( $selector ) {
		$list = self::parse_selector( $selector );
		if ( false === $list ) {
			return null;
		}
		$out = array();
		foreach ( $list as $complex ) {
			$last  = end( $complex );
			$cands = null;
			if ( '' !== $last['tag'] && '*' !== $last['tag'] ) {
				$cands = isset( $this->by_tag[ $last['tag'] ] ) ? $this->by_tag[ $last['tag'] ] : array();
			}
			if ( null === $cands ) {
				$cands = array();
				foreach ( $this->nodes as $i => $n ) {
					if ( '#text' !== $n['tag'] ) {
						$cands[] = $i;
					}
				}
			}
			foreach ( $cands as $i ) {
				if ( ! isset( $out[ $i ] ) && $this->match_complex( $i, $complex, count( $complex ) - 1 ) ) {
					$out[ $i ] = true;
				}
			}
		}
		$out = array_keys( $out );
		sort( $out );
		return $out;
	}

	/**
	 * Whether the element or one of its ancestors matches.
	 */
	public function matches( $i, $selector ) {
		$list = self::parse_selector( $selector );
		if ( false === $list ) {
			return null;
		}
		foreach ( $list as $complex ) {
			if ( $this->match_complex( $i, $complex, count( $complex ) - 1 ) ) {
				return true;
			}
		}
		return false;
	}

	private function match_complex( $i, $complex, $k ) {
		if ( ! $this->match_compound( $i, $complex[ $k ] ) ) {
			return false;
		}
		if ( 0 === $k ) {
			return true;
		}
		$comb = $complex[ $k ]['comb'];
		if ( '>' === $comb ) {
			$p = $this->nodes[ $i ]['p'];
			return $p >= 0 && $this->match_complex( $p, $complex, $k - 1 );
		}
		for ( $p = $this->nodes[ $i ]['p']; $p >= 0; $p = $this->nodes[ $p ]['p'] ) {
			if ( $this->match_complex( $p, $complex, $k - 1 ) ) {
				return true;
			}
		}
		return false;
	}

	private function match_compound( $i, $c ) {
		$n = $this->nodes[ $i ];
		if ( '' !== $c['tag'] && '*' !== $c['tag'] && $n['tag'] !== $c['tag'] ) {
			return false;
		}
		if ( '' !== $c['id'] && ( ! isset( $n['attrs']['id'] ) || $n['attrs']['id'] !== $c['id'] ) ) {
			return false;
		}
		if ( $c['classes'] ) {
			$have = isset( $n['attrs']['class'] ) ? preg_split( '/[\s]+/', trim( $n['attrs']['class'] ) ) : array();
			foreach ( $c['classes'] as $cl ) {
				if ( ! in_array( $cl, $have, true ) ) {
					return false;
				}
			}
		}
		foreach ( $c['attrs'] as $a ) {
			if ( ! array_key_exists( $a[0], $n['attrs'] ) ) {
				return false;
			}
			if ( '' === $a[1] ) {
				continue;
			}
			$v   = (string) $n['attrs'][ $a[0] ];
			$w   = $a[2];
			if ( $a[3] ) {
				$v = strtolower( $v );
				$w = strtolower( $w );
			}
			switch ( $a[1] ) {
				case '=':
					$ok = $v === $w;
					break;
				case '^=':
					$ok = '' !== $w && 0 === strpos( $v, $w );
					break;
				case '$=':
					$ok = '' !== $w && substr( $v, -strlen( $w ) ) === $w;
					break;
				case '*=':
					$ok = '' !== $w && false !== strpos( $v, $w );
					break;
				case '~=':
					$ok = in_array( $w, preg_split( '/\s+/', trim( $v ) ), true );
					break;
				case '|=':
					$ok = $v === $w || 0 === strpos( $v, $w . '-' );
					break;
				default:
					$ok = false;
			}
			if ( ! $ok ) {
				return false;
			}
		}
		foreach ( $c['pseudo'] as $ps ) {
			if ( 'not' === $ps[0] ) {
				foreach ( $ps[1] as $inner ) {
					if ( $this->match_compound( $i, $inner ) ) {
						return false;
					}
				}
				continue;
			}
			if ( 'first-child' === $ps[0] ) {
				$ok = 1 === $this->nth_child( $i );
			} elseif ( 'last-child' === $ps[0] ) {
				$ok = 1 === $this->nth_child( $i, true );
			} elseif ( 'first-of-type' === $ps[0] ) {
				$ok = 1 === $this->nth_of_type( $i );
			} elseif ( 'last-of-type' === $ps[0] ) {
				$ok = 1 === $this->nth_of_type( $i, true );
			} else {
				$pos = 'nth-child' === $ps[0] ? $this->nth_child( $i ) : $this->nth_of_type( $i );
				$ok  = self::an_b( $ps[1], $ps[2], $pos );
			}
			if ( ! $ok ) {
				return false;
			}
		}
		return true;
	}

	private static function an_b( $a, $b, $pos ) {
		if ( 0 === $a ) {
			return $pos === $b;
		}
		$n = ( $pos - $b ) / $a;
		return $n >= 0 && floor( $n ) === $n;
	}

	/**
	 * @param string $selector
	 * @return array|false
	 */
	public static function parse_selector( $selector ) {
		$selector = trim( (string) $selector );
		if ( isset( self::$parsed[ $selector ] ) ) {
			return self::$parsed[ $selector ];
		}
		$result = self::do_parse( $selector );
		if ( count( self::$parsed ) < 500 ) {
			self::$parsed[ $selector ] = $result;
		}
		return $result;
	}

	private static function do_parse( $sel ) {
		if ( '' === $sel || strlen( $sel ) > 600 ) {
			return false;
		}
		$list    = array();
		$complex = array();
		$comb    = ' ';
		$len     = strlen( $sel );
		$p       = 0;
		$ident   = '-?[_a-zA-Z\x80-\xff][_a-zA-Z0-9\x80-\xff-]*';
		while ( $p < $len ) {
			if ( preg_match( '/\G\s*,\s*/', $sel, $m, 0, $p ) ) {
				if ( ! $complex ) {
					return false;
				}
				$list[]  = $complex;
				$complex = array();
				$comb    = ' ';
				$p      += strlen( $m[0] );
				continue;
			}
			if ( preg_match( '/\G\s*>\s*/', $sel, $m, 0, $p ) ) {
				if ( ! $complex ) {
					return false;
				}
				$comb = '>';
				$p   += strlen( $m[0] );
				continue;
			}
			if ( preg_match( '/\G\s*[+~]\s*/', $sel, $m, 0, $p ) ) {
				return false; // Sibling combinators are not supported.
			}
			if ( preg_match( '/\G\s+/', $sel, $m, 0, $p ) ) {
				$comb = ' ';
				$p   += strlen( $m[0] );
				continue;
			}
			$c = self::parse_compound( $sel, $p, $ident );
			if ( false === $c ) {
				return false;
			}
			$c['comb'] = $complex ? $comb : ' ';
			$complex[] = $c;
			$comb      = ' ';
		}
		if ( ! $complex ) {
			return false;
		}
		$list[] = $complex;
		return $list;
	}

	private static function parse_compound( $sel, &$p, $ident ) {
		$c   = array(
			'tag'     => '',
			'id'      => '',
			'classes' => array(),
			'attrs'   => array(),
			'pseudo'  => array(),
		);
		$len = strlen( $sel );
		$any = false;
		if ( preg_match( '/\G(\*|' . $ident . ')/', $sel, $m, 0, $p ) ) {
			$c['tag'] = strtolower( $m[1] );
			$p       += strlen( $m[0] );
			$any      = true;
		}
		while ( $p < $len ) {
			$ch = $sel[ $p ];
			if ( '#' === $ch && preg_match( '/\G#(' . $ident . '|[0-9][_a-zA-Z0-9-]*)/', $sel, $m, 0, $p ) ) {
				$c['id'] = $m[1];
				$p      += strlen( $m[0] );
			} elseif ( '.' === $ch && preg_match( '/\G\.(' . $ident . ')/', $sel, $m, 0, $p ) ) {
				$c['classes'][] = $m[1];
				$p             += strlen( $m[0] );
			} elseif ( '[' === $ch && preg_match( '/\G\[\s*(' . $ident . ')\s*(?:([\^$*~|]?=)\s*(?:"([^"]*)"|\'([^\']*)\'|(' . $ident . '|[0-9]+))\s*(i)?\s*)?\]/', $sel, $m, 0, $p ) ) {
				$val = '';
				foreach ( array( 3, 4, 5 ) as $k ) {
					if ( isset( $m[ $k ] ) && '' !== $m[ $k ] ) {
						$val = $m[ $k ];
						break;
					}
				}
				$name = strtolower( $m[1] );
				// HTML treats these attribute values case-insensitively in selectors.
				$ci             = ! empty( $m[6] ) || in_array( $name, array( 'type', 'lang', 'dir', 'method', 'role' ), true );
				$c['attrs'][]   = array( $name, isset( $m[2] ) ? $m[2] : '', $val, $ci );
				$p             += strlen( $m[0] );
			} elseif ( ':' === $ch && preg_match( '/\G:(first-child|last-child|first-of-type|last-of-type)(?![\w-])/', $sel, $m, 0, $p ) ) {
				$c['pseudo'][] = array( $m[1] );
				$p            += strlen( $m[0] );
			} elseif ( ':' === $ch && preg_match( '/\G:(nth-child|nth-of-type)\(\s*([^)]*)\)/', $sel, $m, 0, $p ) ) {
				$ab = self::parse_an_b( $m[2] );
				if ( ! $ab ) {
					return false;
				}
				$c['pseudo'][] = array( $m[1], $ab[0], $ab[1] );
				$p            += strlen( $m[0] );
			} elseif ( ':' === $ch && preg_match( '/\G:not\(([^()]*)\)/', $sel, $m, 0, $p ) ) {
				$inner = array();
				foreach ( explode( ',', $m[1] ) as $part ) {
					$q  = 0;
					$pt = trim( $part );
					$ic = self::parse_compound( $pt, $q, $ident );
					if ( false === $ic || $q !== strlen( $pt ) ) {
						return false;
					}
					$inner[] = $ic;
				}
				$c['pseudo'][] = array( 'not', $inner );
				$p            += strlen( $m[0] );
			} else {
				break;
			}
			$any = true;
		}
		if ( ! $any ) {
			return false;
		}
		if ( $p < $len && ! preg_match( '/\G[\s,>+~]/', $sel, $m, 0, $p ) ) {
			return false; // Something this reader does not understand (:hover, ::before, …).
		}
		return $c;
	}

	private static function parse_an_b( $s ) {
		$s = strtolower( str_replace( ' ', '', $s ) );
		if ( 'odd' === $s ) {
			return array( 2, 1 );
		}
		if ( 'even' === $s ) {
			return array( 2, 0 );
		}
		if ( preg_match( '/^[+-]?\d+$/', $s ) ) {
			return array( 0, (int) $s );
		}
		if ( preg_match( '/^([+-]?\d*)n([+-]\d+)?$/', $s, $m ) ) {
			$a = '' === $m[1] || '+' === $m[1] ? 1 : ( '-' === $m[1] ? -1 : (int) $m[1] );
			return array( $a, isset( $m[2] ) ? (int) $m[2] : 0 );
		}
		return false;
	}
}
