<?php
/**
 * Front-end: loads the runtime with the saved settings.
 *
 * @package Aboutnet_A11y
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* -------------------------------------------------------------------------
 * When the fixes run
 * ---------------------------------------------------------------------- */

function abt_a11y_is_page_builder_preview() {
	// phpcs:disable WordPress.Security.NonceVerification.Recommended
	// Elementor, Beaver Builder, Divi, Oxygen, Bricks, WPBakery, Thrive, Brizy, Breakdance,
	// the Customizer and the TranslatePress translation editor.
	foreach ( array( 'elementor-preview', 'fl_builder', 'et_fb', 'ct_builder', 'bricks', 'vc_editable', 'tve', 'brizy-edit-iframe', 'breakdance_iframe', 'customize_changeset_uuid', 'trp-edit-translation' ) as $param ) {
		if ( isset( $_GET[ $param ] ) ) {
			return true;
		}
	}
	// phpcs:enable
	if ( function_exists( 'is_customize_preview' ) && is_customize_preview() ) {
		return true;
	}
	if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance ) ) {
		$plugin = \Elementor\Plugin::$instance;
		if ( isset( $plugin->editor ) && is_object( $plugin->editor ) && method_exists( $plugin->editor, 'is_edit_mode' ) && $plugin->editor->is_edit_mode() ) {
			return true;
		}
		if ( isset( $plugin->preview ) && is_object( $plugin->preview ) && method_exists( $plugin->preview, 'is_preview_mode' ) && $plugin->preview->is_preview_mode() ) {
			return true;
		}
	}
	return false;
}

/**
 * ?abt-a11y=off for one request, depending on the "kill switch" setting.
 */
function abt_a11y_switched_off() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( ! isset( $_GET['abt-a11y'] ) || 'off' !== $_GET['abt-a11y'] ) {
		return false;
	}
	$mode = abt_a11y_get_settings()['kill_switch'];
	if ( 'everyone' === $mode ) {
		return true;
	}
	// The page scanner always needs the "before" view.
	return ( 'admins' === $mode || 'off' === $mode ) && current_user_can( 'manage_options' );
}

function abt_a11y_enabled() {
	static $cached = null;
	if ( null !== $cached ) {
		return $cached;
	}
	$s       = abt_a11y_get_settings();
	$enabled = ! empty( $s['enabled'] ) && '' === abt_a11y_conflict();
	if ( $enabled && ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || ( defined( 'WP_CLI' ) && WP_CLI ) ) ) {
		$enabled = false;
	}
	if ( $enabled && did_action( 'wp' ) && ( is_feed() || is_robots() || is_trackback() || is_embed() ) ) {
		$enabled = false;
	}
	if ( $enabled && ( abt_a11y_switched_off() || abt_a11y_is_page_builder_preview() ) ) {
		$enabled = false;
	}
	if ( $enabled && ! empty( $s['exclude_pages'] ) && did_action( 'wp' ) ) {
		$id = get_queried_object_id();
		if ( $id && in_array( (int) $id, $s['exclude_pages'], true ) ) {
			$enabled = false;
		}
	}
	$enabled = (bool) apply_filters( 'abt_a11y_enabled', $enabled );
	if ( did_action( 'wp' ) ) {
		$cached = $enabled; // Page-level checks are only complete once the query has run.
	}
	return $enabled;
}

// The scanner loads pages in an iframe as the logged-in admin: hide the admin bar there.
add_action( 'init', 'abt_a11y_scan_mode', 1 );
function abt_a11y_scan_mode() {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended
	if ( isset( $_GET['abt-a11y-scan'] ) && current_user_can( 'manage_options' ) ) {
		add_filter( 'show_admin_bar', '__return_false', 999 );
	}
}

/* -------------------------------------------------------------------------
 * Visitor language
 * ---------------------------------------------------------------------- */

function abt_a11y_lang() {
	$lang = apply_filters( 'wpml_current_language', null );
	if ( ( ! is_string( $lang ) || '' === $lang ) && function_exists( 'pll_current_language' ) ) {
		$lang = pll_current_language( 'slug' );
	}
	if ( ! is_string( $lang ) || '' === $lang || 'all' === $lang ) {
		$lang = substr( (string) determine_locale(), 0, 2 );
	}
	return strtolower( substr( $lang, 0, 2 ) );
}

/* -------------------------------------------------------------------------
 * Names for image-only links, read from the pages that are rendered.
 * The HTML is only read, never changed.
 * ---------------------------------------------------------------------- */

$GLOBALS['abt_a11y_labels'] = array();

add_filter( 'elementor/frontend/the_content', 'abt_a11y_collect_links', 999 );
add_filter( 'the_content', 'abt_a11y_collect_links', 999 );
add_filter( 'wp_nav_menu', 'abt_a11y_collect_links', 999 );
add_filter( 'widget_text', 'abt_a11y_collect_links', 999 );
add_filter( 'widget_block_content', 'abt_a11y_collect_links', 999 );

/**
 * @param string $html
 * @return string
 */
function abt_a11y_collect_links( $html ) {
	if ( ! is_string( $html ) || '' === $html || is_admin() ) {
		return $html;
	}
	$s = abt_a11y_get_settings();
	if ( empty( $s['auto_labels'] ) || empty( $s['modules']['links'] ) || ! abt_a11y_enabled() ) {
		return $html;
	}
	if ( count( $GLOBALS['abt_a11y_labels'] ) >= 200 || false === stripos( $html, '<a' ) ) {
		return $html;
	}
	if ( ! preg_match_all( '#<a\b([^>]*)>(.*?)</a>#is', $html, $matches, PREG_SET_ORDER ) ) {
		return $html;
	}
	foreach ( $matches as $link ) {
		$attrs = $link[1];
		$inner = $link[2];
		if ( preg_match( '/\baria-label(ledby)?\s*=\s*["\']\s*[^"\'\s]/i', $attrs ) ) {
			continue;
		}
		if ( '' !== trim( html_entity_decode( wp_strip_all_tags( $inner ), ENT_QUOTES, 'UTF-8' ), " \t\n\r\0\x0B\xC2\xA0" ) ) {
			continue;
		}
		if ( preg_match( '/\balt\s*=\s*["\']\s*[^"\'\s]/i', $inner ) ) {
			continue;
		}
		if ( ! preg_match( '/\bhref\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s>]+))/i', $attrs, $h ) ) {
			continue;
		}
		$href = '';
		foreach ( array( 1, 2, 3 ) as $i ) {
			if ( isset( $h[ $i ] ) && '' !== $h[ $i ] ) {
				$href = $h[ $i ];
				break;
			}
		}
		$href = html_entity_decode( $href, ENT_QUOTES, 'UTF-8' );
		if ( '' === $href || '#' === $href[0] || isset( $GLOBALS['abt_a11y_labels'][ $href ] ) ) {
			continue;
		}
		$label = abt_a11y_label_for_url( $href );
		if ( '' !== $label ) {
			$GLOBALS['abt_a11y_labels'][ $href ] = $label;
		}
		if ( count( $GLOBALS['abt_a11y_labels'] ) >= 200 ) {
			break;
		}
	}
	return $html;
}

/**
 * Title of the page, term or brand an internal URL points to ('' if unknown).
 *
 * @param string $url
 * @return string
 */
function abt_a11y_label_for_url( $url ) {
	$url = trim( (string) $url );
	if ( '' === $url ) {
		return '';
	}
	$parts = wp_parse_url( $url );
	if ( ! is_array( $parts ) ) {
		return '';
	}
	$home_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	if ( ! empty( $parts['host'] ) && strtolower( preg_replace( '/^www\./', '', $parts['host'] ) ) !== strtolower( preg_replace( '/^www\./', '', $home_host ) ) ) {
		return '';
	}

	$names = array();
	$path  = isset( $parts['path'] ) ? trim( rawurldecode( $parts['path'] ), '/' ) : '';
	$home  = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
	if ( '' !== $home && 0 === strpos( $path, $home ) ) {
		$path = trim( substr( $path, strlen( $home ) ), '/' );
	}
	$path = abt_a11y_strip_lang_dir( $path );

	if ( '' === $path ) {
		$names[] = (string) get_bloginfo( 'name' );
	} else {
		$post_id = url_to_postid( $url );
		if ( $post_id ) {
			$names[] = wp_strip_all_tags( get_the_title( $post_id ) );
		} else {
			$segments  = explode( '/', $path );
			$term_slug = sanitize_title( end( $segments ) );
			foreach ( get_taxonomies( array( 'public' => true ), 'objects' ) as $tax ) {
				$base = '';
				if ( 'category' === $tax->name ) {
					$base = trim( (string) get_option( 'category_base' ), '/' );
					$base = '' !== $base ? $base : 'category';
				} elseif ( 'post_tag' === $tax->name ) {
					$base = trim( (string) get_option( 'tag_base' ), '/' );
					$base = '' !== $base ? $base : 'tag';
				} elseif ( is_array( $tax->rewrite ) && ! empty( $tax->rewrite['slug'] ) ) {
					$base = trim( $tax->rewrite['slug'], '/' );
				}
				if ( '' === $base || 0 !== strpos( $path . '/', $base . '/' ) ) {
					continue;
				}
				$term = get_term_by( 'slug', $term_slug, $tax->name );
				if ( $term && ! is_wp_error( $term ) ) {
					$names[] = $term->name;
					break;
				}
			}
		}
	}

	// Filter plugins that pass terms in the query string (JetSmartFilters: tax=pwb-brand:37).
	if ( ! empty( $parts['query'] ) ) {
		parse_str( $parts['query'], $query );
		if ( ! empty( $query['tax'] ) && is_string( $query['tax'] ) ) {
			foreach ( explode( ';', $query['tax'] ) as $pair ) {
				$bits = explode( ':', $pair, 2 );
				if ( 2 !== count( $bits ) || ! taxonomy_exists( $bits[0] ) ) {
					continue;
				}
				foreach ( explode( ',', $bits[1] ) as $id ) {
					$term = get_term( (int) $id, $bits[0] );
					if ( $term && ! is_wp_error( $term ) ) {
						$names[] = $term->name;
					}
				}
			}
		}
	}

	$names = array_values( array_unique( array_filter( array_map( 'trim', $names ) ) ) );
	return implode( ' – ', $names );
}

/* -------------------------------------------------------------------------
 * Assets
 * ---------------------------------------------------------------------- */

add_action( 'wp_enqueue_scripts', 'abt_a11y_enqueue', 99 );
function abt_a11y_enqueue() {
	if ( ! abt_a11y_enabled() ) {
		return;
	}
	$css = abt_a11y_front_css( abt_a11y_get_settings() );
	if ( abt_a11y_static_mode() ) {
		$css .= abt_a11y_static_css();
	}
	wp_register_style( 'abt-a11y', false, array(), ABT_A11Y_VERSION );
	wp_enqueue_style( 'abt-a11y' );
	wp_add_inline_style( 'abt-a11y', $css );

	$load = abt_a11y_runtime_load();
	if ( 'none' === $load ) {
		return;
	}
	$src = ABT_A11Y_URL . ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? 'assets/runtime.js' : 'assets/runtime.min.js' );
	if ( 'lazy' === $load ) {
		// Permanent mode: the page is already fixed. The runtime only looks after content that
		// other scripts add later, and the slider pause buttons, so it waits for the page.
		wp_register_script(
			'abt-a11y',
			$src,
			array(),
			ABT_A11Y_VERSION,
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	} else {
		wp_register_script( 'abt-a11y', $src, array(), ABT_A11Y_VERSION, true );
	}
	wp_enqueue_script( 'abt-a11y' );
}

/**
 * How the browser runtime loads on this page.
 *
 * @return string full (fast mode, the on-page editor, the checker) | lazy (permanent mode's
 *                safety net) | none.
 */
function abt_a11y_runtime_load() {
	if ( ! abt_a11y_static_mode() ) {
		return 'full';
	}
	if ( abt_a11y_scan_view( 'nojs' ) ) {
		return 'none';
	}
	if ( abt_a11y_scan_view( 'learn' ) || abt_a11y_inspector_allowed() ) {
		return 'full';
	}
	return abt_a11y_get_settings()['safety_net'] ? 'lazy' : 'none';
}

// Settings go out right before the footer scripts print (priority 20), once the
// header, content, footer and popups have rendered and their links were read.
add_action( 'wp_footer', 'abt_a11y_print_config', 19 );
function abt_a11y_print_config() {
	if ( ! abt_a11y_enabled() || ! wp_script_is( 'abt-a11y', 'enqueued' ) ) {
		return;
	}
	wp_add_inline_script( 'abt-a11y', 'window.abtA11yConfig=' . wp_json_encode( abt_a11y_front_config() ) . ';', 'before' );
}

/**
 * Path of the page being viewed, in the form rules are stored ("/", "/about/").
 *
 * @return string
 */
function abt_a11y_current_path( $raw = false ) {
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- reduced to a clean path below.
	return abt_a11y_path_of( (string) $uri, $raw );
}

/**
 * The stored form of a page address: "/about/", the same for every language.
 *
 * @param string $url URL or path.
 * @param bool   $raw Keep the language directory.
 * @return string
 */
function abt_a11y_path_of( $url, $raw = false ) {
	$path = rawurldecode( (string) wp_parse_url( (string) $url, PHP_URL_PATH ) );
	if ( ! $raw ) {
		// The same page in every language has one path: "/en/about/" is stored as "/about/".
		$home = trim( (string) wp_parse_url( home_url(), PHP_URL_PATH ), '/' );
		$rel  = trim( $path, '/' );
		if ( '' !== $home && 0 === strpos( $rel . '/', $home . '/' ) ) {
			$rel  = trim( substr( $rel, strlen( $home ) ), '/' );
			$path = '/' . $home . '/' . abt_a11y_strip_lang_dir( $rel );
		} else {
			$path = '/' . abt_a11y_strip_lang_dir( $rel );
		}
	}
	$path = abt_a11y_clean_path( $path );
	return '' === $path ? '/' : $path;
}

/**
 * Removes the language directory of WPML, Polylang or TranslatePress from the start of a
 * path relative to the home URL ("en/about" → "about").
 *
 * @param string $path Path without leading or trailing slashes.
 * @return string
 */
function abt_a11y_strip_lang_dir( $path ) {
	if ( ! preg_match( '#^([a-z]{2}(?:[-_][a-z]{2,4})?)(/|$)#i', $path, $m ) ) {
		return $path;
	}
	$dir   = strtolower( $m[1] );
	$langs = array();
	$wpml  = apply_filters( 'wpml_active_languages', null );
	if ( is_array( $wpml ) ) {
		$langs = array_merge( $langs, array_map( 'strtolower', array_keys( $wpml ) ) );
	}
	if ( function_exists( 'pll_languages_list' ) ) {
		$langs = array_merge( $langs, array_map( 'strtolower', (array) pll_languages_list() ) );
	}
	if ( class_exists( 'TRP_Translate_Press' ) ) {
		$trp = get_option( 'trp_settings', array() );
		if ( is_array( $trp ) && ! empty( $trp['url-slugs'] ) && is_array( $trp['url-slugs'] ) ) {
			$langs = array_merge( $langs, array_map( 'strtolower', array_values( $trp['url-slugs'] ) ) );
		}
	}
	if ( ! in_array( $dir, $langs, true ) ) {
		return $path;
	}
	return trim( substr( $path, strlen( $m[1] ) ), '/' );
}

/**
 * @return array
 */
function abt_a11y_front_config() {
	$s    = abt_a11y_get_settings();
	$lang = abt_a11y_lang();

	$labels = $s['auto_labels'] ? $GLOBALS['abt_a11y_labels'] : array();
	foreach ( $s['link_labels'] as $row ) {
		if ( '' === $row['lang'] || $row['lang'] === $lang ) {
			$labels[ $row['url'] ] = $row['label'];
		}
	}

	$strings = array();
	foreach ( $s['strings'] as $key => $pair ) {
		$strings[ $key ] = 'el' === $lang ? $pair['el'] : $pair['en'];
	}

	$path  = abt_a11y_current_path();
	$raw   = abt_a11y_current_path( true );
	$rules = array();
	foreach ( $s['rules'] as $r ) {
		// Page rules saved before 1.7.1 may carry the language directory in their path.
		if ( 'site' !== $r['scope'] && $r['scope'] !== $path && $r['scope'] !== $raw ) {
			continue;
		}
		if ( '' !== $r['lang'] && $r['lang'] !== $lang ) {
			continue;
		}
		$rules[] = array(
			'sel'   => $r['sel'],
			'kind'  => $r['kind'],
			'value' => $r['value'],
			'site'  => 'site' === $r['scope'],
			'lang'  => $r['lang'],
			'scope' => $r['scope'],
		);
	}

	return array(
		'version'            => ABT_A11Y_VERSION,
		'lazy'               => 'lazy' === abt_a11y_runtime_load(),
		'path'               => $path,
		'rules'              => $rules,
		'enabled'            => true,
		'lang'               => $lang,
		'siteName'           => wp_strip_all_tags( (string) get_bloginfo( 'name' ) ),
		'modules'            => $s['modules'],
		'contrastLevel'      => $s['contrast_level'],
		'contrastMargin'     => (float) $s['contrast_margin'],
		'textOverImage'      => $s['text_over_image'],
		'imageFallbackDark'  => $s['image_fallback_dark'],
		'imageFallbackLight' => $s['image_fallback_light'],
		'palette'            => $s['palette'],
		'keep'               => $s['keep_selectors'],
		'exclude'            => $s['exclude_selectors'],
		'labels'             => (object) $labels,
		'strings'            => $strings,
	);
}

/**
 * @param array $s
 * @return string
 */
function abt_a11y_front_css( $s ) {
	$css  = '.abt-a11y-sr{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0,0,0,0)!important;white-space:nowrap!important;border:0!important}';
	// Links and buttons keep the theme's own hover and focus colour; other text stays fixed
	// while the pointer is over it.
	$css .= '[data-abt-a11y-c]:not(:is(a,button,[role="button"]):hover):not(:is(a,button,[role="button"]):focus-visible):not(:is(a,button,[role="button"]):hover *):not(:is(a,button,[role="button"]):focus-visible *){color:var(--abt-a11y-c)!important}';
	$css .= '[data-abt-a11y-u]:not(:is(a,button,[role="button"]):hover):not(:is(a,button,[role="button"]):focus-visible):not(:is(a,button,[role="button"]):hover *):not(:is(a,button,[role="button"]):focus-visible *){color:var(--abt-a11y-u)!important}';
	$css .= '[data-abt-a11y-op]{opacity:1!important}';
	$css .= '[data-abt-a11y-bg]{background-color:var(--abt-a11y-bg)!important}';
	if ( ! empty( $s['modules']['pause'] ) ) {
		$size = (int) $s['pause_size'];
		$pos  = explode( '-', $s['pause_position'] );
		$v    = 'top' === $pos[0] ? 'top:12px' : 'bottom:12px';
		$h    = 'left' === $pos[1] ? 'left:12px' : 'right:12px';
		$css .= '.abt-a11y-pause{position:absolute;' . $v . ';' . $h . ';z-index:20;display:inline-flex;align-items:center;justify-content:center;width:' . $size . 'px;height:' . $size . 'px;padding:0;border:2px solid ' . $s['pause_fg'] . ';border-radius:50%;background:' . $s['pause_bg'] . ';color:' . $s['pause_fg'] . ';cursor:pointer;box-shadow:0 1px 4px rgba(0,0,0,.35)}';
		$css .= '.abt-a11y-pause svg{width:' . max( 10, (int) round( $size * 0.4 ) ) . 'px;height:' . max( 10, (int) round( $size * 0.4 ) ) . 'px;fill:currentColor;pointer-events:none}';
		$css .= '.abt-a11y-pause:focus-visible{outline:3px solid ' . $s['focus_color'] . ';outline-offset:2px}';
	}
	if ( ! empty( $s['modules']['focus'] ) ) {
		$css .= ':where(a,button,input,select,textarea,summary,[tabindex]:not([tabindex="-1"]),[role="button"]):focus-visible{outline:' . (int) $s['focus_width'] . 'px solid ' . $s['focus_color'] . '!important;outline-offset:2px!important}';
	}
	return $css;
}

/* -------------------------------------------------------------------------
 * Keep optimisation plugins from deferring/combining the runtime: it has to run
 * before the page is evaluated. Not in permanent mode, where the fixes are in the HTML
 * and the runtime may be delayed like any other script.
 * ---------------------------------------------------------------------- */

add_filter( 'script_loader_tag', 'abt_a11y_script_tag', 10, 2 );
/**
 * $tag holds both the inline config (before) and the runtime file.
 * nowprocket: WP Rocket · data-no-optimize/defer/minify: LiteSpeed, SG Optimizer ·
 * data-noptimize: Autoptimize · data-cfasync: Cloudflare Rocket Loader.
 *
 * @param string $tag    Script HTML.
 * @param string $handle Script handle.
 * @return string
 */
function abt_a11y_script_tag( $tag, $handle ) {
	if ( 'abt-a11y' !== $handle || empty( abt_a11y_get_settings()['optimizer_optout'] ) || 'lazy' === abt_a11y_runtime_load() ) {
		return $tag;
	}
	return str_replace( '<script ', '<script nowprocket data-no-optimize="1" data-noptimize="1" data-no-defer="1" data-no-minify="1" data-cfasync="false" data-pagespeed-no-defer ', $tag );
}
