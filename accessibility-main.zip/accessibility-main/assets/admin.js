/*!
 * Aboutnet Accessibility – admin screens: compliance status per setting,
 * one-click suggestions, and the page scanner.
 */
(function () {
	'use strict';

	var ADMIN = window.abtA11yAdmin || {};

	/* ------------------------------------------------------------------ *
	 * Colour maths (WCAG 2.1 relative luminance)
	 * ------------------------------------------------------------------ */

	function hex(v) {
		var m = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(v || '').trim());
		if (!m) return '';
		var h = m[1].length === 3 ? m[1].replace(/(.)/g, '$1$1') : m[1];
		return '#' + h.toLowerCase();
	}
	function rgb(v) {
		var m = /rgba?\(([^)]+)\)/.exec(v || '');
		if (m) {
			var p = m[1].split(/[\s,\/]+/).filter(Boolean).map(parseFloat);
			return { r: p[0], g: p[1], b: p[2] };
		}
		var h = hex(v);
		if (!h) return null;
		var n = parseInt(h.slice(1), 16);
		return { r: n >> 16 & 255, g: n >> 8 & 255, b: n & 255 };
	}
	function lum(c) {
		function f(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
		return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
	}
	function ratio(a, b) {
		a = typeof a === 'string' ? rgb(a) : a;
		b = typeof b === 'string' ? rgb(b) : b;
		if (!a || !b) return 0;
		var x = lum(a), y = lum(b);
		return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
	}
	function toHex(c) {
		function h(v) { v = Math.max(0, Math.min(255, Math.round(v))).toString(16); return v.length < 2 ? '0' + v : v; }
		return '#' + h(c.r) + h(c.g) + h(c.b);
	}
	function hsl(c) {
		var r = c.r / 255, g = c.g / 255, b = c.b / 255;
		var max = Math.max(r, g, b), min = Math.min(r, g, b), h = 0, s = 0, l = (max + min) / 2;
		if (max !== min) {
			var d = max - min;
			s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
			h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
			h /= 6;
		}
		return { h: h, s: s, l: l };
	}
	function fromHsl(h, s, l) {
		function hue(p, q, t) { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < 1 / 2) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; }
		var r, g, b;
		if (s === 0) { r = g = b = l; } else {
			var q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
			r = hue(p, q, h + 1 / 3); g = hue(p, q, h); b = hue(p, q, h - 1 / 3);
		}
		return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
	}
	// Nearest colour of the same hue that reaches `need` against every background.
	function suggestColor(color, bgs, need) {
		var c = rgb(color);
		bgs = bgs.map(rgb).filter(Boolean);
		if (!c || !bgs.length) return '';
		function okAll(x) { return bgs.every(function (b) { return ratio(x, b) >= need; }); }
		if (okAll(c)) return hex(color);
		var base = hsl(c);
		var best = null;
		[-1, 1].forEach(function (dir) {
			for (var step = 1; step <= 100; step++) {
				var l = base.l + dir * step / 100;
				if (l < 0 || l > 1) break;
				var x = fromHsl(base.h, base.s, l);
				if (okAll(x)) { if (!best || step < best.step) best = { step: step, c: x }; break; }
			}
		});
		return best ? toHex(best.c) : '';
	}
	function fmt(r) { return (Math.floor(r * 100) / 100).toFixed(2).replace('.', ',') + ':1'; }

	/* ------------------------------------------------------------------ *
	 * Settings page
	 * ------------------------------------------------------------------ */

	var form = document.querySelector('.abt-form');
	if (form) initSettings();

	function initSettings() {
		var rows = Array.prototype.slice.call(document.querySelectorAll('.abt-row[data-rule]'));
		var MODULE_BAD = /^(enabled|modules\.)/;

		function field(name) {
			return form.querySelector('[name="abt_a11y_settings' + name.split('.').map(function (p) { return '[' + p + ']'; }).join('') + '"]:not([type="hidden"])');
		}
		function val(name) { var f = field(name); return f ? (f.type === 'checkbox' ? f.checked : f.value) : null; }
		function level() { return val('contrast_level') === 'AAA' ? 7 : 4.5; }
		function margin() { var m = parseFloat(val('contrast_margin')); return isNaN(m) ? 0.2 : m; }
		function backgrounds() {
			var list = String(val('palette_backgrounds') || '').split(/\r?\n/).map(hex).filter(Boolean);
			return list.length ? list : ['#ffffff'];
		}
		function rec(row) { try { return JSON.parse(row.getAttribute('data-rec')); } catch (e) { return null; } }
		function data(row, k) { var v = row.getAttribute('data-' + k); if (v === null) return null; try { return JSON.parse(v); } catch (e) { return v; } }
		function control(row) { return row.querySelector('.abt-row-control input:not([type="hidden"]):not(.abt-color-picker), .abt-row-control select, .abt-row-control textarea'); }
		function setControl(el, value) {
			if (!el) return;
			if (el.type === 'checkbox') el.checked = !!value; else el.value = value;
			el.dispatchEvent(new Event('change', { bubbles: true }));
			var picker = el.parentElement && el.parentElement.querySelector('.abt-color-picker');
			if (picker && hex(value)) picker.value = hex(value);
		}
		function optionText(sel, value) {
			for (var i = 0; i < sel.options.length; i++) if (sel.options[i].value === value) return sel.options[i].text;
			return value;
		}

		var RULES = {
			bool: function (row) {
				var el = control(row), want = rec(row);
				if (el.checked === want) return { status: 'ok' };
				return {
					status: MODULE_BAD.test(row.dataset.key) ? 'bad' : 'warn',
					text: 'Προτείνεται: ' + (want ? 'Ενεργό' : 'Ανενεργό') + '.',
					apply: function () { setControl(el, want); }
				};
			},
			enum: function (row) {
				var el = control(row), want = rec(row), ok = data(row, 'ok') || [], warn = data(row, 'warn') || [];
				var v = el.value;
				var res = { status: ok.indexOf(v) > -1 ? 'ok' : (warn.indexOf(v) > -1 ? 'warn' : 'bad') };
				if (v !== want) {
					res.text = 'Προτείνεται: ' + optionText(el, want) + '.';
					res.apply = function () { setControl(el, want); };
					res.soft = res.status === 'ok';
				}
				return res;
			},
			min: function (row) {
				var el = control(row), want = rec(row), min = parseFloat(data(row, 'min'));
				var v = parseFloat(el.value);
				if (!isNaN(v) && v >= min) {
					return v < want ? { status: 'ok', soft: true, text: 'Προτείνεται: ' + String(want).replace('.', ',') + '.', apply: function () { setControl(el, want); } } : { status: 'ok' };
				}
				return { status: row.dataset.key === 'contrast_margin' ? 'warn' : 'bad', text: 'Ελάχιστο ' + String(min).replace('.', ',') + ', προτείνεται ' + String(want).replace('.', ',') + '.', apply: function () { setControl(el, want); } };
			},
			'color-vs': function (row) {
				var el = control(row), against = data(row, 'against') || ['#ffffff'];
				var need = level() + margin();
				var v = hex(el.value);
				if (!v) return { status: 'bad', text: 'Μη έγκυρο χρώμα.' };
				var r = Math.min.apply(null, against.map(function (b) { return ratio(v, b); }));
				var res = { status: r >= need ? 'ok' : 'bad', detail: 'Αντίθεση ' + fmt(r) };
				if (r < need) {
					var s = suggestColor(v, against, need);
					if (s) { res.text = 'Πρόταση: ' + s + ' (' + fmt(Math.min.apply(null, against.map(function (b) { return ratio(s, b); }))) + ').'; res.apply = function () { setControl(el, s); }; res.swatch = s; }
				}
				return res;
			},
			'color-pair': function (row) {
				var el = control(row), other = val(data(row, 'pair'));
				var v = hex(el.value), o = hex(other);
				if (!v || !o) return { status: 'bad', text: 'Μη έγκυρο χρώμα.' };
				var need = 4.5, r = ratio(v, o);
				var res = { status: r >= need ? 'ok' : 'bad', detail: 'Αντίθεση ' + fmt(r) };
				if (r < need) {
					var s = suggestColor(v, [o], need + margin());
					if (s) { res.text = 'Πρόταση: ' + s + '.'; res.apply = function () { setControl(el, s); }; res.swatch = s; }
				}
				return res;
			},
			'color-pair-bg': function (row) {
				var v = hex(control(row).value), o = hex(val(data(row, 'pair')));
				if (!v || !o) return { status: 'bad', text: 'Μη έγκυρο χρώμα.' };
				var r = ratio(v, o);
				return { status: r >= 4.5 ? 'ok' : 'bad', detail: 'Αντίθεση με το εικονίδιο ' + fmt(r), text: r >= 4.5 ? '' : 'Δείτε την πρόταση στο χρώμα εικονιδίου.' };
			},
			'color-vs-bgs': function (row) {
				var el = control(row), need = parseFloat(data(row, 'need')) || 3, bgs = backgrounds();
				var v = hex(el.value);
				if (!v) return { status: 'bad', text: 'Μη έγκυρο χρώμα.' };
				var r = Math.min.apply(null, bgs.map(function (b) { return ratio(v, b); }));
				var res = { status: r >= need ? 'ok' : 'bad', detail: 'Ελάχιστη αντίθεση ' + fmt(r) };
				if (r < need) {
					var s = suggestColor(v, bgs, need + margin());
					if (s) { res.text = 'Πρόταση: ' + s + '.'; res.apply = function () { setControl(el, s); }; res.swatch = s; }
				}
				return res;
			},
			colors: function (row) {
				var lines = String(control(row).value || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean);
				var bad = lines.filter(function (l) { return !hex(l); });
				if (!lines.length) return { status: 'warn', text: 'Προσθέστε τουλάχιστον ένα χρώμα φόντου (π.χ. #ffffff).', apply: function () { setControl(control(row), '#ffffff'); } };
				return bad.length ? { status: 'bad', text: 'Μη έγκυρα: ' + bad.join(', ') } : { status: 'ok' };
			},
			selectors: function (row) {
				var lines = String(control(row).value || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean);
				var bad = lines.filter(function (l) { try { document.querySelector(l); return false; } catch (e) { return true; } });
				if (bad.length) return { status: 'bad', text: 'Μη έγκυροι selectors: ' + bad.join(' · ') };
				return { status: 'ok', info: !lines.length };
			},
			empty: function (row) {
				var el = control(row);
				if (!String(el.value || '').trim()) return { status: 'ok' };
				return { status: 'warn', text: 'Ό,τι εξαιρείται δεν διορθώνεται, οπότε εκεί θα παραμείνουν errors. Προτείνεται να μείνει κενό.', apply: function () { setControl(el, ''); }, manualOnly: true };
			},
			strings: function (row) {
				var inputs = Array.prototype.slice.call(row.querySelectorAll('input[type="text"]'));
				var empty = inputs.filter(function (i) { return !i.value.trim(); });
				if (!empty.length) return { status: 'ok' };
				return { status: 'bad', text: empty.length + ' κενά κείμενα: τα στοιχεία τους θα μείνουν χωρίς όνομα.', apply: function () { empty.forEach(function (i) { setControl(i, i.getAttribute('data-default')); }); } };
			},
			palette: function (row) {
				var bgs = backgrounds(), need = level() + margin();
				var failing = [];
				Array.prototype.forEach.call(row.querySelectorAll('.abt-palette-row'), function (tr) {
					var to = tr.querySelectorAll('.abt-color-text')[1], from = tr.querySelectorAll('.abt-color-text')[0];
					var cell = tr.querySelector('.abt-palette-ratio');
					var t = hex(to.value);
					if (!t) { cell.textContent = 'Μη έγκυρο χρώμα'; failing.push({ to: to, from: from }); return; }
					var parts = bgs.map(function (b) { var r = ratio(t, b); return '<span class="abt-chip ' + (r >= need ? 'is-ok' : 'is-bad') + '"><i style="background:' + b + '"></i>' + fmt(r) + '</span>'; });
					cell.innerHTML = parts.join(' ');
					if (bgs.some(function (b) { return ratio(t, b) < need; })) failing.push({ to: to, from: from });
				});
				if (!failing.length) return { status: 'ok', info: !row.querySelector('.abt-palette-row') };
				return {
					status: 'bad',
					text: failing.length + ' αντιστοιχίσεις δεν έχουν αρκετή αντίθεση με όλα τα φόντα.',
					apply: function () {
						var now = level() + margin(), bgsNow = backgrounds();
						failing.forEach(function (f) {
							var s = suggestColor(f.to.value || f.from.value, bgsNow, now);
							if (s) setControl(f.to, s);
						});
					}
				};
			},
			labels: function (row) {
				var generic = /^(εδώ|περισσότερα|μάθετε περισσότερα|δείτε|click here|here|more|read more|link|σύνδεσμος)$/i;
				var weak = Array.prototype.filter.call(row.querySelectorAll('.abt-label-text'), function (i) { return !i.value.trim() || generic.test(i.value.trim()); });
				if (!weak.length) return { status: 'ok', info: !row.querySelector('.abt-label-row') };
				return { status: 'warn', text: weak.length + ' ετικέτες είναι κενές ή γενικές («εδώ», «περισσότερα»). Γράψτε πού οδηγεί ο σύνδεσμος.' };
			}
		};

		var LABELS = { ok: 'Σε συμμόρφωση', warn: 'Προσοχή', bad: 'Χωρίς συμμόρφωση' };

		function evaluate(row) {
			var rule = RULES[row.dataset.rule];
			if (!rule) return null;
			var res;
			try { res = rule(row) || { status: 'ok' }; } catch (e) { res = { status: 'warn', text: 'Δεν ήταν δυνατός ο έλεγχος.' }; }
			var badge = row.querySelector('.abt-badge');
			if (badge) {
				badge.className = 'abt-badge is-' + (res.info ? 'info' : res.status);
				badge.textContent = res.info ? 'Προαιρετικό' : LABELS[res.status] + (res.detail ? ' · ' + res.detail : '');
			}
			var box = row.querySelector('.abt-suggest');
			if (box) {
				var show = !!res.text;
				box.hidden = !show;
				if (show) {
					box.querySelector('.abt-suggest-text').innerHTML = '';
					if (res.swatch) {
						var sw = document.createElement('i');
						sw.className = 'abt-swatch';
						sw.style.background = res.swatch;
						box.querySelector('.abt-suggest-text').appendChild(sw);
					}
					box.querySelector('.abt-suggest-text').appendChild(document.createTextNode(res.text));
					var btn = box.querySelector('.abt-apply');
					if (btn) {
						btn.hidden = !res.apply;
						btn.onclick = res.apply ? function () { res.apply(); refresh(); } : null;
					}
				}
			}
			row._abt = res;
			return res;
		}

		function refresh() {
			var total = 0, ok = 0;
			rows.forEach(function (row) {
				var res = evaluate(row);
				if (!res || res.info) return;
				total++;
				if (res.status === 'ok') ok++;
			});
			var count = document.querySelector('.abt-summary-count');
			if (count) count.textContent = ok + ' από ' + total;
			var box = document.querySelector('.abt-summary');
			if (box) box.className = 'abt-summary ' + (ok === total ? 'is-ok' : 'is-bad');
		}

		var timer = null;
		form.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(refresh, 150); });
		form.addEventListener('change', function (e) {
			var t = e.target;
			if (t.classList.contains('abt-color-picker')) {
				var text = t.parentElement.querySelector('.abt-color-text');
				if (text) text.value = t.value;
			}
			if (t.classList.contains('abt-color-text') && hex(t.value)) {
				var picker = t.parentElement.querySelector('.abt-color-picker');
				if (picker) picker.value = hex(t.value);
			}
			clearTimeout(timer); timer = setTimeout(refresh, 50);
		});
		form.addEventListener('input', function (e) {
			if (e.target.classList.contains('abt-color-picker')) {
				var text = e.target.parentElement.querySelector('.abt-color-text');
				if (text) text.value = e.target.value;
			}
		});

		// Rules depend on each other (margin → colours, backgrounds → palette), so each row is
		// re-evaluated right before its suggestion is applied, and a second pass catches the rest.
		document.querySelector('.abt-apply-all').addEventListener('click', function () {
			for (var pass = 0; pass < 3; pass++) {
				var changed = false;
				rows.forEach(function (row) {
					var res = evaluate(row);
					if (res && res.apply && !res.manualOnly) { res.apply(); changed = true; }
				});
				refresh();
				if (!changed) break;
			}
		});

		// Changes made on the page travel as one JSON field (see abt_a11y_sanitize()).
		form.addEventListener('submit', function () {
			var field = document.getElementById('abt-rules-json');
			if (!field) return;
			var rules = Array.prototype.map.call(form.querySelectorAll('.abt-rule-row'), function (tr) {
				try { return JSON.parse(tr.getAttribute('data-rule')); } catch (e) { return null; }
			}).filter(Boolean);
			field.value = JSON.stringify(rules);
		});

		var uid = Date.now();
		function addRow(templateId, tbody) {
			var tpl = document.getElementById(templateId);
			var html = tpl.innerHTML.replace(/__i__/g, 'n' + (uid++));
			tbody.insertAdjacentHTML('beforeend', html);
			refresh();
			var first = tbody.lastElementChild && tbody.lastElementChild.querySelector('input:not(.abt-color-picker)');
			if (first) first.focus();
		}
		document.querySelector('.abt-add-palette').addEventListener('click', function () {
			addRow('abt-palette-template', document.querySelector('[data-key="palette"] tbody'));
		});
		document.querySelector('.abt-add-label').addEventListener('click', function () {
			addRow('abt-label-template', document.querySelector('[data-key="link_labels"] tbody'));
		});
		form.addEventListener('click', function (e) {
			if (!e.target.classList.contains('abt-remove-row')) return;
			var tr = e.target.closest('tr');
			if (tr) tr.remove();
			refresh();
		});

		var exportBtn = document.querySelector('.abt-export');
		if (exportBtn) exportBtn.addEventListener('click', function () {
			var payload = { plugin: 'aboutnet-a11y', exported: new Date().toISOString(), site: ADMIN.home, settings: ADMIN.settings };
			var blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
			var a = document.createElement('a');
			a.href = URL.createObjectURL(blob);
			a.download = 'aboutnet-a11y-settings.json';
			document.body.appendChild(a);
			a.click();
			setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
		});

		refresh();
	}

	/* ------------------------------------------------------------------ *
	 * Scanner
	 * ------------------------------------------------------------------ */

	if (document.getElementById('abt-scan-start')) initScanner();

	function initScanner() {
		var $ = function (id) { return document.getElementById(id); };
		var running = false;
		var results = [];
		var agg = { colors: {}, links: {}, images: {}, issues: {}, noPlugin: 0, imageBg: 0 };
		var paletteFroms = (ADMIN.settings && ADMIN.settings.palette || []).map(function (r) { return r.from; });

		function post(action, body) {
			var fd = new FormData();
			fd.append('action', action);
			fd.append('nonce', ADMIN.nonce);
			Object.keys(body || {}).forEach(function (k) { fd.append(k, body[k]); });
			return fetch(ADMIN.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
		}
		var STATIC = !!(ADMIN.settings && ADMIN.settings.mode === 'static' && ADMIN.settings.enabled);
		var baked = 0;
		function withParams(url, view) {
			var u = new URL(url, window.location.href);
			u.searchParams.set('abt-a11y-scan', '1');
			if (view === true || view === 'off') u.searchParams.set('abt-a11y', 'off');
			else if (view === 'learn') u.searchParams.set('abt-a11y-learn', '1');
			else if (view === 'nojs') u.searchParams.set('abt-a11y-nojs', '1');
			return u.toString();
		}

		/* Permanent mode: the colour fixes the runtime found are stored as CSS selectors. */
		var BAD_CLASS = /^(abt-|is-|has-|wp-image-|e-(con|flex|parent|child|grid|lazyloaded)$|elementor-(invisible|animated|repeater-item-|element-edit-mode)|swiper-slide-(active|next|prev|duplicate|visible)|wd-slide-(active|next|prev|visible)|wd-(active|full-visible)$|active$|current|hover|focus|animated|animate__|fadeIn|lazy|loaded|selected|woodmart-loaded)/;
		function classes(el, n) {
			return Array.prototype.filter.call(el.classList || [], function (c) { return /^[a-zA-Z_][\w-]*$/.test(c) && !BAD_CLASS.test(c); }).slice(0, n);
		}
		function part(el) { return el.tagName.toLowerCase() + classes(el, 2).map(function (c) { return '.' + c; }).join(''); }
		function count(doc, sel) { try { return doc.querySelectorAll(sel).length; } catch (e) { return 0; } }
		function anchorOf(doc, el) {
			for (var a = el.parentElement; a && a !== doc.body; a = a.parentElement) {
				var did = a.getAttribute('data-id');
				if (did && /^[a-z0-9]+$/i.test(did) && a.classList.contains('elementor-element-' + did)) return { el: a, sel: '.elementor-element-' + did };
				if (a.id && /^[a-zA-Z][\w-]*$/.test(a.id) && !/abt/.test(a.id) && count(doc, '#' + a.id) === 1) return { el: a, sel: '#' + a.id };
			}
			return null;
		}
		function similarSelector(doc, el) {
			var anc = anchorOf(doc, el), base = anc ? anc.sel : '';
			if (!base) {
				var chain = [];
				for (var e = el.parentElement; e && e !== doc.body && chain.length < 3; e = e.parentElement) if (classes(e, 1).length) chain.unshift(part(e));
				base = chain.join(' ');
			}
			var sel = (base ? base + ' ' : '') + part(el);
			try { if (!el.matches(sel)) sel = part(el); } catch (x) { sel = part(el); }
			return sel;
		}
		function uniqueSelector(doc, el) {
			if (el.id && /^[a-zA-Z][\w-]*$/.test(el.id) && !/abt/.test(el.id) && count(doc, '#' + el.id) === 1) return '#' + el.id;
			var s = similarSelector(doc, el);
			if (count(doc, s) === 1) return s;
			var anc = anchorOf(doc, el), parts = [];
			for (var e = el; e && e !== doc.body && (!anc || e !== anc.el); e = e.parentElement) {
				var k = 1;
				for (var p = e.previousElementSibling; p; p = p.previousElementSibling) if (p.tagName === e.tagName) k++;
				parts.unshift(e.tagName.toLowerCase() + ':nth-of-type(' + k + ')');
			}
			var sel = (anc ? anc.sel : 'body') + ' > ' + parts.join(' > ');
			try { if (count(doc, sel) === 1 && el.matches(sel)) return sel; } catch (x) { /* fall back */ }
			return null;
		}
		function sitewide(el) {
			return !!el.closest('header, footer, [data-elementor-type="header"], [data-elementor-type="footer"], .elementor-location-header, .elementor-location-footer, .whb-header, .site-header, .site-footer, #masthead, #colophon, .wd-header, .footer-container');
		}
		function fixOf(el) {
			var out = {};
			var c = el.hasAttribute('data-abt-a11y-c') ? (el.style.getPropertyValue('--abt-a11y-c') || '').trim() : '';
			var bg = el.hasAttribute('data-abt-a11y-bg') ? (el.style.getPropertyValue('--abt-a11y-bg') || '').trim() : '';
			if (c) out.c = c;
			if (bg) out.bg = bg;
			if (c && el.hasAttribute('data-abt-a11y-op')) out.op = 1;
			return out;
		}
		function sameFix(a, b) { return a.c === b.c && a.bg === b.bg && !!a.op === !!b.op; }
		function bakeFrom(doc) {
			var page = {}, site = {}, done = new Set();
			var els = Array.prototype.slice.call(doc.querySelectorAll('[data-abt-a11y-c], [data-abt-a11y-bg]'));
			els.forEach(function (el) {
				if (done.has(el)) return;
				var fix = fixOf(el);
				if (!fix.c && !fix.bg) return;
				var sel = null;
				// One rule for a group of elements that all got the same fix (product titles, menu items).
				var sim = similarSelector(doc, el), group = null;
				try { group = Array.prototype.slice.call(doc.querySelectorAll(sim)); } catch (e) { group = null; }
				if (group && group.length > 1 && group.every(function (g) { return sameFix(fixOf(g), fix); })) {
					sel = sim;
					group.forEach(function (g) { done.add(g); });
				} else {
					sel = uniqueSelector(doc, el);
					done.add(el);
				}
				if (!sel || /[<{};@\\]/.test(sel) || sel.length > 300) return;
				(sitewide(el) ? site : page)[sel] = fix;
			});
			return { page: page, site: site };
		}
		function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

		function load(url, width) {
			return new Promise(function (resolve) {
				var f = document.createElement('iframe');
				f.style.width = width + 'px';
				f.style.height = '900px';
				f.setAttribute('tabindex', '-1');
				f.setAttribute('title', 'Έλεγχος');
				var done = false;
				function finish() {
					if (done) return;
					done = true;
					setTimeout(function () { resolve(f); }, 2500);
				}
				f.addEventListener('load', finish);
				setTimeout(finish, 45000);
				f.src = url;
				$('abt-frames').appendChild(f);
			});
		}

		function inspect(f) {
			var doc;
			try { doc = f.contentDocument; } catch (e) { return { error: 'Η σελίδα δεν είναι διαθέσιμη (άλλο domain;)' }; }
			if (!doc || !doc.body) return { error: 'Η σελίδα δεν φόρτωσε.' };
			// Let entrance animations end, as they would for a visitor.
			try { doc.getAnimations().forEach(function (a) { var t = a.effect && a.effect.getComputedTiming(); if (t && isFinite(t.endTime)) a.finish(); }); } catch (e) { /* ignore */ }
			var res = window.abtCheck(doc);
			var issues = [];
			Object.keys(res.error).forEach(function (k) {
				res.error[k].forEach(function (i) { issues.push({ rule: k, desc: window.abtDescribe(i.el) + (i.note ? ' ' + i.note : '') }); });
			});
			res.contrast.forEach(function (c) { issues.push({ rule: 'contrast', desc: window.abtDescribe(c.el) + ' · ' + c.fg + ' σε ' + c.bg + ' = ' + String(c.ratio).replace('.', ',') + ':1' }); });
			var sum = window.abtSummary(res);
			var out = { errors: sum.errorTotal, contrast: sum.contrast, issues: issues, title: doc.title };
			var w = f.contentWindow;
			out.plugin = !!(w && w.abtA11y) || (STATIC && !!doc.getElementById('abt-a11y-inline-css'));
			out.colors = [];
			Array.prototype.forEach.call(doc.querySelectorAll('[data-abt-a11y-c]'), function (el) {
				var from = el.getAttribute('data-abt-a11y-c'), to = (el.style.getPropertyValue('--abt-a11y-c') || '').trim();
				if (from && to) out.colors.push({ from: from, to: to });
			});
			out.links = [];
			Array.prototype.forEach.call(doc.querySelectorAll('a[data-abt-a11y="named-url"], a[data-abt-a11y="named-guess"]'), function (a) {
				var img = a.querySelector('img[alt]');
				out.links.push({ href: a.href, label: a.getAttribute('aria-label') || (img && img.getAttribute('alt')) || '' });
			});
			out.images = [];
			Array.prototype.forEach.call(doc.querySelectorAll('img[data-abt-a11y="alt-filename"]'), function (img) {
				out.images.push({ src: img.currentSrc || img.src, alt: img.getAttribute('alt') });
			});
			out.imageBg = doc.querySelectorAll('[data-abt-a11y-bg="image"]').length;
			out.photoPartial = doc.querySelectorAll('[data-abt-a11y-why^="photo-partial"]').length;
			return out;
		}

		async function scanOne(job) {
			var row = { url: job.url, label: job.label, type: job.type, vp: job.vp };
			if (job.compare) {
				var fb = await load(withParams(job.url, true), job.width);
				var before = inspect(fb);
				fb.remove();
				row.before = before;
			}
			if (!running) return row;
			if (STATIC) {
				// 1. Measure: the page as the server fixes it, plus the runtime, without the stored colours.
				var fl = await load(withParams(job.url, 'learn'), job.width);
				var learned = inspect(fl);
				var fixes = null;
				try { fixes = learned.error ? null : bakeFrom(fl.contentDocument); } catch (e) { fixes = null; }
				fl.remove();
				if (fixes) {
					var r = await post('abt_a11y_bake', { url: job.url, vp: job.vp, page: JSON.stringify(fixes.page), site: JSON.stringify(fixes.site) });
					if (r && r.success) baked += r.data.stored;
				}
				if (!running) { row.after = learned; return row; }
				// 2. Count: only what the server sends (HTML + stored colours), no plugin script.
				var fn = await load(withParams(job.url, 'nojs'), job.width);
				row.after = inspect(fn);
				fn.remove();
				// Suggestions come from the measuring view, where every fix carries its mark.
				if (!row.after.error && !learned.error) {
					row.after.colors = learned.colors; row.after.links = learned.links; row.after.images = learned.images;
					row.after.imageBg = learned.imageBg; row.after.photoPartial = learned.photoPartial;
				}
				return row;
			}
			var fa = await load(withParams(job.url, false), job.width);
			row.after = inspect(fa);
			fa.remove();
			return row;
		}

		function pretty(u) { try { return decodeURI(u); } catch (e) { return u; } }
		function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
		function cell(r) { return r ? (r.error ? '—' : r.errors + ' / ' + r.contrast) : '—'; }

		function addResultRow(row) {
			var tbody = document.querySelector('#abt-results tbody');
			var tr = document.createElement('tr');
			var a = row.after || {};
			var ok = !a.error && a.errors === 0 && a.contrast === 0;
			var status = a.error ? '<span class="abt-badge is-warn">' + esc(a.error) + '</span>'
				: ok ? '<span class="abt-badge is-ok">0 errors</span>'
				: '<span class="abt-badge is-bad">' + (a.errors + a.contrast) + ' εναπομείναντα</span>';
			if (!a.error && !a.plugin) status += ' <span class="abt-badge is-warn">Το plugin δεν φορτώθηκε</span>';
			if (!a.error && a.plugin) status += '<br><a class="abt-see-changes" href="' + esc(row.url.split('#')[0] + '#abt-a11y-inspect') + '" target="_blank" rel="noopener">Τι άλλαξε εδώ</a>';
			var details = '';
			if (a.issues && a.issues.length) {
				details = '<details><summary>Λεπτομέρειες</summary><ul>' + a.issues.slice(0, 40).map(function (i) { return '<li><code>' + esc(i.rule) + '</code> ' + esc(i.desc) + '</li>'; }).join('') + '</ul></details>';
			}
			tr.innerHTML = '<td><a href="' + esc(row.url) + '" target="_blank" rel="noopener">' + esc(row.label || pretty(row.url)) + '</a><br><small>' + esc(row.type || '') + '</small></td>' +
				'<td>' + (row.vp === 'mobile' ? 'Κινητό' : 'Υπολογιστής') + '</td>' +
				'<td>' + cell(row.before) + '</td><td>' + cell(row.after) + '</td><td>' + status + details + '</td>';
			tbody.appendChild(tr);
		}

		function collect(row) {
			var a = row.after;
			if (!a || a.error) return;
			if (!a.plugin) agg.noPlugin++;
			agg.imageBg += a.imageBg || 0;
			agg.photoPartial = (agg.photoPartial || 0) + (a.photoPartial || 0);
			a.colors.forEach(function (c) {
				if (paletteFroms.indexOf(c.from) > -1) return;
				var k = c.from;
				agg.colors[k] = agg.colors[k] || { from: c.from, to: {}, n: 0 };
				agg.colors[k].n++;
				agg.colors[k].to[c.to] = (agg.colors[k].to[c.to] || 0) + 1;
			});
			a.links.forEach(function (l) {
				var k = l.href;
				agg.links[k] = agg.links[k] || { href: l.href, label: l.label, pages: {}, n: 0, page: row.url };
				if (!agg.links[k].pages[row.url]) { agg.links[k].pages[row.url] = 1; agg.links[k].n++; }
			});
			a.images.forEach(function (i) {
				agg.images[i.src] = agg.images[i.src] || { src: i.src, alt: i.alt, n: 0, page: row.url };
				agg.images[i.src].n++;
			});
			(a.issues || []).forEach(function (i) {
				var k = i.rule + '|' + i.desc.replace(/"[^"]*"/, '').slice(0, 140);
				agg.issues[k] = agg.issues[k] || { rule: i.rule, desc: i.desc, n: 0, page: row.url };
				agg.issues[k].n++;
			});
		}

		function renderTotals() {
			var done = results.length;
			var b = { e: 0, c: 0 }, a = { e: 0, c: 0 }, clean = 0;
			results.forEach(function (r) {
				if (r.before && !r.before.error) { b.e += r.before.errors; b.c += r.before.contrast; }
				if (r.after && !r.after.error) { a.e += r.after.errors; a.c += r.after.contrast; if (!r.after.errors && !r.after.contrast) clean++; }
			});
			var box = $('abt-totals');
			box.hidden = false;
			box.innerHTML = '<div><strong>' + done + '</strong> έλεγχοι σελίδων</div>' +
				'<div><strong>' + clean + '</strong> χωρίς κανένα error</div>' +
				(results.some(function (r) { return r.before; }) ? '<div>Χωρίς διορθώσεις: <strong>' + b.e + '</strong> errors · <strong>' + b.c + '</strong> contrast</div>' : '') +
				'<div>' + (STATIC ? 'Με διορθώσεις, χωρίς JavaScript' : 'Με διορθώσεις') + ': <strong>' + a.e + '</strong> errors · <strong>' + a.c + '</strong> contrast</div>' +
				(STATIC && baked ? '<div><strong>' + baked + '</strong> διορθώσεις χρωμάτων αποθηκεύτηκαν</div>' : '');
		}

		function renderSuggestions() {
			var body = $('abt-suggestions-body');
			var html = '';
			if (agg.noPlugin) {
				html += '<div class="notice notice-warning inline"><p>Σε ' + agg.noPlugin + ' σελίδες οι διορθώσεις δεν φορτώθηκαν. Ελέγξτε ότι το plugin είναι ενεργό, ότι οι σελίδες δεν είναι στις εξαιρέσεις, και ότι κάποιο plugin βελτιστοποίησης δεν καθυστερεί τα scripts.</p></div>';
			}
			var issues = Object.keys(agg.issues).map(function (k) { return agg.issues[k]; }).sort(function (x, y) { return y.n - x.n; });
			if (issues.length) {
				html += '<h3>Εναπομείναντα errors</h3><p>Αυτά δεν διορθώθηκαν αυτόματα. Συνήθως χρειάζονται αλλαγή στο περιεχόμενο ή στο θέμα.</p><table class="widefat striped"><thead><tr><th>Κανόνας</th><th>Στοιχείο</th><th>Εμφανίσεις</th></tr></thead><tbody>' +
					issues.slice(0, 50).map(function (i) { return '<tr><td><code>' + esc(i.rule) + '</code></td><td>' + esc(i.desc) + '<br><a href="' + esc(i.page) + '" target="_blank" rel="noopener"><small>π.χ. ' + esc(pretty(i.page)) + '</small></a></td><td>' + i.n + '</td></tr>'; }).join('') + '</tbody></table>';
			}
			var colors = Object.keys(agg.colors).map(function (k) { return agg.colors[k]; }).sort(function (x, y) { return y.n - x.n; });
			if (colors.length) {
				html += '<h3>Χρώματα που διορθώθηκαν αυτόματα</h3><p>Αν προσθέσετε την αντιστοίχιση, το site θα χρησιμοποιεί σταθερά αυτή την απόχρωση. Μπορείτε να την αλλάξετε στις ρυθμίσεις.</p><table class="widefat striped"><thead><tr><th>Αρχικό</th><th>Νέο</th><th>Σημεία</th><th><span class="screen-reader-text">Ενέργεια</span></th></tr></thead><tbody>' +
					colors.slice(0, 30).map(function (c) {
						var best = Object.keys(c.to).sort(function (x, y) { return lum(rgb(y)) - lum(rgb(x)); })[0];
						return '<tr><td><span class="abt-chip"><i style="background:' + esc(c.from) + '"></i>' + esc(c.from) + '</span></td><td><span class="abt-chip"><i style="background:' + esc(best) + '"></i>' + esc(best) + '</span></td><td>' + c.n + '</td><td><button type="button" class="button button-small abt-add-color" data-from="' + esc(c.from) + '" data-to="' + esc(best) + '">Προσθήκη αντιστοίχισης</button></td></tr>';
					}).join('') + '</tbody></table>';
			}
			var links = Object.keys(agg.links).map(function (k) { return agg.links[k]; }).sort(function (x, y) { return y.n - x.n; });
			if (links.length) {
				html += '<h3>Σύνδεσμοι που ονομάστηκαν από τη διεύθυνσή τους</h3><p>Πήραν όνομα από το URL, οπότε μπορεί να μη διαβάζεται φυσικά. Γράψτε πού οδηγούν.</p><table class="widefat striped"><thead><tr><th>Σύνδεσμος</th><th>Όνομα</th><th><span class="screen-reader-text">Ενέργεια</span></th></tr></thead><tbody>' +
					links.slice(0, 40).map(function (l, i) {
						return '<tr><td><a href="' + esc(l.href) + '" target="_blank" rel="noopener">' + esc(pretty(l.href)) + '</a><br><small>' + (l.n === 1 ? 'σε 1 σελίδα' : 'σε ' + l.n + ' σελίδες') + '</small></td><td><label class="screen-reader-text" for="abt-l' + i + '">Όνομα συνδέσμου</label><input id="abt-l' + i + '" type="text" class="regular-text" value="' + esc(l.label) + '"></td><td><button type="button" class="button button-small abt-add-link" data-url="' + esc(l.href) + '" data-input="abt-l' + i + '">Αποθήκευση</button></td></tr>';
					}).join('') + '</tbody></table>';
			}
			var images = Object.keys(agg.images).map(function (k) { return agg.images[k]; });
			if (images.length) {
				html += '<h3>Εικόνες με alt από το όνομα αρχείου</h3><p>Γράψτε το κείμενο εναλλακτικής περιγραφής στη Βιβλιοθήκη Πολυμέσων.</p><ul>' +
					images.slice(0, 40).map(function (i) {
						var file = i.src.split('/').pop().split('?')[0];
						return '<li><a href="' + esc(ADMIN.settingsUrl.replace(/admin\.php.*$/, 'upload.php?search=' + encodeURIComponent(file.replace(/\.[a-z0-9]+$/i, '')))) + '" target="_blank" rel="noopener">' + esc(file) + '</a> → «' + esc(i.alt) + '»</li>';
					}).join('') + '</ul>';
			}
			if (agg.imageBg) {
				html += '<p>Σε ' + agg.imageBg + ' σημεία με κείμενο πάνω σε φωτογραφία δόθηκε συμπαγές χρώμα κάτω από τη φωτογραφία. Το χρώμα αλλάζει στις ρυθμίσεις αντίθεσης.</p>';
			}
			if (agg.photoPartial) {
				html += '<p>Σε ' + agg.photoPartial + ' σημεία κείμενο πάνω σε φωτογραφία έμεινε όπως ήταν, γιατί η φωτογραφία δεν καλύπτει όλο το πλαίσιο και ένα χρώμα από κάτω θα φαινόταν. Εκεί χρειάζεται overlay ή χρώμα φόντου από τον Elementor. Για να τα δείτε, πατήστε «Τι άλλαξε εδώ» δίπλα στη σελίδα στον πίνακα.</p>';
			}
			$('abt-suggestions').hidden = !html;
			body.innerHTML = html;
		}

		document.addEventListener('click', function (e) {
			var t = e.target;
			if (t.classList.contains('abt-add-color')) {
				t.disabled = true;
				post('abt_a11y_add', { type: 'palette', from: t.dataset.from, to: t.dataset.to }).then(function (r) {
					t.textContent = r && r.success ? 'Προστέθηκε' : 'Σφάλμα';
					if (r && r.success) paletteFroms.push(t.dataset.from);
				});
			}
			if (t.classList.contains('abt-add-link')) {
				var input = document.getElementById(t.dataset.input);
				if (!input || !input.value.trim()) { input && input.focus(); return; }
				t.disabled = true;
				post('abt_a11y_add', { type: 'label', url: t.dataset.url, label: input.value.trim() }).then(function (r) {
					t.textContent = r && r.success ? 'Αποθηκεύτηκε' : 'Σφάλμα';
					if (!(r && r.success)) t.disabled = false;
				});
			}
		});

		async function start() {
			running = true;
			results = [];
			baked = 0;
			agg = { colors: {}, links: {}, images: {}, issues: {}, noPlugin: 0, imageBg: 0 };
			document.querySelector('#abt-results tbody').innerHTML = '';
			$('abt-results').hidden = false;
			$('abt-scan-start').disabled = true;
			$('abt-scan-stop').hidden = false;
			$('abt-scan-stop').disabled = false;
			$('abt-scan-csv').hidden = true;
			$('abt-progress-text').textContent = 'Συλλογή σελίδων…';

			var source = document.querySelector('input[name="abt-source"]:checked').value;
			var urls = [];
			if (source === 'list') {
				urls = $('abt-url-list').value.split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean).map(function (u) { return { url: u, label: u, type: '' }; });
			} else {
				var r = await post('abt_a11y_urls', { mode: source, per_type: $('abt-per-type').value });
				urls = r && r.success ? r.data : [];
			}
			var vps = [];
			if ($('abt-vp-desktop').checked) vps.push(['desktop', 1440]);
			if ($('abt-vp-mobile').checked) vps.push(['mobile', 390]);
			if (!vps.length) vps.push(['desktop', 1440]);
			var compare = $('abt-compare').checked;
			var jobs = [];
			urls.forEach(function (u) { vps.forEach(function (v) { jobs.push({ url: u.url, label: u.label, type: u.type, vp: v[0], width: v[1], compare: compare }); }); });

			var total = jobs.length, next = 0;
			$('abt-progress').max = Math.max(1, total);
			var conc = Math.max(1, Math.min(4, parseInt($('abt-concurrency').value, 10) || 2));
			async function worker() {
				while (running && next < jobs.length) {
					var job = jobs[next++];
					var row;
					try { row = await scanOne(job); } catch (e) { row = { url: job.url, label: job.label, vp: job.vp, after: { error: String(e && e.message || e) } }; }
					results.push(row);
					collect(row);
					addResultRow(row);
					$('abt-progress').value = results.length;
					$('abt-progress-text').textContent = results.length + ' από ' + total;
					renderTotals();
					if (results.length % 5 === 0 || results.length === total) renderSuggestions();
				}
			}
			var workers = [];
			for (var i = 0; i < conc; i++) workers.push(worker());
			await Promise.all(workers);
			if (STATIC) { try { await post('abt_a11y_bake_done', {}); } catch (e) { /* the cache is emptied on the next settings save */ } }
			renderSuggestions();
			running = false;
			$('abt-scan-start').disabled = false;
			$('abt-scan-stop').hidden = true;
			$('abt-scan-csv').hidden = !results.length;
			$('abt-progress-text').textContent = results.length < total ? 'Διακόπηκε: ' + results.length + ' από ' + total : 'Ολοκληρώθηκε: ' + total + ' έλεγχοι';
		}

		$('abt-scan-start').addEventListener('click', function () { start(); });
		$('abt-scan-stop').addEventListener('click', function () { running = false; $('abt-scan-stop').disabled = true; $('abt-scan-start').focus(); });
		$('abt-scan-csv').addEventListener('click', function () {
			var lines = [['URL', 'Οθόνη', 'Errors χωρίς', 'Contrast χωρίς', 'Errors με', 'Contrast με']];
			results.forEach(function (r) {
				lines.push([r.url, r.vp, r.before ? r.before.errors : '', r.before ? r.before.contrast : '', r.after ? r.after.errors : '', r.after ? r.after.contrast : '']);
			});
			var csv = '﻿' + lines.map(function (l) { return l.map(function (v) { return '"' + String(v).replace(/"/g, '""') + '"'; }).join(';'); }).join('\n');
			var a = document.createElement('a');
			a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
			a.download = 'accessibility-scan.csv';
			document.body.appendChild(a);
			a.click();
			setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
		});
	}
})();
