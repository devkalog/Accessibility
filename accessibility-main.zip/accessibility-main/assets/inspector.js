/*!
 * Aboutnet Accessibility: on-page editor (administrators only).
 * Marks on the page (remaining errors, automatic fixes, your own changes), click on any
 * element and a panel of changes that fit that element, like the Elementor panel.
 */
(function (window, document) {
	'use strict';

	var D = window.abtA11yInspector || {};
	var A = 'data-abt-a11y';
	function CFG() { return window.abtA11yConfig || {}; }
	function RT() { return window.abtA11y || null; }

	var STATUS = [
		{ id: 'error', label: 'Σφάλματα που μένουν', short: 'Σφάλματα', hint: 'Θα τα δείξει το WAVE. Κλικ για να τα διορθώσετε.' },
		{ id: 'review', label: 'Διορθώθηκαν, ελέγξτε τα', short: 'Για έλεγχο', hint: 'Το plugin τα διόρθωσε κατ’ εκτίμηση. Δείτε αν διαβάζονται σωστά.' },
		{ id: 'user', label: 'Δικές σας αλλαγές', short: 'Δικές σας', hint: '' },
		{ id: 'auto', label: 'Διορθώθηκαν αυτόματα', short: 'Αυτόματα', hint: '' }
	];
	var RANK = { error: 0, review: 1, user: 2, auto: 3 };
	var TYPE = { image: 'Εικόνα', link: 'Σύνδεσμος', button: 'Κουμπί', field: 'Πεδίο φόρμας', text: 'Κείμενο', icon: 'Εικονίδιο', heading: 'Επικεφαλίδα', pause: 'Κουμπί παύσης', photo: 'Φωτογραφία με κείμενο', page: 'Σελίδα', label: 'Ετικέτα πεδίου', other: 'Στοιχείο' };
	var WAVE = {
		alt_missing: 'Χωρίς εναλλακτικό κείμενο', alt_link_missing: 'Εικόνα-σύνδεσμος χωρίς περιγραφή', alt_input_missing: 'Κουμπί-εικόνα χωρίς περιγραφή',
		alt_area_missing: 'Περιοχή χάρτη χωρίς περιγραφή', alt_map_missing: 'Εικόνα χάρτη χωρίς alt', longdesc_invalid: 'Λάθος longdesc',
		link_empty: 'Σύνδεσμος χωρίς όνομα', button_empty: 'Κουμπί χωρίς όνομα', label_missing: 'Πεδίο χωρίς ετικέτα', label_multiple: 'Πεδίο με δύο ετικέτες',
		label_empty: 'Κενή ετικέτα', heading_empty: 'Κενή επικεφαλίδα', th_empty: 'Κενή κεφαλίδα πίνακα', aria_reference_broken: 'Σπασμένη αναφορά ARIA',
		aria_menu_broken: 'Μενού ARIA χωρίς στοιχεία', language_missing: 'Λείπει ή είναι λάθος η γλώσσα', link_skip_broken: 'Σύνδεσμος παράλειψης χωρίς στόχο',
		title_invalid: 'Λείπει ο τίτλος της σελίδας', meta_refresh: 'Αυτόματη ανανέωση σελίδας', marquee: 'Κινούμενο κείμενο (marquee)', blink: 'Κείμενο που αναβοσβήνει',
		contrast: 'Χαμηλή αντίθεση'
	};

	var on = false, panel = null, body = null, marks = null, hoverBox = null, tag = null;
	var items = [], filter = 'all', current = null, timer = null, frame = 0, preview = null, lastHover = null;
	var ui = { mode: 'right', x: 0, y: 0, w: 400, h: 0, min: false }, drag = null, dockHint = null;
	var liveTimer = null;
	function stopLive() { if (liveTimer) { window.clearInterval(liveTimer); liveTimer = null; } }

	/* ---------------- Small helpers ---------------- */

	function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
	function num(n) { return String(n).replace('.', ','); }
	function clean(s) { return String(s == null ? '' : s).replace(/[\s ]+/g, ' ').trim(); }
	function cut(s, n) { s = clean(s); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
	function q(s) { return '«' + esc(cut(s, 70)) + '»'; }
	function count(sel) { try { return document.querySelectorAll(sel).length; } catch (e) { return 0; } }
	function inUI(el) { return !!(el && el.closest && el.closest('[data-abt-ui], #wpadminbar')); }
	function link(hash, text) { return '<a href="' + esc((D.settings || '') + hash) + '" target="_blank" rel="noopener">' + esc(text) + '</a>'; }
	function pretty(u) { try { u = decodeURI(u); } catch (e) { /* keep */ } return u.replace(/^https?:\/\/(www\.)?/, '').replace(window.location.host.replace(/^www\./, ''), ''); }
	function sw(c) { return '<i class="abt-insp-sw" style="background:' + esc(c) + '"></i>'; }
	function textOf(el) {
		var c = el.cloneNode(true);
		Array.prototype.forEach.call(c.querySelectorAll('.abt-a11y-sr, script, style'), function (x) { x.remove(); });
		return clean(c.textContent);
	}
	function humanize(src) {
		var s = String(src || '');
		try { s = decodeURIComponent(s); } catch (e) { /* keep */ }
		s = s.replace(/[?#].*$/, '').split('/').filter(Boolean).pop() || '';
		s = s.replace(/\.[a-z0-9]{2,5}$/i, '').replace(/-\d+x\d+$/i, '').replace(/-(scaled|min|removebg-preview|copy|e\d{10,})$/i, '').replace(/[-_+]+/g, ' ').replace(/\s\d{1,2}$/, '');
		s = clean(s);
		return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
	}

	/* ---------------- Colour helpers (from the runtime) ---------------- */

	function parse(c) { return RT().util.parseColor(c); }
	function hex(c) { return RT().util.toHex(c); }
	function ratioOf(fg, bg) { var u = RT().util; return Math.floor(u.ratio(u.blend(fg, bg), bg) * 100) / 100; }

	/* ---------------- Selectors ---------------- */

	var BAD_CLASS = /^(abt-|is-|has-|wp-image-|e-(con|flex|parent|child|grid|lazyloaded)$|elementor-(invisible|animated|repeater-item-|element-edit-mode)|swiper-slide-(active|next|prev|duplicate|visible)|wd-slide-(active|next|prev|visible)|wd-(active|full-visible)$|active$|current|hover|focus|animated|animate__|fadeIn|lazy|loaded|selected|woodmart-loaded)/;
	function classes(el, n) {
		return Array.prototype.filter.call(el.classList || [], function (c) { return /^[a-zA-Z_][\w-]*$/.test(c) && !BAD_CLASS.test(c); }).slice(0, n);
	}
	function part(el) { return el.tagName.toLowerCase() + classes(el, 2).map(function (c) { return '.' + c; }).join(''); }
	function anchorOf(el) {
		for (var a = el.parentElement; a && a !== document.body; a = a.parentElement) {
			var did = a.getAttribute('data-id');
			if (did && /^[a-z0-9]+$/i.test(did) && a.classList.contains('elementor-element-' + did)) return { el: a, sel: '.elementor-element-' + did };
			if (a.id && /^[a-zA-Z][\w-]*$/.test(a.id) && !/abt/.test(a.id) && count('#' + a.id) === 1) return { el: a, sel: '#' + a.id };
		}
		return null;
	}
	function similarSelector(el) {
		if (el === document.documentElement) return 'html';
		var anc = anchorOf(el), base = anc ? anc.sel : '';
		if (!base) {
			var chain = [];
			for (var e = el.parentElement; e && e !== document.body && chain.length < 3; e = e.parentElement) if (classes(e, 1).length) chain.unshift(part(e));
			base = chain.join(' ');
		}
		var sel = (base ? base + ' ' : '') + part(el);
		try { if (!el.matches(sel)) sel = part(el); } catch (x) { sel = part(el); }
		return sel;
	}
	function uniqueSelector(el) {
		if (el.id && /^[a-zA-Z][\w-]*$/.test(el.id) && !/abt/.test(el.id) && count('#' + el.id) === 1) return '#' + el.id;
		var s = similarSelector(el);
		if (count(s) === 1) return s;
		var anc = anchorOf(el), parts = [];
		for (var e = el; e && e !== document.body && (!anc || e !== anc.el); e = e.parentElement) {
			var k = 1;
			for (var p = e.previousElementSibling; p; p = p.previousElementSibling) if (p.tagName === e.tagName) k++;
			parts.unshift(e.tagName.toLowerCase() + ':nth-of-type(' + k + ')');
		}
		var sel = (anc ? anc.sel : 'body') + ' > ' + parts.join(' > ');
		try { if (count(sel) === 1 && el.matches(sel)) return sel; } catch (x) { /* fall back */ }
		return s;
	}
	function sitewide(el) {
		return !!el.closest('header, footer, [data-elementor-type="header"], [data-elementor-type="footer"], .elementor-location-header, .elementor-location-footer, .whb-header, .site-header, .site-footer, #masthead, #colophon, .wd-header, .footer-container');
	}

	/* ---------------- What is on the page ---------------- */

	function typeOf(el) {
		var t = el.tagName.toLowerCase();
		if (el.classList && el.classList.contains('abt-a11y-pause')) return 'pause';
		if (t === 'html') return 'page';
		if (t === 'img' || t === 'area' || (t === 'input' && el.type === 'image')) return 'image';
		if (t === 'svg') return 'icon';
		if (t === 'a') return 'link';
		if (t === 'button' || el.getAttribute('role') === 'button' || (t === 'input' && /^(submit|button|reset)$/i.test(el.type))) return 'button';
		if (/^(input|select|textarea)$/.test(t)) return 'field';
		if (t === 'label') return 'label';
		if (/^h[1-6]$/.test(t)) return 'heading';
		if (el.hasAttribute(A + '-bg')) return 'photo';
		return 'text';
	}
	function nameOf(el) {
		var img = el.querySelector && el.querySelector('img[alt]');
		return el.getAttribute('aria-label') || el.getAttribute('alt') || textOf(el) || (img && img.getAttribute('alt')) || '';
	}
	function rulesFor(el) {
		return (CFG().rules || []).filter(function (r) { try { return el.matches(r.sel); } catch (e) { return false; } });
	}

	var FIX = {
		'named': 'Πήρε όνομα από το περιεχόμενο της σελίδας.',
		'named-setting': 'Πήρε όνομα από τις ρυθμίσεις (Σύνδεσμοι).',
		'named-url': 'Πήρε όνομα από τη διεύθυνση του συνδέσμου. Ελέγξτε ότι διαβάζεται σωστά.',
		'named-guess': 'Πήρε όνομα κατ’ εκτίμηση. Καλό είναι να γράψετε σωστό όνομα.',
		'duplicate-link': 'Διπλός σύνδεσμος εικόνας: κρύφτηκε από τους αναγνώστες οθόνης, γιατί δίπλα υπάρχει ίδιος σύνδεσμος με κείμενο.',
		'alt-filename': 'Πήρε περιγραφή από το όνομα του αρχείου. Καλό είναι να γράψετε σωστή περιγραφή.',
		'alt-title': 'Πήρε περιγραφή από τον τίτλο της εικόνας.',
		'alt-icon': 'Πήρε περιγραφή από το είδος του εικονιδίου.',
		'label-text': 'Η κενή ετικέτα πήρε κείμενο που διαβάζεται μόνο από αναγνώστες οθόνης.',
		color: 'Το plugin άλλαξε το χρώμα για να έχει αντίθεση.',
		bg: 'Το plugin έβαλε συμπαγές χρώμα κάτω από τη φωτογραφία. Κανονικά δεν φαίνεται.',
		overlay: 'Το χρώμα του overlay γράφτηκε και ως φόντο, για να το βλέπει το WAVE. Η εμφάνιση δεν αλλάζει.',
		partial: 'Η φωτογραφία δεν καλύπτει όλο το πλαίσιο, οπότε το plugin δεν άλλαξε τίποτα και μένει contrast error.',
		pause: 'Το plugin πρόσθεσε κουμπί παύσης, γιατί το slider αλλάζει μόνο του.',
		rule: 'Εδώ ισχύει δική σας αλλαγή.',
		detached: 'Δύο ετικέτες έδειχναν στο ίδιο πεδίο. Η δεύτερη αποσυνδέθηκε.',
		dupid: 'Διπλό id: το δεύτερο πεδίο πήρε νέο.',
		lang: 'Ο κωδικός γλώσσας διορθώθηκε.',
		aria: 'Αφαιρέθηκε αναφορά ARIA σε στοιχείο που δεν υπάρχει.',
		menu: 'Αφαιρέθηκε role="menu" χωρίς στοιχεία μενού.',
		skip: 'Ο σύνδεσμος παράλειψης δείχνει τώρα στο κύριο περιεχόμενο.'
	};
	var REVIEW = /^(named-url|named-guess|alt-filename|partial)$/;

	function collect() {
		var list = [], seen = typeof Map === 'function' ? new Map() : null;
		function add(el, status, title, extra) {
			if (!el || inUI(el) || !seen) return;
			var it = seen.get(el);
			if (!it) {
				it = { el: el, status: status, title: title, type: typeOf(el), waves: [], fixes: [] };
				seen.set(el, it);
				list.push(it);
			} else if (RANK[status] < RANK[it.status]) {
				it.status = status;
				it.title = title;
			}
			if (extra && extra.wave) it.waves.push(extra);
			if (extra && extra.fix && it.fixes.indexOf(extra.fix) < 0) it.fixes.push(extra.fix);
		}
		// 1. What the WAVE rules still find, after the fixes.
		if (typeof window.abtCheck === 'function') {
			var r = window.abtCheck(document);
			Object.keys(r.error).forEach(function (code) {
				r.error[code].forEach(function (e) {
					add(e.el, 'error', (WAVE[code] || code) + (e.el.tagName === 'HTML' ? '' : ' ' + q(nameOf(e.el) || humanize(e.el.getAttribute('src')))), { wave: code, note: e.note });
				});
			});
			r.contrast.forEach(function (c) {
				add(c.el, 'error', WAVE.contrast + ' ' + q(textOf(c.el)), { wave: 'contrast', fg: c.fg, bg: c.bg, ratio: c.ratio, need: c.need });
			});
		}
		// 2. What the plugin did on its own.
		Array.prototype.forEach.call(document.querySelectorAll('[' + A + '-c]'), function (el) {
			add(el, 'auto', 'Άλλαξε χρώμα ' + q(textOf(el)), { fix: 'color' });
		});
		Array.prototype.forEach.call(document.querySelectorAll('[' + A + '-bg]'), function (el) {
			var k = el.getAttribute(A + '-bg');
			add(el, 'auto', (k === 'overlay' ? 'Overlay ως φόντο ' : 'Χρώμα κάτω από φωτογραφία ') + q(cut(textOf(el), 45)), { fix: k === 'overlay' ? 'overlay' : 'bg' });
		});
		Array.prototype.forEach.call(document.querySelectorAll('[' + A + '-why^="photo-partial"]'), function (el) {
			add(el, 'review', 'Κείμενο πάνω σε φωτογραφία ' + q(textOf(el)), { fix: 'partial' });
		});
		Array.prototype.forEach.call(document.querySelectorAll('.abt-a11y-pause'), function (el) {
			add(el, 'auto', 'Κουμπί παύσης slider', { fix: 'pause' });
		});
		Array.prototype.forEach.call(document.querySelectorAll('[' + A + ']'), function (el) {
			var v = el.getAttribute(A);
			if (v === 'svg-hidden' || v === 'alt-empty') return;
			var target = v === 'label-text' ? el.parentElement : el;
			var t = typeOf(target);
			var title = /^empty-h/.test(v) ? 'Κενή επικεφαλίδα ' + v.slice(6).toUpperCase() + ' έγινε απλό στοιχείο' : TYPE[t] + ' → ' + q(nameOf(target));
			add(target, REVIEW.test(v) ? 'review' : 'auto', title, { fix: v });
		});
		[['[data-abt-for]', 'Δεύτερη ετικέτα για το ίδιο πεδίο', 'detached'], ['[' + A + '-id]', 'Διπλό id διορθώθηκε', 'dupid'], ['[' + A + '-lang]', 'Κωδικός γλώσσας διορθώθηκε', 'lang'],
			['[' + A + '-aria]', 'Σπασμένη αναφορά ARIA διορθώθηκε', 'aria'], ['[data-abt-role="menu"]', 'Άδειο μενού ARIA διορθώθηκε', 'menu'], ['[' + A + '-skip]', 'Σύνδεσμος παράλειψης διορθώθηκε', 'skip']].forEach(function (x) {
			Array.prototype.forEach.call(document.querySelectorAll(x[0]), function (el) { add(el, 'auto', x[1], { fix: x[2] }); });
		});
		// 3. Your own changes.
		Array.prototype.forEach.call(document.querySelectorAll('[' + A + '-rule]'), function (el) {
			add(el, 'user', TYPE[typeOf(el)] + ' · δική σας αλλαγή ' + q(nameOf(el)), { fix: 'rule' });
		});
		list.sort(function (a, b) {
			if (a.status !== b.status) return RANK[a.status] - RANK[b.status];
			if (a.el === b.el) return 0;
			return a.el.compareDocumentPosition(b.el) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
		});
		list.forEach(function (it, i) { it.n = i + 1; it.clips = null; });
		return list;
	}

	function loadChecker() {
		return new Promise(function (resolve) {
			if (typeof window.abtCheck === 'function' || !D.checker) { resolve(); return; }
			var s = document.createElement('script');
			s.src = D.checker;
			s.setAttribute('data-abt-ui', '');
			s.onload = s.onerror = function () { resolve(); };
			document.head.appendChild(s);
		});
	}

	/* ---------------- Where a spot is on screen ---------------- */

	function clipAncestors(el) {
		var list = [];
		for (var e = el.parentElement; e && e !== document.body && e !== document.documentElement; e = e.parentElement) {
			var s = window.getComputedStyle(e);
			if (s.overflowX !== 'visible' || s.overflowY !== 'visible') list.push(e);
		}
		return list;
	}
	function where(it) {
		var el = it.el;
		if (!el.isConnected || el === document.documentElement) return null;
		var r = el.getBoundingClientRect();
		if (!r.width && !r.height) return null;
		if (window.getComputedStyle(el).visibility === 'hidden') return null;
		if (!it.clips) it.clips = clipAncestors(el);
		var x = r.left, y = r.top;
		for (var i = 0; i < it.clips.length; i++) {
			var c = it.clips[i].getBoundingClientRect();
			if (x + Math.min(r.width, 20) < c.left || x > c.right || y + Math.min(r.height, 20) < c.top || y > c.bottom) return null;
			x = Math.max(x, c.left);
			y = Math.max(y, c.top);
		}
		return { x: x, y: y, w: r.width, h: r.height };
	}

	/* ---------------- Marks, outlines, hover ---------------- */

	function shown(it) { return filter === 'all' || filter === it.status; }

	function placeMarks() {
		frame = 0;
		if (!on || !marks) return;
		var pos = items.map(function (it) { return shown(it) ? where(it) : null; });
		items.forEach(function (it, i) {
			var b = it.badge;
			if (!b) return;
			var p = pos[i];
			if (!p) { b.hidden = true; return; }
			b.hidden = false;
			b.style.transform = 'translate(' + Math.round(Math.max(0, p.x - 10)) + 'px,' + Math.round(Math.max(0, p.y - 10)) + 'px)';
		});
		placeTag();
	}
	function queue() { if (!frame) frame = window.requestAnimationFrame(placeMarks); }

	function buildMarks() {
		if (marks) marks.remove();
		marks = document.createElement('div');
		marks.className = 'abt-insp-marks';
		marks.setAttribute('data-abt-ui', '');
		hoverBox = document.createElement('div');
		hoverBox.className = 'abt-insp-hover';
		hoverBox.hidden = true;
		tag = document.createElement('div');
		tag.className = 'abt-insp-tag';
		tag.hidden = true;
		marks.appendChild(hoverBox);
		marks.appendChild(tag);
		items.forEach(function (it) {
			var b = document.createElement('button');
			b.type = 'button';
			b.className = 'abt-insp-mark s-' + it.status;
			b.textContent = it.n;
			b.setAttribute('aria-label', it.n + '. ' + STATUS.filter(function (s) { return s.id === it.status; })[0].short + ': ' + it.title.replace(/[«»]/g, ''));
			b.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); edit(it.el); });
			it.badge = b;
			marks.appendChild(b);
		});
		document.body.appendChild(marks);
		placeMarks();
	}

	function outline() {
		Array.prototype.forEach.call(document.querySelectorAll('[data-abt-insp], [data-abt-insp-open]'), function (el) { el.removeAttribute('data-abt-insp'); el.removeAttribute('data-abt-insp-open'); });
		if (!on) return;
		items.forEach(function (it) { if (shown(it) && it.el.isConnected && it.el !== document.documentElement) it.el.setAttribute('data-abt-insp', it.status); });
		if (current && current.el.isConnected && current.el !== document.documentElement) current.el.setAttribute('data-abt-insp-open', '');
	}

	function targetFor(node) {
		if (!node || node.nodeType !== 1 || inUI(node)) return null;
		var img = node.closest('img');
		var ctl = node.closest('a[href], button, [role="button"], input, select, textarea, label');
		if (ctl && ctl !== document.body) {
			if (img && ctl.tagName === 'A') return img;
			return ctl;
		}
		var svg = node.closest('svg');
		if (svg) return svg;
		if (img) return img;
		var heading = node.closest('h1,h2,h3,h4,h5,h6');
		if (heading) return heading;
		for (var e = node; e && e !== document.body; e = e.parentElement) {
			for (var c = e.firstChild; c; c = c.nextSibling) if (c.nodeType === 3 && /\S/.test(c.nodeValue)) return e;
			if (e.hasAttribute(A + '-bg')) return e;
		}
		return null;
	}

	function placeBox(box, el, text) {
		if (!box) return;
		if (!el || !el.isConnected || el === document.documentElement) { box.hidden = true; return; }
		var r = el.getBoundingClientRect();
		if (!r.width && !r.height) { box.hidden = true; return; }
		box.hidden = false;
		if (box === hoverBox) {
			box.style.transform = 'translate(' + Math.round(r.left) + 'px,' + Math.round(r.top) + 'px)';
			box.style.width = Math.round(r.width) + 'px';
			box.style.height = Math.round(r.height) + 'px';
		} else {
			box.textContent = text;
			box.style.transform = 'translate(' + Math.round(Math.max(0, r.left)) + 'px,' + Math.round(Math.max(0, r.top - 22)) + 'px)';
		}
	}
	function placeTag() {
		if (current) placeBox(tag, current.el, TYPE[current.type] + ' · επιλεγμένο');
		else if (lastHover) placeBox(tag, lastHover, TYPE[typeOf(lastHover)] + ' · κλικ για αλλαγή');
		else if (tag) tag.hidden = true;
		placeBox(hoverBox, lastHover, '');
	}

	function onMove(e) {
		if (!on || drag) return;
		var t = targetFor(e.target);
		if (t === lastHover) return;
		lastHover = t;
		queue();
	}

	/* ---------------- AJAX ---------------- */

	function post(action, data) {
		// Names and alt texts belong to the language of the page they were written on.
		if (action === 'abt_a11y_rule' && (data.kind === 'name' || data.kind === 'alt') && data.lang === undefined) data.lang = CFG().lang || '';
		var fd = new FormData();
		fd.append('action', action);
		fd.append('nonce', D.nonce || '');
		for (var k in data) if (Object.prototype.hasOwnProperty.call(data, k)) fd.append(k, data[k]);
		return fetch(D.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
	}
	function reloadKeepingEditor() {
		window.setTimeout(function () { window.location.hash = 'abt-a11y-inspect'; window.location.reload(); }, 600);
	}

	/* ---------------- Panel: list ---------------- */

	function chips() {
		var counts = { all: items.length };
		items.forEach(function (it) { counts[it.status] = (counts[it.status] || 0) + 1; });
		var html = '<div class="abt-insp-chips" role="group" aria-label="Φίλτρο">';
		html += '<button type="button" class="abt-insp-chip' + (filter === 'all' ? ' is-on' : '') + '" data-filter="all" aria-pressed="' + (filter === 'all') + '">Όλα <b>' + counts.all + '</b></button>';
		STATUS.forEach(function (s) {
			if (!counts[s.id]) return;
			html += '<button type="button" class="abt-insp-chip s-' + s.id + (filter === s.id ? ' is-on' : '') + '" data-filter="' + s.id + '" aria-pressed="' + (filter === s.id) + '"><i></i>' + s.short + ' <b>' + counts[s.id] + '</b></button>';
		});
		return html + '</div>';
	}
	function bulk() {
		var svg = count('[' + A + '="svg-hidden"]'), dec = count('[' + A + '="alt-empty"]'), out = [];
		if (svg) out.push(svg + (svg === 1 ? ' εικονίδιο SVG κρύφτηκε' : ' εικονίδια SVG κρύφτηκαν') + ' από τους αναγνώστες οθόνης ως διακοσμητικά');
		if (dec) out.push(dec + (dec === 1 ? ' εικόνα ορίστηκε' : ' εικόνες ορίστηκαν') + ' ως διακοσμητικές, γιατί δίπλα υπάρχει ήδη κείμενο');
		return out.length ? '<p class="abt-insp-small abt-insp-bulk">Επίσης: ' + out.join('. ') + '. Κλικ πάνω τους στη σελίδα για αλλαγή.</p>' : '';
	}
	function renderList() {
		stopLive();
		current = null;
		var errors = items.filter(function (it) { return it.status === 'error'; }).length;
		var html = '<p class="abt-insp-lead">' + (errors ? '<strong class="abt-insp-bad">' + errors + (errors === 1 ? ' σφάλμα μένει' : ' σφάλματα μένουν') + '</strong>' : '<strong class="abt-insp-good">Κανένα σφάλμα WAVE</strong>') +
			' σε αυτή τη σελίδα. Κλικ σε σημάδι ή σε <em>οποιοδήποτε</em> σημείο της σελίδας για να το αλλάξετε.</p>' + chips();
		var group = '';
		items.forEach(function (it, i) {
			if (!shown(it)) return;
			if (it.status !== group) {
				if (group) html += '</ul>';
				group = it.status;
				var s = STATUS.filter(function (x) { return x.id === group; })[0];
				html += '<h3 class="abt-insp-h">' + esc(s.label) + '</h3>' + (s.hint ? '<p class="abt-insp-small">' + esc(s.hint) + '</p>' : '') + '<ul class="abt-insp-list">';
			}
			var hidden = !where(it) && it.el !== document.documentElement;
			html += '<li><button type="button" class="abt-insp-row" data-i="' + i + '"><span class="abt-insp-num s-' + it.status + '">' + it.n + '</span><span class="abt-insp-t"><small class="abt-insp-type">' + esc(TYPE[it.type]) + '</small>' + it.title +
				(hidden ? '<small>Δεν φαίνεται τώρα (κλειστό μενού, άλλο slide ή έκδοση κινητού)</small>' : '') + '</span></button></li>';
		});
		if (group) html += '</ul>';
		if (!items.length) html += '<p>Δεν υπάρχει τίποτα σημειωμένο σε αυτή τη σελίδα.</p>';
		html += bulk() + '<p class="abt-insp-foot"><a href="' + esc(offUrl()) + '">Η σελίδα χωρίς διορθώσεις</a> · ' + link('', 'Ρυθμίσεις') + ' · ' + link('#abt-page-changes', 'Όλες οι αλλαγές σας') + '</p>';
		body.innerHTML = html;
		panel.querySelector('.abt-insp-title').textContent = 'Προσβασιμότητα σελίδας';
		panel.querySelector('.abt-insp-back').hidden = true;
		outline();
		queue();
	}
	function offUrl() {
		var u = new URL(window.location.href);
		u.hash = '';
		u.searchParams.set('abt-a11y', 'off');
		return u.toString();
	}

	/* ---------------- Panel: editor for one element ---------------- */

	function itemFor(el) { for (var i = 0; i < items.length; i++) if (items[i].el === el) return items[i]; return null; }

	function statusBox(it, el) {
		var under = el && el.closest && el.closest('[' + A + '-bg="keep"], [' + A + '-bg="image"]');
		if (!it && under && under !== el) return '<div class="abt-ed-status s-auto">Το WAVE δεν δείχνει σφάλμα εδώ: το plugin έβαλε σκούρο χρώμα κάτω από τη φωτογραφία, που δεν φαίνεται.</div>';
		if (!it) return '<div class="abt-ed-status s-none">Εδώ δεν βρέθηκε σφάλμα και το plugin δεν άλλαξε κάτι.</div>';
		var html = '';
		it.waves.forEach(function (w) {
			html += '<div class="abt-ed-status s-error"><strong>Σφάλμα WAVE:</strong> ' + esc(WAVE[w.wave] || w.wave) +
				(w.wave === 'contrast' ? ' (' + num(w.ratio) + ':1, χρειάζεται ' + num(w.need) + ':1)' : '') + '</div>';
		});
		it.fixes.forEach(function (f) {
			var t = FIX[f] || (/^empty-h/.test(f) ? 'Η επικεφαλίδα ήταν άδεια και έγινε απλό στοιχείο, με την ίδια εμφάνιση.' : '');
			if (t) html += '<div class="abt-ed-status s-' + (f === 'rule' ? 'user' : REVIEW.test(f) ? 'review' : 'auto') + '">' + esc(t) + '</div>';
		});
		return html || '<div class="abt-ed-status s-none">Εδώ δεν βρέθηκε σφάλμα.</div>';
	}

	function scopeHtml(el, extra) {
		extra = extra || [];
		var similar = count(similarSelector(el));
		var html = '<fieldset class="abt-ed-field"><legend>Πού ισχύει</legend>';
		extra.forEach(function (x, i) {
			html += '<label class="abt-ed-opt"><input type="radio" name="abt-where" value="' + esc(x.value) + '"' + (i === 0 ? ' checked' : '') + '> ' + x.label + '</label>';
		});
		html += '<label class="abt-ed-opt"><input type="radio" name="abt-where" value="one"' + (!extra.length ? ' checked' : '') + '> Μόνο σε αυτό το σημείο</label>';
		if (similar > 1) html += '<label class="abt-ed-opt"><input type="radio" name="abt-where" value="similar"> Σε όλα τα όμοια σημεία (' + similar + ' σε αυτή τη σελίδα)</label>';
		html += '<label class="abt-ed-opt abt-ed-site"><input type="checkbox" name="abt-site"' + (sitewide(el) ? ' checked' : '') + '> Σε όλες τις σελίδες του site' + (sitewide(el) ? ' <small>(είναι στο header/footer)</small>' : '') + '</label>';
		return html + '</fieldset>';
	}
	function readScope(root, el) {
		var w = (root.querySelector('input[name="abt-where"]:checked') || {}).value || 'one';
		var site = root.querySelector('input[name="abt-site"]');
		return { where: w, sel: w === 'similar' ? similarSelector(el) : uniqueSelector(el), scope: site && site.checked ? 'site' : (CFG().path || '/') };
	}

	function chipsFor(list) {
		var seen = {}, out = [];
		list.forEach(function (s) { s = clean(s); if (s && !seen[s.toLowerCase()] && s.length < 140) { seen[s.toLowerCase()] = 1; out.push(s); } });
		return out.length ? '<div class="abt-ed-sugg"><span>Προτάσεις:</span>' + out.slice(0, 6).map(function (s) { return '<button type="button" class="abt-ed-chip" data-fill="' + esc(s) + '">' + esc(cut(s, 48)) + '</button>'; }).join('') + '</div>' : '';
	}
	function nameField(id, label, value, sugg) {
		return '<p class="abt-ed-p"><label class="abt-ed-lbl" for="' + id + '">' + esc(label) + '</label><input id="' + id + '" class="abt-ed-input" type="text" value="' + esc(value || '') + '"></p><div class="abt-ed-sugg-wrap">' + chipsFor(sugg) + '</div>';
	}
	function nearbyHeading(el) {
		for (var e = el.parentElement, i = 0; e && e !== document.body && i < 5; e = e.parentElement, i++) {
			var h = e.querySelector('h1,h2,h3,h4,h5,h6,.product-title,.woocommerce-loop-product__title,.wd-entities-title');
			if (h && !h.contains(el) && textOf(h)) return textOf(h);
		}
		return '';
	}
	function buttonWords() {
		var s = CFG().strings || {};
		return ['menu', 'close', 'openSearch', 'submit', 'next', 'prev', 'cart', 'account', 'wishlist', 'share', 'backToTop', 'expand'].map(function (k) { return s[k]; }).filter(Boolean);
	}
	function fail(text) { return Promise.resolve({ r: { success: false, data: { message: text } } }); }

	/* Each editor returns { html, init(root), save(root) -> Promise, cancel() }. */

	// Backing for text over a photo: the lightest colour + opacity that still gives the
	// text enough contrast where the photo is at its brightest (or darkest).
	/* ---------------- What a reader sees behind text over a photo ----------------
	 * WAVE does not look at photos, so the editor measures the page itself: at points spread
	 * over the text's lines it finds the photo, the video frame or the colour underneath, adds
	 * the overlays drawn on top of it (Elementor overlays, gradients) and computes the
	 * contrast at the lightest (or darkest) spot. */

	function over(a, b) {
		var A = a.a + b.a * (1 - a.a);
		if (!A) return { r: 0, g: 0, b: 0, a: 0 };
		return { r: (a.r * a.a + b.r * b.a * (1 - a.a)) / A, g: (a.g * a.a + b.g * b.a * (1 - a.a)) / A, b: (a.b * a.a + b.b * b.a * (1 - a.a)) / A, a: A };
	}
	function mix(a, b, f) {
		var A = a.a * (1 - f) + b.a * f;
		if (!A) return { r: 0, g: 0, b: 0, a: 0 };
		return { r: (a.r * a.a * (1 - f) + b.r * b.a * f) / A, g: (a.g * a.a * (1 - f) + b.g * b.a * f) / A, b: (a.b * a.a * (1 - f) + b.b * b.a * f) / A, a: A };
	}
	function splitTop(str) {
		var out = [], depth = 0, cur = '';
		for (var i = 0; i < str.length; i++) {
			var ch = str.charAt(i);
			if (ch === '(') depth++;
			if (ch === ')') depth--;
			if (ch === ',' && !depth) { out.push(cur.trim()); cur = ''; } else cur += ch;
		}
		if (cur.trim()) out.push(cur.trim());
		return out;
	}
	function colorStop(part) {
		var m = /^(rgba?\([^)]*\)|#[0-9a-f]{3,8}|transparent)\s*(.*)$/i.exec(String(part).trim());
		if (!m) return null;
		var c = m[1].toLowerCase() === 'transparent' ? { r: 0, g: 0, b: 0, a: 0 } : parse(m[1]);
		return c ? { c: c, pos: m[2] ? m[2].split(/\s+/)[0] : null } : null;
	}
	function angleOf(v) {
		var n = parseFloat(v);
		if (/turn$/.test(v)) return n * 360;
		if (/grad$/.test(v)) return n * 0.9;
		if (/rad$/.test(v)) return n * 180 / Math.PI;
		return n;
	}
	function sideAngle(v, w, h) {
		var d = Math.atan2(h, w) * 180 / Math.PI, t = /top/.test(v), b = /bottom/.test(v), l = /left/.test(v), r = /right/.test(v);
		if (t && r) return 90 - d;
		if (b && r) return 90 + d;
		if (b && l) return 270 - d;
		if (t && l) return 270 + d;
		return t ? 0 : r ? 90 : l ? 270 : 180;
	}
	// Colour of a CSS gradient at (x, y) inside a w × h box. Radial and conic gradients are
	// averaged (approximate).
	function gradientAt(str, w, h, x, y) {
		var m = /^(?:repeating-)?(linear|radial|conic)-gradient\((.*)\)$/.exec(String(str).trim());
		if (!m) return null;
		var parts = splitTop(m[2]), angle = 180, first = parts[0] || '';
		if (m[1] === 'linear') {
			if (/^-?[\d.]+(deg|turn|rad|grad)$/.test(first)) { angle = angleOf(first); parts.shift(); } else if (/^to\s/.test(first)) { angle = sideAngle(first, w, h); parts.shift(); }
		} else if (!colorStop(first)) parts.shift();
		var stops = parts.map(colorStop).filter(Boolean);
		if (!stops.length) return null;
		var rad = angle * Math.PI / 180;
		var len = m[1] === 'linear' ? Math.abs(w * Math.sin(rad)) + Math.abs(h * Math.cos(rad)) : 0;
		stops.forEach(function (s) { s.p = s.pos === null ? null : /%$/.test(s.pos) ? parseFloat(s.pos) / 100 : /px$/.test(s.pos) && len ? parseFloat(s.pos) / len : null; });
		if (stops[0].p === null) stops[0].p = 0;
		if (stops[stops.length - 1].p === null) stops[stops.length - 1].p = 1;
		for (var i = 1; i < stops.length - 1; i++) {
			if (stops[i].p !== null) continue;
			var j = i;
			while (stops[j].p === null) j++;
			for (var k = i; k < j; k++) stops[k].p = stops[i - 1].p + (stops[j].p - stops[i - 1].p) * (k - i + 1) / (j - i + 1);
		}
		if (m[1] !== 'linear') return stops.reduce(function (acc, s, n) { return n ? mix(acc, s.c, 1 / (n + 1)) : s.c; }, null);
		var t = len ? ((x - w / 2) * Math.sin(rad) - (y - h / 2) * Math.cos(rad)) / len + 0.5 : 0.5;
		if (t <= stops[0].p) return stops[0].c;
		for (var n = 1; n < stops.length; n++) {
			if (t <= stops[n].p) {
				var span = stops[n].p - stops[n - 1].p;
				return mix(stops[n - 1].c, stops[n].c, span > 0 ? (t - stops[n - 1].p) / span : 1);
			}
		}
		return stops[stops.length - 1].c;
	}

	// Pixels of a photo or video frame, scaled down for sampling. Null when the browser does
	// not allow reading them (a photo from another site without CORS).
	function grab(source, w, h) {
		if (!w || !h) return null;
		var k = Math.min(1, 480 / Math.max(w, h));
		var cv = document.createElement('canvas');
		cv.width = Math.max(1, Math.round(w * k));
		cv.height = Math.max(1, Math.round(h * k));
		try {
			var cx = cv.getContext('2d', { willReadFrequently: true });
			cx.drawImage(source, 0, 0, cv.width, cv.height);
			return { w: cv.width, h: cv.height, nw: w, nh: h, k: k, d: cx.getImageData(0, 0, cv.width, cv.height).data };
		} catch (e) { return null; }
	}
	var picCache = {};
	function loadPic(src) {
		if (!picCache[src]) {
			picCache[src] = new Promise(function (resolve) {
				var im = new Image();
				try { if (new URL(src, window.location.href).origin !== window.location.origin) im.crossOrigin = 'anonymous'; } catch (e) { /* keep */ }
				im.onload = function () { resolve(grab(im, im.naturalWidth, im.naturalHeight)); };
				im.onerror = function () { resolve(null); };
				im.src = src;
			});
		}
		return picCache[src];
	}
	// Average colour around natural-image point (x, y), over radius r (natural px).
	function pickAt(pic, x, y, r) {
		var steps = r * pic.k > 1 ? 4 : 0, n = 0, R = 0, G = 0, B = 0, Al = 0;
		for (var i = -steps; i <= steps; i++) {
			for (var j = -steps; j <= steps; j++) {
				var px = Math.max(0, Math.min(pic.w - 1, Math.round((x + (steps ? i * r / steps : 0)) * pic.k)));
				var py = Math.max(0, Math.min(pic.h - 1, Math.round((y + (steps ? j * r / steps : 0)) * pic.k)));
				var o = (py * pic.w + px) * 4, a = pic.d[o + 3] / 255;
				R += pic.d[o] * a; G += pic.d[o + 1] * a; B += pic.d[o + 2] * a; Al += a; n++;
			}
		}
		return Al ? { r: R / Al, g: G / Al, b: B / Al, a: Al / n } : { r: 0, g: 0, b: 0, a: 0 };
	}
	function lenOf(v, base) {
		v = String(v || '').trim();
		var m;
		if ((m = /^(-?[\d.]+)%$/.exec(v))) return base * parseFloat(m[1]) / 100;
		if ((m = /^(-?[\d.]+)px$/.exec(v))) return parseFloat(m[1]);
		if ((m = /^calc\((-?[\d.]+)%\s*([+-])\s*(-?[\d.]+)px\)$/.exec(v))) return base * parseFloat(m[1]) / 100 + (m[2] === '-' ? -1 : 1) * parseFloat(m[3]);
		if (v === 'left' || v === 'top') return 0;
		if (v === 'right' || v === 'bottom') return base;
		return base / 2;
	}
	function fitted(mode, bw, bh, nw, nh) {
		var k;
		if (mode === 'cover') k = Math.max(bw / nw, bh / nh);
		else if (mode === 'contain') k = Math.min(bw / nw, bh / nh);
		else if (mode === 'scale-down') k = Math.min(1, bw / nw, bh / nh);
		else if (mode === 'none' || mode === 'auto') k = 1;
		else return { w: bw, h: bh };
		return { w: nw * k, h: nh * k };
	}
	function bgSize(spec, bw, bh, nw, nh) {
		spec = String(spec || 'auto').split(',')[0].trim();
		if (spec === 'cover' || spec === 'contain') return fitted(spec, bw, bh, nw, nh);
		var p = spec.split(/\s+/);
		var W = p[0] === 'auto' ? null : lenOf(p[0], bw), H = !p[1] || p[1] === 'auto' ? null : lenOf(p[1], bh);
		if (W === null && H === null) return { w: nw, h: nh };
		if (W === null) W = nw * H / nh;
		if (H === null) H = nh * W / nw;
		return { w: W, h: H };
	}
	// A point of the page in an element's own coordinates (inside the border), undoing scale.
	function local(e, x, y) {
		var r = e.getBoundingClientRect();
		var sx = e.offsetWidth ? r.width / e.offsetWidth : 1, sy = e.offsetHeight ? r.height / e.offsetHeight : 1;
		return { x: (x - r.left) / (sx || 1) - e.clientLeft, y: (y - r.top) / (sy || 1) - e.clientTop };
	}
	// Where a page point falls in the photo: natural-image coordinates and natural px per CSS px.
	function mediaSpot(geo, nw, nh) {
		var d = fitted(geo.fit, geo.bw, geo.bh, nw, nh);
		var ix = (geo.x - lenOf(geo.pos[0], geo.bw - d.w)) / d.w * nw, iy = (geo.y - lenOf(geo.pos[1] || '50%', geo.bh - d.h)) / d.h * nh;
		return ix < 0 || iy < 0 || ix > nw || iy > nh ? null : { x: ix, y: iy, k: nw / d.w };
	}
	function bgSpot(geo, nw, nh) {
		var d = bgSize(geo.size, geo.bw, geo.bh, nw, nh);
		var ix = (geo.x - lenOf(geo.pos[0], geo.bw - d.w)) / d.w * nw, iy = (geo.y - lenOf(geo.pos[1], geo.bh - d.h)) / d.h * nh;
		var rep = geo.repeat.split(/\s+/);
		if (rep.length === 1) rep = rep[0] === 'repeat-x' ? ['repeat', 'no-repeat'] : rep[0] === 'repeat-y' ? ['no-repeat', 'repeat'] : [rep[0], rep[0]];
		if (rep[0] !== 'no-repeat') ix = ((ix % nw) + nw) % nw;
		if (rep[1] !== 'no-repeat') iy = ((iy % nh) + nh) % nh;
		return ix < 0 || iy < 0 || ix > nw || iy > nh ? null : { x: ix, y: iy, k: nw / d.w };
	}
	function opacityBetween(e, el) {
		var op = 1;
		for (var p = e; p && p.nodeType === 1 && !p.contains(el); p = p.parentElement) op *= parseFloat(window.getComputedStyle(p).opacity) || 0;
		return op;
	}
	// An overlay drawn by ::before / ::after (Elementor background overlay and the like).
	function pseudoLayer(e, which, x, y) {
		var s = window.getComputedStyle(e, which);
		if (!s || s.content === 'none' || s.content === 'normal' || s.display === 'none' || s.visibility === 'hidden') return null;
		if (s.position !== 'absolute' && s.position !== 'fixed') return null;
		var op = parseFloat(s.opacity);
		if (isNaN(op)) op = 1;
		var c = parse(s.backgroundColor), grads = s.backgroundImage && s.backgroundImage !== 'none' ? splitTop(s.backgroundImage).filter(function (g) { return /gradient\(/.test(g); }) : [];
		if (op < 0.03 || (!(c && c.a > 0) && !grads.length)) return null;
		var r = e.getBoundingClientRect(), L = parseFloat(s.left), T = parseFloat(s.top), W = parseFloat(s.width), H = parseFloat(s.height);
		var box = { left: r.left + (isNaN(L) ? 0 : L), top: r.top + (isNaN(T) ? 0 : T), w: isNaN(W) ? r.width : W, h: isNaN(H) ? r.height : H };
		if (x < box.left || y < box.top || x > box.left + box.w || y > box.top + box.h) return null;
		var col = c && c.a > 0 ? c : null;
		for (var i = grads.length - 1; i >= 0; i--) {
			var g = gradientAt(grads[i], box.w, box.h, x - box.left, y - box.top);
			if (g) col = col ? over(g, col) : g;
		}
		if (!col) return null;
		col = { r: col.r, g: col.g, b: col.b, a: col.a * op };
		return { col: col, approx: (s.mixBlendMode && s.mixBlendMode !== 'normal') || (s.filter && s.filter !== 'none') || grads.some(function (g) { return !/^linear/.test(g); }) };
	}
	// What lies under one point of a text element, top to bottom. elementsFromPoint lists each
	// element once, where it is first hit: a container whose ::before overlay sits above its
	// background video is listed before the video. Its own background, though, is painted
	// under everything inside it, so it is taken after the last of its descendants.
	function probe(x, y, el) {
		var stack = document.elementsFromPoint(x, y), i = stack.indexOf(el);
		if (i < 0) return null;
		var list = stack.slice(i + 1).filter(function (e) { return e instanceof HTMLElement && !inUI(e); });
		var tails = list.map(function () { return []; });
		list.forEach(function (e, j) {
			var last = j;
			for (var k = j + 1; k < list.length; k++) if (e.contains(list[k])) last = k;
			tails[last].push(j);
		});
		var order = [];
		list.forEach(function (e, j) {
			order.push({ e: e, own: false });
			// Own backgrounds: the innermost first.
			tails[j].sort(function (m, n) { return n - m; }).forEach(function (m) { order.push({ e: list[m], own: true }); });
		});
		var pt = { x: x, y: y, layers: [], approx: false };
		function add(l) { if (l) { pt.layers.push(l); if (l.approx) pt.approx = true; } }
		for (var n = 0; n < order.length; n++) {
			var e = order[n].e;
			var op = opacityBetween(e, el);
			if (op < 0.03) continue;
			var s = window.getComputedStyle(e);
			if (!order[n].own) {
				if ((s.filter && s.filter !== 'none') || (s.mixBlendMode && s.mixBlendMode !== 'normal')) pt.approx = true;
				add(pseudoLayer(e, '::after', x, y));
				add(pseudoLayer(e, '::before', x, y));
				continue;
			}
			var photo = null;
			if (e.matches('img, video, canvas')) {
				var L = local(e, x, y), pl = parseFloat(s.paddingLeft) || 0, pt0 = parseFloat(s.paddingTop) || 0;
				photo = { media: e, geo: { x: L.x - pl, y: L.y - pt0, bw: e.clientWidth - pl - (parseFloat(s.paddingRight) || 0), bh: e.clientHeight - pt0 - (parseFloat(s.paddingBottom) || 0), fit: s.objectFit, pos: s.objectPosition.split(/\s+/) } };
			} else if (e.matches('iframe')) {
				photo = { unknown: true };
			} else if (s.backgroundImage && s.backgroundImage !== 'none') {
				var imgs = splitTop(s.backgroundImage), box = e.getBoundingClientRect();
				for (var k = 0; k < imgs.length && !photo; k++) {
					var u = /^url\(\s*["']?([^"')]+)["']?\s*\)$/.exec(imgs[k]);
					if (u) {
						var fixed = /fixed/.test(s.backgroundAttachment.split(',')[0]), P = local(e, x, y);
						photo = { url: u[1], geo: { x: fixed ? x : P.x, y: fixed ? y : P.y, bw: fixed ? document.documentElement.clientWidth : e.clientWidth, bh: fixed ? window.innerHeight : e.clientHeight, size: s.backgroundSize, pos: [s.backgroundPositionX.split(',')[0], s.backgroundPositionY.split(',')[0]], repeat: s.backgroundRepeat.split(',')[0].trim() } };
					} else {
						var g = gradientAt(imgs[k], box.width, box.height, x - box.left, y - box.top);
						if (g) add({ col: { r: g.r, g: g.g, b: g.b, a: g.a * op }, src: e, approx: !/^linear/.test(imgs[k]) });
					}
				}
			}
			if (photo) {
				photo.op = op;
				pt.photo = photo;
				return pt;
			}
			var c = parse(s.backgroundColor);
			if (c && c.a > 0) {
				add({ col: { r: c.r, g: c.g, b: c.b, a: c.a * op }, src: e });
				if (c.a * op >= 0.999) return pt;
			}
		}
		pt.layers.push({ col: { r: 255, g: 255, b: 255, a: 1 } });
		return pt;
	}
	function textsIn(root, max) {
		var out = [], w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null), n;
		while ((n = w.nextNode()) && out.length < (max || 12)) {
			if (!/[^\s ]/.test(n.nodeValue)) continue;
			var e = n.parentElement;
			if (!e || inUI(e) || out.indexOf(e) > -1 || e.closest('script, style, noscript, svg, .abt-a11y-sr')) continue;
			var r = e.getBoundingClientRect(), s = window.getComputedStyle(e);
			if (!r.width || !r.height || s.visibility === 'hidden') continue;
			out.push(e);
		}
		return out;
	}
	function samplePoints(el) {
		var range = document.createRange();
		range.selectNodeContents(el);
		var rects = Array.prototype.filter.call(range.getClientRects(), function (r) { return r.width > 3 && r.height > 3; });
		if (!rects.length) rects = [el.getBoundingClientRect()];
		var pts = [], vw = document.documentElement.clientWidth, vh = window.innerHeight;
		rects.slice(0, 8).forEach(function (r) {
			var cols = Math.max(2, Math.min(10, Math.round(r.width / 24)));
			for (var i = 0; i < cols; i++) {
				for (var j = 0; j < 2; j++) {
					var x = r.left + (i + 0.5) * r.width / cols, y = r.top + r.height * (j ? 0.68 : 0.36);
					if (x >= 0 && y >= 0 && x < vw && y < vh) pts.push([x, y]);
				}
			}
		});
		return pts;
	}
	// Measures the texts once. Returns a model whose contrast() answers "what would a reader
	// see with this colour and this backing" instantly, for the live status in the panel.
	function measureTexts(texts) {
		var st = document.createElement('style');
		st.setAttribute('data-abt-ui', '');
		st.textContent = '*,*::before,*::after{pointer-events:auto!important}';
		document.head.appendChild(st);
		var pts = [];
		try {
			texts.forEach(function (t, ti) {
				samplePoints(t).forEach(function (xy) {
					var p = probe(xy[0], xy[1], t);
					if (p) { p.ti = ti; pts.push(p); }
				});
			});
		} finally { st.remove(); }
		var info = texts.map(function (t) {
			var s = window.getComputedStyle(t), fg = parse(s.color) || { r: 0, g: 0, b: 0, a: 1 };
			var op = parseFloat(s.opacity);
			if (!isNaN(op)) fg.a *= op;
			var size = parseFloat(s.fontSize), weight = parseInt(s.fontWeight, 10) || 400;
			return { el: t, fg: fg, need: size >= 24 || (size >= 18.66 && weight >= 700) ? 3 : 4.5 };
		});
		var videos = [];
		var jobs = pts.map(function (p) {
			var ph = p.photo;
			if (!ph) return null;
			if (ph.unknown) return null;
			if (ph.media) {
				var m = ph.media;
				if (m.tagName === 'VIDEO') {
					if (videos.indexOf(m) < 0) videos.push(m);
					return null;
				}
				var nw = m.naturalWidth || m.width, nh = m.naturalHeight || m.height;
				var pic = m.tagName === 'IMG' && m.complete ? grab(m, nw, nh) : m.tagName === 'CANVAS' ? grab(m, m.width, m.height) : null;
				if (pic) { ph.pics = [pic]; return null; }
				if (m.tagName !== 'IMG') return null;
				return loadPic(m.currentSrc || m.src).then(function (pc) { if (pc) ph.pics = [pc]; });
			}
			return loadPic(ph.url).then(function (pc) { if (pc) ph.pics = [pc]; });
		}).filter(Boolean);
		var frames = videos.map(function () { return []; });
		function addFrames() {
			var added = false;
			videos.forEach(function (v, n) {
				if (v.readyState < 2 || frames[n].length >= 10) return;
				var pic = grab(v, v.videoWidth, v.videoHeight);
				if (pic) { frames[n].push(pic); added = true; }
			});
			if (added) pts.forEach(function (p) { if (p.photo && p.photo.media && p.photo.media.tagName === 'VIDEO') { p.photo.pics = frames[videos.indexOf(p.photo.media)]; p.cols = null; } });
			return added;
		}
		// Colours of the photo under point p (one per video frame), blurred by `blur` CSS px.
		function photoColors(p, blur) {
			var key = blur + '';
			if (!p.cols) p.cols = {};
			if (p.cols[key]) return p.cols[key];
			var ph = p.photo, out = null;
			if (ph && ph.pics && ph.pics.length) {
				var nw = ph.pics[0].nw, nh = ph.pics[0].nh;
				var spot = ph.media ? mediaSpot(ph.geo, nw, nh) : bgSpot(ph.geo, nw, nh);
				out = spot ? ph.pics.map(function (pic) {
					var c = pickAt(pic, spot.x, spot.y, Math.max(1.5, blur) * spot.k);
					c = over(c, { r: 255, g: 255, b: 255, a: 1 });
					return ph.op < 1 ? over({ r: c.r, g: c.g, b: c.b, a: ph.op }, { r: 255, g: 255, b: 255, a: 1 }) : c;
				}) : [{ r: 255, g: 255, b: 255, a: 1 }];
			}
			p.cols[key] = out;
			return out;
		}
		var model = {
			texts: texts,
			info: info,
			points: pts,
			videos: videos,
			approx: pts.some(function (p) { return p.approx; }),
			frames: function () { return frames.reduce(function (n, f) { return n + f.length; }, 0); },
			addFrames: addFrames,
			// opt: { only: [text indexes], fg: colour for text 0, plate: {c, a} or null, blur: px, skip: element }
			contrast: function (opt) {
				var worst = null, unread = false;
				var u = RT().util;
				pts.forEach(function (p) {
					if (opt.only && opt.only.indexOf(p.ti) < 0) return;
					var t = info[p.ti], fg = p.ti === 0 && opt.fg ? opt.fg : t.fg;
					var light = u.lum(u.blend(fg, { r: 128, g: 128, b: 128, a: 1 })) > 0.2;
					var cols = p.photo ? photoColors(p, opt.blur || 0) : [null];
					if (!cols) { unread = true; cols = [light ? { r: 255, g: 255, b: 255, a: 1 } : { r: 0, g: 0, b: 0, a: 1 }]; }
					cols.forEach(function (base) {
						var c = base || { r: 255, g: 255, b: 255, a: 1 };
						for (var i = p.layers.length - 1; i >= 0; i--) {
							var l = p.layers[i];
							if (opt.skip && l.src === opt.skip) continue;
							c = over(l.col, c);
						}
						if (opt.plate) c = over({ r: opt.plate.c.r, g: opt.plate.c.g, b: opt.plate.c.b, a: opt.plate.a }, c);
						c.a = 1;
						var r = Math.floor(u.ratio(u.blend(fg, c), c) * 100) / 100;
						var gap = r / t.need;
						if (!worst || gap < worst.gap) worst = { ratio: r, need: t.need, gap: gap, el: t.el };
					});
				});
				if (worst) worst.unread = unread;
				return worst;
			}
		};
		addFrames();
		return Promise.all(jobs).then(function () { return model; });
	}

	function platePlan(orig, need) {
		var u = RT().util, fg = parse(orig);
		var darkText = u.lum(fg) <= 0.4;
		var plate = parse(darkText ? (CFG().imageFallbackLight || '#ffffff') : (CFG().imageFallbackDark || '#1a1a1a'));
		var worst = darkText ? { r: 0, g: 0, b: 0, a: 1 } : { r: 255, g: 255, b: 255, a: 1 };
		var target = need + (typeof CFG().contrastMargin === 'number' ? CFG().contrastMargin : 0.2);
		for (var a = 0.3; a < 0.951; a += 0.05) {
			var r = u.ratio(fg, u.blend({ r: plate.r, g: plate.g, b: plate.b, a: a }, worst));
			if (r >= target || a > 0.94) return { color: hex(plate), alpha: Math.round(a * 100) / 100, worst: Math.floor(r * 100) / 100 };
		}
	}
	// Containers around the text that hold more texts, for one backing behind all of them.
	// Only containers clearly smaller than the photo: a backing over the whole photo would hide it.
	function frameCandidates(el, host) {
		var out = [], hr = host.getBoundingClientRect(), last = 1;
		for (var p = el.parentElement; p && p !== host && host.contains(p); p = p.parentElement) {
			var n = textsIn(p, 20).length;
			if (n <= last) continue;
			var r = p.getBoundingClientRect();
			if (r.width * r.height > hr.width * hr.height * 0.7) break;
			out.push({ el: p, n: n });
			last = n;
			if (out.length === 2) break;
		}
		return out;
	}
	function plateSwatches(orig, need, current) {
		var u = RT().util, fg = parse(orig), light = u.lum(fg) > 0.4;
		var list = [current, light ? (CFG().imageFallbackDark || '#1a1a1a') : (CFG().imageFallbackLight || '#ffffff'), light ? '#000000' : '#ffffff'];
		(CFG().palette || []).forEach(function (p) { list.push(p.to); });
		var freq = {};
		Array.prototype.forEach.call(document.querySelectorAll('body *'), function (x, i) {
			if (i > 1500 || inUI(x)) return;
			var c = window.getComputedStyle(x).backgroundColor;
			if (/rgba\(.*,\s*0\)$|transparent/.test(c)) return;
			freq[c] = (freq[c] || 0) + 1;
		});
		Object.keys(freq).sort(function (a, b) { return freq[b] - freq[a]; }).forEach(function (c) { var p = parse(c); if (p && p.a === 1) list.push(hex(p)); });
		var out = [];
		list.forEach(function (c) {
			var p = c && parse(c);
			if (!p || out.indexOf(hex(p)) > -1 || out.length >= 6) return;
			if (u.ratio(fg, p) >= need) out.push(hex(p));
		});
		return out;
	}

	function textEditor(el) {
		stopLive();
		var info = RT().contrastInfo(el);
		var userColor = el.getAttribute(A + '-u');
		var orig = el.getAttribute(A + '-c') || (info ? hex(info.fg) : '#000000');
		var bg = info && info.bg ? info.bg : null;
		var need = info ? info.need : 4.5;
		var photo = !!(info && info.photo);
		var plan = photo ? platePlan(orig, need) : null;
		var frames = photo ? frameCandidates(el, info.photo.host) : [];
		var opts = [];
		if (photo && info.photo.covers) opts.push({ id: 'keep', color: orig, label: 'Χωρίς αλλαγή στην εμφάνιση · σκούρο χρώμα κάτω από τη φωτογραφία, που δεν φαίνεται' });
		if (photo) opts.push({ id: 'plate', color: orig, label: 'Το χρώμα σας · φόντο πίσω από το κείμενο' });
		if (bg) {
			var sugg = hex(RT().util.adjust(RT().util.blend(parse(orig), bg), bg, need + (info.margin || 0.2)));
			opts.push({ id: 'suggest', color: sugg, label: photo ? 'Άλλο χρώμα: η πλησιέστερη απόχρωση που περνάει στο WAVE' : 'Προτεινόμενο: η πλησιέστερη απόχρωση που περνάει' });
			var freq = {};
			Array.prototype.forEach.call(document.querySelectorAll('body *'), function (x, i) {
				if (i > 1500 || !x.firstChild || x.firstChild.nodeType !== 3 || inUI(x)) return;
				var c = window.getComputedStyle(x).color;
				freq[c] = (freq[c] || 0) + 1;
			});
			var used = Object.keys(freq).sort(function (a, b) { return freq[b] - freq[a]; }).map(function (c) { return hex(parse(c)); });
			(CFG().palette || []).forEach(function (p) { used.unshift(p.to); });
			var picked = {};
			picked[sugg] = 1;
			used.forEach(function (c) {
				if (picked[c] || opts.length > 6) return;
				picked[c] = 1;
				if (ratioOf(parse(c), bg) >= need) opts.push({ id: 'site', color: c, label: 'Χρώμα που υπάρχει ήδη στο site' });
			});
		}
		opts.push({ id: 'custom', color: userColor || orig, label: 'Δικό μου χρώμα' });

		// A backing saved earlier, on this text or on a frame around it.
		var start = 0, onFrame = 0, saved = null;
		[el].concat(frames.map(function (f) { return f.el; })).some(function (x, i) {
			var v = RT().parsePlate(x.getAttribute(A + '-plate') || '');
			if (v) { saved = v; onFrame = i; }
			return !!v;
		});
		var pl = { c: saved ? hex(saved.color) : plan ? plan.color : '#1a1a1a', a: saved ? saved.alpha : plan ? plan.alpha : 0.6, blur: saved ? saved.blur : 0, touched: !!saved };
		opts.forEach(function (o, i) { if (saved && o.id === 'plate') start = i; });
		var swatches = photo ? plateSwatches(orig, need, pl.c) : [];

		var sampleBg = photo ? 'linear-gradient(90deg,#e9e9e9,#6d6d6d)' : (bg ? hex(bg) : '#fff');
		var html = '<div class="abt-ed-sample" style="background:' + esc(sampleBg) + '"><span style="color:' + esc(window.getComputedStyle(el).color) + '">' + esc(cut(textOf(el), 60) || 'Κείμενο') + '</span></div>' +
			'<p class="abt-insp-small">' + (userColor ? 'Τρέχον χρώμα (δική σας αλλαγή) ' : 'Αρχικό χρώμα ') + sw(orig) + esc(orig) +
			(photo ? ' · πάνω σε φωτογραφία' : bg ? ' · φόντο ' + sw(hex(bg)) + esc(hex(bg)) : ' · φόντο με διαβάθμιση ή διαφάνεια') + ' · ' + (info && info.large ? 'μεγάλο κείμενο, χρειάζεται 3:1' : 'κανονικό κείμενο, χρειάζεται 4,5:1') + '</p>' +
			(photo ? '<p class="abt-ed-note">Το WAVE δεν βλέπει τη φωτογραφία: μετράει σαν το φόντο να ήταν ' + esc(bg ? hex(bg) : 'λευκό') + '. Γι’ αυτό το plugin μετράει και την πραγματική αντίθεση πάνω στη φωτογραφία, όπως τη βλέπει ο αναγνώστης.</p>' : '') +
			'<fieldset class="abt-ed-field"><legend>Χρώμα κειμένου</legend>' + opts.map(function (o, i) {
				var r = bg ? ratioOf(parse(o.color), bg) : null;
				var badge = '';
				if (o.id === 'keep') badge = ' <b class="is-ok">✓ στο WAVE</b>';
				else if (o.id !== 'plate' && r !== null) badge = ' <b class="' + (r >= need ? 'is-ok' : 'is-bad') + '">' + num(r) + ':1' + (photo ? ' στο WAVE' : '') + '</b>';
				return '<label class="abt-ed-opt abt-ed-color"><input type="radio" name="abt-color" value="' + i + '"' + (i === start ? ' checked' : '') + '> ' + sw(o.id === 'plate' ? pl.c : o.color) + '<span>' + esc(o.label) + (o.id === 'keep' || o.id === 'plate' ? '' : ' <code>' + esc(o.color) + '</code>') + badge + (photo && o.id !== 'plate' ? '<span class="abt-ed-real" data-i="' + i + '"></span>' : '') + '</span>' +
					(o.id === 'custom' ? '<input type="color" class="abt-ed-picker" value="' + esc(o.color) + '" aria-label="Επιλογή χρώματος">' : '') + '</label>';
			}).join('') + '</fieldset>' +
			(photo ? '<div class="abt-ed-plate" hidden>' +
				(frames.length ? '<fieldset class="abt-ed-field"><legend>Πού μπαίνει το φόντο</legend><label class="abt-ed-opt"><input type="radio" name="abt-plate-on" value="0"' + (onFrame === 0 ? ' checked' : '') + '> Πίσω από αυτό το κείμενο</label>' +
					frames.map(function (f, i) { return '<label class="abt-ed-opt"><input type="radio" name="abt-plate-on" value="' + (i + 1) + '"' + (onFrame === i + 1 ? ' checked' : '') + '> Πίσω από ' + (i ? 'μεγαλύτερο πλαίσιο' : 'όλο το πλαίσιο') + ' με ' + f.n + ' κείμενα</label>'; }).join('') + '</fieldset>' : '') +
				'<div class="abt-ed-row"><span class="abt-ed-lbl" id="abt-plate-c-l">Χρώμα φόντου</span><span class="abt-ed-swatches" role="group" aria-labelledby="abt-plate-c-l">' +
					swatches.map(function (c) { return '<button type="button" class="abt-ed-swatch" data-c="' + esc(c) + '" aria-label="' + esc(c) + '" aria-pressed="' + (c === pl.c) + '" style="background:' + esc(c) + '"></button>'; }).join('') +
					'<input type="color" class="abt-ed-plate-c" value="' + esc(pl.c) + '" aria-label="Άλλο χρώμα φόντου"></span></div>' +
				'<div class="abt-ed-row"><label class="abt-ed-lbl" for="abt-plate-a">Αδιαφάνεια</label><input type="range" id="abt-plate-a" class="abt-ed-range" min="5" max="100" step="1" list="abt-plate-ticks" value="' + Math.round(pl.a * 100) + '"><output class="abt-ed-out" for="abt-plate-a">' + Math.round(pl.a * 100) + '%</output></div>' +
				'<datalist id="abt-plate-ticks"></datalist>' +
				'<p class="abt-insp-small abt-ed-enough"></p>' +
				'<div class="abt-ed-live-slot"></div>' +
				'<label class="abt-ed-opt"><input type="checkbox" name="abt-plate-glass"' + (pl.blur ? ' checked' : '') + '> Εφέ γυαλιού: θολώνει τη φωτογραφία πίσω από το φόντο</label>' +
				'<div class="abt-ed-row abt-ed-glass"' + (pl.blur ? '' : ' hidden') + '><label class="abt-ed-lbl" for="abt-plate-b">Θόλωμα</label><input type="range" id="abt-plate-b" class="abt-ed-range abt-ed-blur" min="2" max="24" step="1" value="' + (pl.blur || 8) + '"><output class="abt-ed-out" for="abt-plate-b">' + (pl.blur || 8) + 'px</output></div>' +
				'</div>' : '') +
			'<div class="abt-ed-live" role="status"></div>' +
			'<div class="abt-ed-scope-wrap">' + scopeHtml(el) + '<label class="abt-ed-opt abt-ed-palette"><input type="checkbox" name="abt-palette"> <span>Παντού στο site, το χρώμα ' + sw(orig) + '<code>' + esc(orig) + '</code> να γίνεται το επιλεγμένο</span></label></div>';

		var PROPS = ['color', 'background-color', 'box-shadow', 'border-radius', 'backdrop-filter', '-webkit-backdrop-filter'];
		var touched = [];
		function remember(x) {
			if (touched.some(function (t) { return t.el === x; })) return;
			touched.push({ el: x, props: PROPS.map(function (n) { return { n: n, v: x.style.getPropertyValue(n), p: x.style.getPropertyPriority(n) }; }) });
		}
		function restore() {
			touched.forEach(function (t) { t.props.forEach(function (x) { if (x.v) t.el.style.setProperty(x.n, x.v, x.p); else t.el.style.removeProperty(x.n); }); });
			touched = [];
		}
		function rgba(c, a) { var p = parse(c); return 'rgba(' + p.r + ',' + p.g + ',' + p.b + ',' + a + ')'; }
		var root = null, model = null, applied = false, frameIdx = onFrame;
		var margin = typeof CFG().contrastMargin === 'number' ? CFG().contrastMargin : 0.2;
		function chosen() {
			var o = opts[+((root.querySelector('input[name="abt-color"]:checked') || {}).value || 0)];
			if (o.id === 'custom') o = { id: 'custom', color: root.querySelector('.abt-ed-picker').value };
			return o;
		}
		function target() { return frameIdx ? frames[frameIdx - 1].el : el; }
		function plateValue() { return pl.c + '@' + Math.round(pl.a * 100) / 100 + (pl.blur ? '/' + pl.blur : ''); }
		function only(t) {
			if (!model) return null;
			if (t === el) return [0];
			return model.texts.map(function (x, i) { return t.contains(x) ? i : -1; }).filter(function (i) { return i > -1; });
		}
		function real(o, alpha) {
			if (!model) return null;
			var isPlate = o.id === 'plate', t = isPlate ? target() : el;
			return model.contrast({ only: only(t), fg: o.id === 'keep' || isPlate ? parse(orig) : parse(o.color), plate: isPlate ? { c: parse(pl.c), a: alpha === undefined ? pl.a : alpha } : null, blur: isPlate ? pl.blur : 0, skip: isPlate ? t : null });
		}
		// Worst case when the photo cannot be measured: a white (or black) photo behind the text.
		function worstCase(alpha) {
			var u = RT().util, fg = parse(orig), p = parse(pl.c), back = u.lum(fg) > 0.4 ? { r: 255, g: 255, b: 255, a: 1 } : { r: 0, g: 0, b: 0, a: 1 };
			return Math.floor(u.ratio(fg, u.blend({ r: p.r, g: p.g, b: p.b, a: alpha }, back)) * 100) / 100;
		}
		function minAlpha() {
			for (var a = 5; a <= 100; a++) {
				var r = real({ id: 'plate' }, a / 100);
				if (r ? (!r.unread && r.ratio >= r.need + 0.1) || (r.unread && worstCase(a / 100) >= need + margin) : worstCase(a / 100) >= need + margin) return a;
			}
			return null;
		}
		function waveFor(o) {
			if (o.id === 'keep') return { ok: true, text: 'χωρίς σφάλμα' };
			if (o.id === 'plate') {
				if (pl.a < 1) return { ok: true, text: 'χωρίς σφάλμα', why: 'σε κάθε αδιαφάνεια κάτω από 100%: το WAVE δεν μετράει κείμενο σε ημιδιάφανο φόντο' };
				var texts = model ? model.info.filter(function (x, i) { return (only(target()) || [0]).indexOf(i) > -1; }) : [{ fg: parse(orig), need: need }];
				var worst = null;
				texts.forEach(function (x) { var r = ratioOf(x.el === el ? parse(orig) : x.fg, parse(pl.c)); if (!worst || r / x.need < worst.r / worst.need) worst = { r: r, need: x.need }; });
				return { ok: worst.r >= worst.need, text: num(worst.r) + ':1', why: 'με αδιαφάνεια 100% το WAVE μετράει το κείμενο πάνω στο φόντο' };
			}
			if (!bg) return null;
			var r = ratioOf(parse(o.color), bg);
			return { ok: r >= need, text: num(r) + ':1' };
		}
		function line(label, ok, value, note) {
			return '<p class="abt-ed-l"><span>' + label + '</span> <b class="' + (ok ? 'is-ok' : 'is-bad') + '">' + value + ' ' + (ok ? '✓' : '✕') + '</b>' + (note ? ' <small>' + note + '</small>' : '') + '</p>';
		}
		var enoughKey = null, enough = null;
		function renderEnough() {
			var p = root.querySelector('.abt-ed-enough');
			if (!p) return;
			if (!model) { p.textContent = 'Μέτρηση της φωτογραφίας…'; return; }
			var key = [pl.c, pl.blur, frameIdx, model.frames()].join('|');
			if (key !== enoughKey) { enoughKey = key; enough = minAlpha(); }
			var list = root.querySelector('#abt-plate-ticks');
			list.innerHTML = enough === null ? '' : '<option value="' + enough + '"></option>';
			p.innerHTML = enough === null
				? '<span class="abt-ed-real is-bad">Με αυτό το χρώμα φόντου δεν αρκεί ούτε 100%.</span> Διαλέξτε πιο σκούρο (ή πιο ανοιχτό) χρώμα.'
				: 'Διαβάζεται πάνω στη φωτογραφία από <b>' + enough + '%</b> και πάνω. ' + (Math.round(pl.a * 100) !== enough ? '<button type="button" class="abt-insp-link" data-plate="min">Ορισμός στο ' + enough + '%</button>' : '');
		}
		function render() {
			var o = chosen(), w = waveFor(o), live = root.querySelector('.abt-ed-live'), out = '';
			// While a backing is being set up, its live status sits right under its controls.
			var slot = o.id === 'plate' ? root.querySelector('.abt-ed-live-slot') : root.querySelector('.abt-ed-field');
			if (slot && live.parentNode !== slot && live.previousElementSibling !== slot) {
				if (o.id === 'plate') slot.appendChild(live); else slot.parentNode.insertBefore(live, slot.nextSibling);
			}
			if (o.id === 'plate') renderEnough();
			if (w) out += line('WAVE:', w.ok, w.text, w.why);
			if (photo) {
				if (!model) out += '<p class="abt-ed-l"><span>Πάνω στη φωτογραφία:</span> <small>μέτρηση…</small></p>';
				else {
					var r = real(o);
					if (r) {
						var lightText = RT().util.lum(parse(o.id === 'plate' || o.id === 'keep' ? orig : o.color)) > 0.4;
						var notes = [];
						notes.push('χρειάζεται ' + num(r.need) + ':1');
						if (r.el !== el) notes.push('το πιο δύσκολο: ' + q(textOf(r.el)));
						out += line('Πάνω στη φωτογραφία:', r.ratio >= r.need, num(r.ratio) + ':1', notes.join(' · '));
						var how = r.unread ? 'Η φωτογραφία δεν διαβάζεται από τον browser (π.χ. είναι σε άλλο domain), οπότε υπολογίζεται σαν να ήταν ' + (lightText ? 'λευκή' : 'μαύρη') + ' πίσω από το κείμενο, η χειρότερη περίπτωση.'
							: 'Μετρήθηκε στο πιο ' + (lightText ? 'φωτεινό' : 'σκοτεινό') + ' σημείο πίσω από το κείμενο' + (model.videos.length ? ', στα καρέ του βίντεο που έπαιξαν όσο είναι ανοιχτό το πάνελ (' + model.frames() + ')' : '') + '.' + (model.approx ? ' Κατά προσέγγιση: υπάρχουν φίλτρα ή blend modes.' : '');
						out += '<p class="abt-insp-small abt-ed-how">' + esc(how) + '</p>';
						if (w && w.ok && r.ratio < r.need) {
							out += '<p class="abt-ed-warn">' + (o.id === 'plate' ? 'Το WAVE δεν θα δείξει σφάλμα, αλλά πάνω στη φωτογραφία το κείμενο δεν διαβάζεται αρκετά.' + (enough !== null ? ' Ανεβάστε την αδιαφάνεια τουλάχιστον στο ' + enough + '%.' : '')
								: o.id === 'keep' ? 'Το WAVE δεν θα δείξει σφάλμα, αλλά πάνω στη φωτογραφία το κείμενο δεν διαβάζεται αρκετά. Καλύτερα φόντο πίσω από το κείμενο (επόμενη επιλογή).'
								: 'Περνάει στο WAVE, αλλά πάνω στη φωτογραφία διαβάζεται λιγότερο. Καλύτερα να μείνει το χρώμα σας, με φόντο πίσω από το κείμενο.') + '</p>';
						}
					}
				}
			}
			live.innerHTML = out;
			if (model) {
				Array.prototype.forEach.call(root.querySelectorAll('.abt-ed-real'), function (s) {
					var x = real(opts[+s.getAttribute('data-i')].id === 'custom' ? { id: 'custom', color: root.querySelector('.abt-ed-picker').value } : opts[+s.getAttribute('data-i')]);
					s.className = 'abt-ed-real ' + (x && x.ratio >= x.need ? 'is-ok' : 'is-bad');
					s.textContent = x ? ' · ' + num(x.ratio) + ':1 στη φωτογραφία' : '';
				});
			}
		}
		function update(apply) {
			var o = chosen();
			var span = root.querySelector('.abt-ed-sample span');
			span.style.color = o.color;
			span.style.backgroundColor = o.id === 'plate' ? rgba(pl.c, pl.a) : '';
			span.style.boxShadow = o.id === 'plate' ? '0 0 0 .25em ' + rgba(pl.c, pl.a) : '';
			var box = root.querySelector('.abt-ed-plate');
			if (box) box.hidden = o.id !== 'plate';
			var sw0 = root.querySelector('.abt-ed-color input[value="' + opts.map(function (x) { return x.id; }).indexOf('plate') + '"] + .abt-insp-sw');
			if (sw0) sw0.style.background = pl.c;
			if (apply) {
				applied = true;
				restore();
				if (o.id === 'plate') {
					remember(target());
					RT().plate(target(), plateValue());
				} else if (o.id !== 'keep') {
					remember(el);
					el.style.setProperty('color', o.color, 'important');
				}
				preview = restore;
			}
			root.querySelector('.abt-ed-palette').hidden = o.id === 'keep' || o.id === 'plate';
			render();
		}
		function setAlpha(a) {
			pl.a = Math.max(0.05, Math.min(1, a / 100));
			var range = root.querySelector('.abt-ed-range');
			if (range) { range.value = Math.round(pl.a * 100); root.querySelector('.abt-ed-out').textContent = Math.round(pl.a * 100) + '%'; }
		}
		return {
			html: html,
			init: function (r) {
				root = r;
				root.addEventListener('change', function (e) {
					if (e.target.name === 'abt-plate-on') {
						frameIdx = +e.target.value;
						var fs = root.querySelector('.abt-ed-scope-wrap fieldset');
						if (fs) fs.outerHTML = scopeHtml(target());
					}
					if (e.target.name === 'abt-plate-glass') {
						var gb = root.querySelector('.abt-ed-glass');
						pl.blur = e.target.checked ? +root.querySelector('.abt-ed-blur').value : 0;
						if (gb) gb.hidden = !e.target.checked;
					}
					if (e.target.classList.contains('abt-ed-range')) return;
					update(true);
				});
				root.addEventListener('input', function (e) {
					var t = e.target;
					if (t.classList.contains('abt-ed-blur')) { pl.blur = +t.value; t.nextElementSibling.textContent = t.value + 'px'; update(true); }
					else if (t.classList.contains('abt-ed-range')) { pl.touched = true; setAlpha(+t.value); update(true); }
					else if (t.classList.contains('abt-ed-plate-c')) { pl.c = t.value; Array.prototype.forEach.call(root.querySelectorAll('.abt-ed-swatch'), function (b) { b.setAttribute('aria-pressed', 'false'); }); update(true); }
					else if (t.classList.contains('abt-ed-picker')) { root.querySelector('input[name="abt-color"][value="' + (opts.length - 1) + '"]').checked = true; update(true); }
				});
				root.addEventListener('click', function (e) {
					var b = e.target.closest('.abt-ed-swatch, [data-plate="min"]');
					if (!b) return;
					if (b.hasAttribute('data-c')) {
						pl.c = b.getAttribute('data-c');
						root.querySelector('.abt-ed-plate-c').value = pl.c;
						Array.prototype.forEach.call(root.querySelectorAll('.abt-ed-swatch'), function (x) { x.setAttribute('aria-pressed', String(x === b)); });
					} else {
						var m = minAlpha();
						if (m === null) return;
						pl.touched = true;
						setAlpha(m);
					}
					update(true);
				});
				update(!!saved); // Nothing changes on the page until you pick an option.
				if (!photo) return;
				var texts = [el];
				if (frames.length) textsIn(frames[frames.length - 1].el, 20).forEach(function (t) { if (texts.indexOf(t) < 0) texts.push(t); });
				measureTexts(texts).then(function (m) {
					if (!root.isConnected) return;
					model = m;
					if (!pl.touched) {
						var a = minAlpha();
						if (a !== null) setAlpha(Math.ceil(Math.max(a, 25) / 5) * 5);
					}
					update(applied);
					if (m.videos.length) {
						liveTimer = window.setInterval(function () {
							if (!root.isConnected) { stopLive(); return; }
							if (m.addFrames()) render();
							if (m.frames() >= 10 * m.videos.length) stopLive();
						}, 700);
					}
				});
			},
			save: function () {
				stopLive();
				var o = chosen(), t = o.id === 'plate' ? target() : el, sc = readScope(root, t);
				if (o.id === 'keep') return post('abt_a11y_add', { type: 'keep', selector: sc.sel }).then(function (r) { return { r: r, reload: true }; });
				var rule;
				if (o.id === 'plate') rule = { sel: sc.sel, kind: 'plate', value: plateValue(), scope: sc.scope, label: (t === el ? 'Κείμενο «' : 'Πλαίσιο «') + cut(textOf(t), 40) + '»' };
				else if (root.querySelector('input[name="abt-palette"]').checked) return post('abt_a11y_add', { type: 'palette', from: orig, to: o.color }).then(function (r) { return { r: r, reload: true }; });
				else rule = { sel: sc.sel, kind: 'color', value: o.color, scope: sc.scope, label: 'Κείμενο «' + cut(textOf(el), 40) + '»' };
				return post('abt_a11y_rule', rule).then(function (r) { return { r: r, rule: rule }; });
			},
			cancel: function () { stopLive(); if (preview) preview(); preview = null; }
		};
	}

	function imageEditor(img) {
		var a = img.closest('a[href]');
		var linkText = a ? textOf(a) : '';
		var alt = img.getAttribute('alt');
		var auto = img.getAttribute(A);
		var src = img.currentSrc || img.getAttribute('src') || '';
		var m = /wp-image-(\d+)/.exec(img.className || '');
		var hintId = m ? m[1] : (img.getAttribute('data-id') || img.getAttribute('data-attachment-id') || '');
		var sugg = [humanize(src), img.getAttribute('title'), nearbyHeading(img)];
		var state = alt === null ? 'Χωρίς εναλλακτικό κείμενο (alt).' : alt === '' ? 'Ορισμένη ως διακοσμητική (alt κενό).' : 'Εναλλακτικό κείμενο: «' + cut(alt, 70) + '»' + (auto ? ' (από το plugin)' : '') + '.';
		var decorativeNow = alt === '' && !!linkText;
		var html = '<div class="abt-ed-thumb"><img src="' + esc(src) + '" alt=""></div><p>' + esc(state) + '</p>' +
			(a ? '<p class="abt-insp-small">Η εικόνα είναι σύνδεσμος προς ' + esc(pretty(a.href)) + '. ' + (linkText ? 'Ο σύνδεσμος έχει και κείμενο (' + q(linkText) + '), οπότε η εικόνα μπορεί να είναι διακοσμητική.' : 'Η περιγραφή πρέπει να λέει πού οδηγεί ο σύνδεσμος.') + '</p>' : '') +
			'<fieldset class="abt-ed-field"><legend>Τι είναι η εικόνα</legend>' +
			'<label class="abt-ed-opt"><input type="radio" name="abt-img" value="describe"' + (decorativeNow ? '' : ' checked') + '> Έχει περιεχόμενο</label>' +
			nameField('abt-ed-alt', 'Εναλλακτικό κείμενο (τι δείχνει ή πού οδηγεί)', alt || '', sugg) +
			'<label class="abt-ed-opt"><input type="radio" name="abt-img" value="decorative"' + (decorativeNow ? ' checked' : '') + '> Διακοσμητική (δεν διαβάζεται)</label></fieldset>' +
			'<div class="abt-ed-media"><p class="abt-insp-small">Αναζήτηση στη Βιβλιοθήκη Πολυμέσων…</p></div>' +
			'<div class="abt-ed-scope-wrap">' + scopeHtml(img) + '</div>';
		var media = null;
		function toggle(root) {
			var dec = (root.querySelector('input[name="abt-img"]:checked') || {}).value === 'decorative';
			var box = root.querySelector('input[name="abt-media"]');
			root.querySelector('.abt-ed-scope-wrap').hidden = !!(media && !dec && box && box.checked);
		}
		return {
			html: html,
			init: function (root) {
				var lookups = [post('abt_a11y_lookup', { src: src, id: hintId })];
				if (a && /^https?:/i.test(a.href)) lookups.push(post('abt_a11y_lookup', { url: a.href }));
				Promise.all(lookups).then(function (res) {
					var d = (res[0] && res[0].data) || {}, u = (res[1] && res[1].data) || {};
					media = d.media || null;
					var more = [u.saved, u.title];
					if (media) more.push(media.alt, media.title, media.caption);
					root.querySelector('.abt-ed-sugg-wrap').innerHTML = chipsFor(more.concat(sugg));
					var box = root.querySelector('.abt-ed-media');
					box.innerHTML = media
						? '<label class="abt-ed-opt"><input type="checkbox" name="abt-media" checked> Αποθήκευση στη Βιβλιοθήκη Πολυμέσων, ώστε να ισχύει όπου μπαίνει η εικόνα</label><p class="abt-insp-small">Στη Βιβλιοθήκη τώρα: ' + (media.alt ? q(media.alt) : 'κενό') + (media.edit ? ' · <a href="' + esc(media.edit) + '" target="_blank" rel="noopener">Άνοιγμα εικόνας</a>' : '') + '</p>'
						: '<p class="abt-insp-small">Η εικόνα δεν βρέθηκε στη Βιβλιοθήκη Πολυμέσων (π.χ. εικόνα του θέματος ή εξωτερική). Η αλλαγή θα γίνεται από το plugin.</p>';
					toggle(root);
				}, function () { root.querySelector('.abt-ed-media').innerHTML = ''; });
				root.addEventListener('change', function () { toggle(root); });
				root.querySelector('#abt-ed-alt').addEventListener('input', function () { root.querySelector('input[name="abt-img"][value="describe"]').checked = true; toggle(root); });
			},
			save: function (root) {
				var dec = (root.querySelector('input[name="abt-img"]:checked') || {}).value === 'decorative';
				var text = clean(root.querySelector('#abt-ed-alt').value);
				if (!dec && !text) return fail('Γράψτε ένα εναλλακτικό κείμενο ή επιλέξτε «Διακοσμητική».');
				var box = root.querySelector('input[name="abt-media"]');
				if (media && !dec && box && box.checked) {
					return post('abt_a11y_media_alt', { id: media.id, alt: text }).then(function (r) {
						if (r && r.success) {
							Array.prototype.forEach.call(document.querySelectorAll('img'), function (x) {
								if (x === img || (x.className || '').indexOf('wp-image-' + media.id) > -1 || (x.currentSrc || x.src) === src) { x.setAttribute('alt', text); x.removeAttribute(A); }
							});
						}
						return { r: r, note: 'Αποθηκεύτηκε στη Βιβλιοθήκη Πολυμέσων. Αν το site έχει cache, καθαρίστε την.' };
					});
				}
				var sc = readScope(root, img);
				var rule = { sel: sc.sel, kind: 'alt', value: dec ? '' : text, scope: sc.scope, label: 'Εικόνα ' + humanize(src) };
				return post('abt_a11y_rule', rule).then(function (r) { return { r: r, rule: rule }; });
			}
		};
	}

	function linkEditor(a) {
		var text = textOf(a);
		var img = a.querySelector('img');
		var now = a.getAttribute('aria-label') || text || (img && img.getAttribute('alt')) || '';
		var http = /^https?:/i.test(a.href);
		var hidden = a.getAttribute('aria-hidden') === 'true';
		var sugg = [now, img && img.getAttribute('alt'), nearbyHeading(a)];
		var html = '<p class="abt-insp-small">Οδηγεί σε: <a href="' + esc(a.href) + '" target="_blank" rel="noopener">' + esc(pretty(a.getAttribute('href') || '')) + '</a></p>' +
			(text && !a.getAttribute('aria-label') ? '<p>Διαβάζεται από το κείμενό του: ' + q(text) + '. Συνήθως δεν χρειάζεται αλλαγή.</p>' : '<p>Οι αναγνώστες οθόνης λένε: ' + (now ? q(now) : '<em>τίποτα</em>') + '</p>') +
			'<fieldset class="abt-ed-field"><legend>Τι να διαβάζεται</legend>' +
			'<label class="abt-ed-opt"><input type="radio" name="abt-link" value="name"' + (hidden ? '' : ' checked') + '> Όνομα συνδέσμου</label>' +
			nameField('abt-ed-name', 'Πού οδηγεί (π.χ. «Επικοινωνία», «Καναπέδες»)', a.getAttribute('aria-label') || (text ? '' : now), sugg) +
			'<label class="abt-ed-opt"><input type="radio" name="abt-link" value="hide"' + (hidden ? ' checked' : '') + '> Να μη διαβάζεται: υπάρχει ίδιος σύνδεσμος με κείμενο δίπλα</label></fieldset>' +
			'<div class="abt-ed-scope-wrap">' + scopeHtml(a, http ? [{ value: 'url', label: 'Σε όλους τους συνδέσμους προς αυτή τη διεύθυνση, σε όλο το site' }] : []) + '</div>';
		return {
			html: html,
			init: function (root) {
				if (http) post('abt_a11y_lookup', { url: a.href }).then(function (res) {
					var d = (res && res.data) || {};
					root.querySelector('.abt-ed-sugg-wrap').innerHTML = chipsFor([d.saved, d.title].concat(sugg));
				});
				root.querySelector('#abt-ed-name').addEventListener('input', function () { root.querySelector('input[name="abt-link"][value="name"]').checked = true; });
			},
			save: function (root) {
				var mode = (root.querySelector('input[name="abt-link"]:checked') || {}).value;
				var sc = readScope(root, a);
				if (mode === 'hide') {
					var hr = { sel: sc.where === 'url' ? uniqueSelector(a) : sc.sel, kind: 'hide', value: '', scope: sc.scope, label: 'Σύνδεσμος ' + pretty(a.getAttribute('href') || '') };
					return post('abt_a11y_rule', hr).then(function (r) { return { r: r, rule: hr }; });
				}
				var name = clean(root.querySelector('#abt-ed-name').value);
				if (!name) return fail('Γράψτε ένα όνομα.');
				if (sc.where === 'url') return post('abt_a11y_add', { type: 'label', url: a.href, label: name, lang: '' }).then(function (r) { return { r: r, reload: true }; });
				var rule = { sel: sc.sel, kind: 'name', value: name, scope: sc.scope, label: 'Σύνδεσμος ' + pretty(a.getAttribute('href') || '') };
				return post('abt_a11y_rule', rule).then(function (r) { return { r: r, rule: rule }; });
			}
		};
	}

	function nameEditor(el, label, sugg, kindLabel) {
		var now = nameOf(el);
		var html = '<p>Οι αναγνώστες οθόνης λένε: ' + (now ? q(now) : '<em>τίποτα</em>') + '</p>' +
			nameField('abt-ed-name', label, el.getAttribute('aria-label') || '', [now].concat(sugg)) +
			'<div class="abt-ed-scope-wrap">' + scopeHtml(el) + '</div>';
		return {
			html: html,
			init: function () {},
			save: function (root) {
				var name = clean(root.querySelector('#abt-ed-name').value);
				if (!name) return fail('Γράψτε ένα όνομα.');
				var sc = readScope(root, el);
				var rule = { sel: sc.sel, kind: 'name', value: name, scope: sc.scope, label: kindLabel + ' «' + cut(name, 40) + '»' };
				return post('abt_a11y_rule', rule).then(function (r) { return { r: r, rule: rule }; });
			}
		};
	}

	function iconEditor(svg) {
		var hidden = svg.getAttribute('aria-hidden') === 'true';
		var html = '<p>' + (hidden ? 'Είναι κρυφό από τους αναγνώστες οθόνης (διακοσμητικό).' : 'Οι αναγνώστες οθόνης λένε: ' + (nameOf(svg) ? q(nameOf(svg)) : '<em>τίποτα</em>')) + '</p>' +
			'<fieldset class="abt-ed-field"><legend>Τι είναι το εικονίδιο</legend>' +
			'<label class="abt-ed-opt"><input type="radio" name="abt-icon" value="hide"' + (hidden ? ' checked' : '') + '> Διακοσμητικό (δεν διαβάζεται)</label>' +
			'<label class="abt-ed-opt"><input type="radio" name="abt-icon" value="name"' + (hidden ? '' : ' checked') + '> Έχει νόημα</label>' +
			nameField('abt-ed-name', 'Τι σημαίνει (π.χ. «Τηλέφωνο», «Δωρεάν αποστολή»)', svg.getAttribute('aria-label') || '', [nearbyHeading(svg)]) +
			'</fieldset><div class="abt-ed-scope-wrap">' + scopeHtml(svg) + '</div>';
		return {
			html: html,
			init: function (root) { root.querySelector('#abt-ed-name').addEventListener('input', function () { root.querySelector('input[name="abt-icon"][value="name"]').checked = true; }); },
			save: function (root) {
				var mode = (root.querySelector('input[name="abt-icon"]:checked') || {}).value;
				var sc = readScope(root, svg);
				var name = clean(root.querySelector('#abt-ed-name').value);
				if (mode === 'name' && !name) return fail('Γράψτε τι σημαίνει το εικονίδιο.');
				var rule = { sel: sc.sel, kind: mode === 'name' ? 'name' : 'hide', value: mode === 'name' ? name : '', scope: sc.scope, label: 'Εικονίδιο' + (name ? ' «' + cut(name, 40) + '»' : '') };
				return post('abt_a11y_rule', rule).then(function (r) { return { r: r, rule: rule }; });
			}
		};
	}

	function infoEditor(html) { return { html: html, init: function () {}, save: null }; }

	function editorFor(el) {
		switch (typeOf(el)) {
			case 'image': return imageEditor(el);
			case 'link': return linkEditor(el);
			case 'button': return nameEditor(el, 'Τι κάνει το κουμπί', buttonWords(), 'Κουμπί');
			case 'field': return nameEditor(el, 'Ετικέτα πεδίου (τι συμπληρώνεται)', [el.getAttribute('placeholder'), humanize(el.getAttribute('name') || ''), el.previousElementSibling ? textOf(el.previousElementSibling) : ''], 'Πεδίο');
			case 'icon': return iconEditor(el);
			case 'pause': return infoEditor('<p>Το slider αλλάζει μόνο του, οπότε χρειάζεται κουμπί για να σταματά (WCAG 2.2.2).</p><p>Θέση, μέγεθος και χρώματα: ' + link('#abt-controls', 'Ρυθμίσεις → Slider & focus') + '.</p>');
			case 'photo': return infoEditor('<p>Το χρώμα κάτω από τη φωτογραφία αλλάζει στο ' + link('#abt-contrast', 'Ρυθμίσεις → Αντίθεση → Φόντο κάτω από φωτογραφία') + '.</p><p class="abt-insp-small">Για το χρώμα ενός κειμένου μέσα στη φωτογραφία, κλικ πάνω στο κείμενο.</p>');
			case 'page': return infoEditor('<p>Αφορά όλη τη σελίδα (γλώσσα ή τίτλος). Ο τίτλος μπαίνει από το SEO plugin ή τις ρυθμίσεις της σελίδας στο WordPress.</p>');
			default: return textEditor(el);
		}
	}

	function edit(el) {
		if (!el || !on) return;
		stopLive();
		if (ui.min) { ui.min = false; applyUI(); saveUI(); }
		if (preview) { preview(); preview = null; }
		if (el.tagName === 'LABEL') {
			var f = el.getAttribute('for') ? document.getElementById(el.getAttribute('for')) : el.querySelector('input, select, textarea');
			if (f) el = f;
		}
		var it = itemFor(el);
		current = { el: el, type: typeOf(el), item: it };
		var ed;
		try { ed = editorFor(el); } catch (e) { ed = infoEditor('<p>Δεν ήταν δυνατή η επεξεργασία αυτού του στοιχείου.</p>'); }
		current.ed = ed;
		var rules = rulesFor(el);
		var autoFixed = it && it.fixes.some(function (f) { return f !== 'rule' && f !== 'pause' && f !== 'partial'; });
		panel.querySelector('.abt-insp-title').textContent = (it ? it.n + '. ' : '') + TYPE[current.type] + (current.type === 'heading' ? ' ' + el.tagName : '');
		panel.querySelector('.abt-insp-back').hidden = false;
		body.innerHTML = statusBox(it, el) + '<div class="abt-ed">' + ed.html + '</div>' +
			'<div class="abt-insp-actions">' + (ed.save ? '<button type="button" class="abt-insp-btn" data-act="save">Αποθήκευση</button><button type="button" class="abt-insp-btn is-secondary" data-act="cancel">Ακύρωση</button>' : '<button type="button" class="abt-insp-btn is-secondary" data-act="cancel">Πίσω</button>') +
			'<button type="button" class="abt-insp-btn is-secondary" data-act="show">Δείξε στη σελίδα</button></div>' +
			'<div class="abt-insp-msg" role="status"></div>' +
			(rules.length ? '<p class="abt-ed-more"><button type="button" class="abt-insp-link" data-act="unrule">Αφαίρεση της δικής σας αλλαγής εδώ</button></p>' : '') +
			(autoFixed ? '<p class="abt-ed-more"><button type="button" class="abt-insp-link" data-act="exclude">Να μη διορθώνει το plugin αυτό το σημείο</button></p>' : '');
		try { ed.init(body.querySelector('.abt-ed')); } catch (e) { /* the form still works */ }
		outline();
		queue();
		var first = body.querySelector('.abt-ed input:not([type="hidden"]), .abt-insp-actions button');
		if (first) { try { first.focus({ preventScroll: true }); } catch (e) { first.focus(); } }
		avoid(el);
	}

	function message(text, bad) {
		var box = body.querySelector('.abt-insp-msg');
		if (box) { box.textContent = text; box.className = 'abt-insp-msg' + (bad ? ' is-bad' : ''); }
	}
	function busy(on2) {
		Array.prototype.forEach.call(body.querySelectorAll('.abt-insp-actions button, .abt-ed-more button'), function (b) { b.disabled = on2; });
	}

	function afterSave(res) {
		var r = res && res.r;
		if (!r || !r.success) { message((r && r.data && r.data.message) || 'Δεν αποθηκεύτηκε.', true); busy(false); return; }
		if (preview) preview(); // The saved change now comes from the plugin, not the preview.
		preview = null;
		if (res.reload) { message('Αποθηκεύτηκε. Ανανέωση σελίδας…'); reloadKeepingEditor(); return; }
		if (res.rule) {
			var c = CFG();
			c.rules = (c.rules || []).filter(function (x) { return !(x.sel === res.rule.sel && x.kind === res.rule.kind); });
			c.rules.push({ sel: res.rule.sel, kind: res.rule.kind, value: res.rule.value, site: res.rule.scope === 'site', lang: res.rule.lang || '', scope: res.rule.scope });
			RT().setRules(c.rules);
		}
		var el = current && current.el;
		RT().run();
		window.setTimeout(function () {
			items = collect();
			buildMarks();
			updateBarCount();
			if (el && el.isConnected) { edit(el); message(res.note || 'Αποθηκεύτηκε. Ισχύει ήδη στη σελίδα.'); } else renderList();
		}, 150);
	}

	function onPanelClick(e) {
		var t = e.target.closest('button');
		if (!t || !panel.contains(t)) return;
		if (t.classList.contains('abt-insp-close')) { stop(); return; }
		if (t.classList.contains('abt-insp-side')) {
			if (ui.mode === 'float') ui.mode = ui.x + ui.w / 2 < vw() / 2 ? 'left' : 'right';
			else ui.mode = ui.mode === 'left' ? 'right' : 'left';
			applyUI(); saveUI(); queue();
			return;
		}
		if (t.classList.contains('abt-insp-min')) { ui.min = !ui.min; applyUI(); saveUI(); queue(); return; }
		if (t.classList.contains('abt-insp-move')) return;
		if (t.classList.contains('abt-insp-reload')) { refresh(); return; }
		if (t.classList.contains('abt-insp-back')) { if (preview) preview(); preview = null; renderList(); return; }
		if (t.hasAttribute('data-filter')) { filter = t.getAttribute('data-filter'); renderList(); return; }
		if (t.classList.contains('abt-insp-row')) { var it = items[+t.getAttribute('data-i')]; edit(it.el); flash(it.el, true); avoidLater(it.el); return; }
		if (t.classList.contains('abt-ed-chip')) {
			var input = body.querySelector('#abt-ed-alt, #abt-ed-name');
			if (input) { input.value = t.getAttribute('data-fill'); input.dispatchEvent(new Event('input', { bubbles: true })); input.focus(); }
			return;
		}
		var act = t.getAttribute('data-act');
		if (!act || !current) return;
		var el = current.el;
		if (act === 'show') { flash(el, true); avoidLater(el); return; }
		if (act === 'cancel') { if (current.ed.cancel) current.ed.cancel(); preview = null; renderList(); return; }
		if (act === 'save') {
			busy(true);
			message('Αποθήκευση…');
			var p;
			try { p = current.ed.save(body.querySelector('.abt-ed')); } catch (err) { p = fail('Σφάλμα: ' + err.message); }
			Promise.resolve(p).then(afterSave, function () { afterSave(null); });
			return;
		}
		if (act === 'unrule') {
			busy(true);
			Promise.all(rulesFor(el).map(function (r) { return post('abt_a11y_rule', { op: 'delete', sel: r.sel, kind: r.kind, lang: r.lang || '', scope: r.site ? 'site' : (r.scope || CFG().path || '/') }); })).then(function () {
				message('Η αλλαγή αφαιρέθηκε. Ανανέωση σελίδας…');
				reloadKeepingEditor();
			});
			return;
		}
		if (act === 'exclude') {
			if (!t.hasAttribute('data-sure')) { t.setAttribute('data-sure', '1'); t.textContent = 'Σίγουρα; Εδώ θα εμφανιστεί σφάλμα στο WAVE. Πατήστε ξανά'; return; }
			busy(true);
			post('abt_a11y_add', { type: 'exclude', selector: uniqueSelector(el) }).then(function (r) { afterSave({ r: r, reload: true }); });
		}
	}

	function flash(el, scroll) {
		if (!el || el === document.documentElement) return;
		if (scroll) { try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch (e) { el.scrollIntoView(); } }
		el.classList.add('abt-insp-flash');
		window.setTimeout(function () { el.classList.remove('abt-insp-flash'); }, 1600);
		queue();
	}

	function onPageClick(e) {
		if (!on || inUI(e.target)) return;
		e.preventDefault();
		e.stopPropagation();
		var t = targetFor(e.target);
		if (t) edit(t);
	}
	function onKey(e) {
		if (e.key !== 'Escape' || !on) return;
		if (current) { if (preview) preview(); preview = null; renderList(); } else stop();
	}

	/* ---------------- Panel: docked right/left or floating; drag, resize, collapse ---------------- */

	var UI_KEY = 'abt-a11y-panel';
	function loadUI() {
		try {
			var s = JSON.parse(window.localStorage.getItem(UI_KEY) || 'null');
			if (s && typeof s === 'object') Object.keys(ui).forEach(function (k) { if (k in s) ui[k] = s[k]; });
		} catch (e) { /* defaults */ }
		if (['right', 'left', 'float'].indexOf(ui.mode) < 0) ui.mode = 'right';
		ui.min = !!ui.min;
	}
	function saveUI() { try { window.localStorage.setItem(UI_KEY, JSON.stringify(ui)); } catch (e) { /* only for this visit */ } }
	function vw() { return document.documentElement.clientWidth || window.innerWidth; }
	function narrow() { return window.matchMedia ? window.matchMedia('(max-width: 782px)').matches : window.innerWidth <= 782; }
	function topGap() {
		var ab = document.getElementById('wpadminbar');
		return ab && ab.offsetHeight && window.getComputedStyle(ab).position === 'fixed' ? ab.offsetHeight : 0;
	}
	function clampUI() {
		var w = vw(), h = window.innerHeight, top = topGap();
		ui.w = Math.round(Math.max(300, Math.min(+ui.w || 400, 720, Math.max(300, w - 40))));
		if (ui.mode !== 'float') return;
		ui.h = Math.round(Math.max(220, Math.min(+ui.h || h * 0.7, h - top - 8)));
		ui.x = Math.round(Math.max(0, Math.min(+ui.x || 0, w - ui.w)));
		ui.y = Math.round(Math.max(top, Math.min(+ui.y || top, h - (ui.min ? 44 : ui.h) - 4)));
	}
	function applyUI() {
		if (!panel) return;
		clampUI();
		var fl = ui.mode === 'float' && !narrow();
		panel.classList.toggle('is-left', ui.mode === 'left');
		panel.classList.toggle('is-float', fl);
		panel.classList.toggle('is-min', ui.min);
		[['--abt-top', topGap()], ['--abt-w', ui.w], ['--abt-x', ui.x], ['--abt-y', ui.y], ['--abt-h', ui.h]].forEach(function (v) { panel.style.setProperty(v[0], v[1] + 'px'); });
		var side = panel.querySelector('.abt-insp-side'), mn = panel.querySelector('.abt-insp-min');
		var near = ui.x + ui.w / 2 < vw() / 2 ? 'αριστερά' : 'δεξιά';
		side.setAttribute('aria-label', fl ? 'Κόλλημα του πάνελ ' + near : 'Μετακίνηση του πάνελ στην άλλη πλευρά');
		side.title = fl ? 'Κόλλημα ' + near : 'Άλλη πλευρά';
		mn.setAttribute('aria-expanded', String(!ui.min));
		mn.setAttribute('aria-label', ui.min ? 'Άνοιγμα του πάνελ' : 'Μάζεμα του πάνελ');
		mn.title = ui.min ? 'Άνοιγμα' : 'Μάζεμα';
		mn.textContent = ui.min ? '□' : '–';
	}
	function undock() {
		if (ui.mode === 'float') return;
		var r = panel.getBoundingClientRect();
		ui.mode = 'float';
		ui.x = r.left;
		ui.y = r.top;
		if (!ui.h) ui.h = Math.round(window.innerHeight * 0.7);
	}
	function showDock(side) {
		if (!dockHint) return;
		dockHint.hidden = !side;
		dockHint.className = 'abt-insp-dock' + (side ? ' is-' + side : '');
		dockHint.style.setProperty('--abt-top', topGap() + 'px');
		dockHint.style.setProperty('--abt-w', ui.w + 'px');
	}
	function onDown(e) {
		if (narrow() || (e.button !== undefined && e.button !== 0)) return;
		var t = e.target, grip = t.closest('.abt-insp-grip'), head = t.closest('.abt-insp-head');
		if (!grip && !head) return;
		if (!grip && t.closest('button') && !t.closest('.abt-insp-move')) return;
		drag = { size: !!grip, sx: e.clientX, sy: e.clientY, r: panel.getBoundingClientRect(), moved: false, snap: '' };
		try { (grip || head).setPointerCapture(e.pointerId); } catch (err) { /* window listeners still work */ }
		e.preventDefault();
	}
	function onDrag(e) {
		if (!drag) return;
		var dx = e.clientX - drag.sx, dy = e.clientY - drag.sy;
		if (!drag.moved && Math.abs(dx) + Math.abs(dy) < 5) return;
		drag.moved = true;
		document.documentElement.classList.add('abt-insp-dragging');
		if (drag.size) {
			if (ui.mode === 'float') { ui.w = drag.r.width + dx; ui.h = drag.r.height + dy; }
			else ui.w = ui.mode === 'right' ? drag.r.width - dx : drag.r.width + dx;
		} else {
			undock();
			ui.x = drag.r.left + dx;
			ui.y = drag.r.top + dy;
			drag.snap = e.clientX < 30 ? 'left' : e.clientX > vw() - 30 ? 'right' : '';
			showDock(drag.snap);
		}
		applyUI();
		queue();
	}
	function onUp() {
		if (!drag) return;
		var d = drag;
		drag = null;
		document.documentElement.classList.remove('abt-insp-dragging');
		showDock('');
		if (!d.moved) return;
		if (d.snap) ui.mode = d.snap;
		applyUI();
		saveUI();
		queue();
	}
	function onPanelKey(e) {
		if (!e.target.closest || !e.target.closest('.abt-insp-move') || narrow()) return;
		var n = e.shiftKey ? 100 : 20;
		var d = { ArrowLeft: [-n, 0], ArrowRight: [n, 0], ArrowUp: [0, -n], ArrowDown: [0, n] }[e.key];
		if (!d) return;
		e.preventDefault();
		undock();
		ui.x += d[0];
		ui.y += d[1];
		applyUI();
		saveUI();
		queue();
	}
	// The panel should not hide the element being edited: move it to the other side if that shows more of it.
	function coverage(r, p) {
		var ix = Math.max(0, Math.min(r.right, p.right) - Math.max(r.left, p.left));
		var iy = Math.max(0, Math.min(r.bottom, p.bottom) - Math.max(r.top, p.top));
		return ix * iy / Math.max(1, r.width * r.height);
	}
	function avoid(el) {
		if (!on || !el || el === document.documentElement || el === document.body || narrow() || ui.min) return;
		var r = el.getBoundingClientRect();
		if (!r.width || !r.height) return;
		var fl = ui.mode === 'float', w = vw(), p = panel.getBoundingClientRect();
		var box = function (left) { return { left: left, right: left + p.width, top: fl ? p.top : -1e6, bottom: fl ? p.bottom : 1e6 }; };
		var now = box(p.left);
		if (coverage(r, now) < 0.5) return;
		var left = fl ? (r.left + r.width / 2 < w / 2 ? w - p.width - 8 : 8) : (ui.mode === 'left' ? w - p.width : 0);
		if (coverage(r, box(left)) >= coverage(r, now)) return;
		if (fl) ui.x = left; else ui.mode = ui.mode === 'left' ? 'right' : 'left';
		applyUI();
		saveUI();
		queue();
	}
	function avoidLater(el) { window.setTimeout(function () { avoid(el); }, 500); }

	/* ---------------- Start / stop ---------------- */

	function build() {
		panel = document.createElement('div');
		panel.className = 'abt-insp-panel';
		panel.setAttribute('data-abt-ui', '');
		panel.setAttribute('role', 'dialog');
		panel.setAttribute('aria-label', 'Προσβασιμότητα σελίδας');
		panel.innerHTML = '<div class="abt-insp-head" title="Σύρετε από εδώ για να μετακινήσετε το πάνελ"><button type="button" class="abt-insp-move" aria-label="Μετακίνηση του πάνελ: σύρετε ή πατήστε τα βελάκια" title="Σύρετε για να μετακινήσετε το πάνελ"></button><button type="button" class="abt-insp-back" hidden>← Όλα</button><strong class="abt-insp-title"></strong>' +
			'<span><button type="button" class="abt-insp-reload" aria-label="Ξανά έλεγχος της σελίδας" title="Ξανά έλεγχος">↻</button><button type="button" class="abt-insp-side" aria-label="Μετακίνηση του πάνελ στην άλλη πλευρά" title="Άλλη πλευρά">⇆</button><button type="button" class="abt-insp-min" aria-expanded="true" aria-label="Μάζεμα του πάνελ" title="Μάζεμα">–</button><button type="button" class="abt-insp-close" aria-label="Κλείσιμο">×</button></span></div><div class="abt-insp-body"></div><div class="abt-insp-grip" aria-hidden="true" title="Σύρετε για να αλλάξετε το μέγεθος"></div>';
		body = panel.querySelector('.abt-insp-body');
		panel.addEventListener('click', onPanelClick);
		panel.addEventListener('pointerdown', onDown);
		panel.addEventListener('keydown', onPanelKey);
		window.addEventListener('pointermove', onDrag, true);
		window.addEventListener('pointerup', onUp, true);
		window.addEventListener('pointercancel', onUp, true);
		document.body.appendChild(panel);
		dockHint = document.createElement('div');
		dockHint.className = 'abt-insp-dock';
		dockHint.setAttribute('data-abt-ui', '');
		dockHint.setAttribute('aria-hidden', 'true');
		dockHint.hidden = true;
		document.body.appendChild(dockHint);
		loadUI();
	}

	function refresh() {
		if (RT()) RT().run();
		items = collect();
		buildMarks();
		if (current && current.el.isConnected) edit(current.el); else renderList();
		updateBarCount();
	}

	function start() {
		if (on || !RT()) return;
		on = true;
		if (!panel) build();
		panel.hidden = false;
		applyUI();
		document.documentElement.classList.add('abt-insp');
		body.innerHTML = '<p class="abt-insp-lead">Έλεγχος της σελίδας…</p>';
		document.addEventListener('click', onPageClick, true);
		document.addEventListener('keydown', onKey);
		document.addEventListener('mousemove', onMove, true);
		window.addEventListener('scroll', queue, true);
		window.addEventListener('resize', queue);
		window.addEventListener('resize', applyUI);
		timer = window.setInterval(queue, 800);
		loadChecker().then(function () {
			try { RT().run(); } catch (e) { /* show what is there */ }
			items = collect();
			buildMarks();
			renderList();
			updateBarCount();
			panel.querySelector('.abt-insp-close').focus();
		});
	}

	function stop() {
		on = false;
		stopLive();
		if (preview) preview();
		preview = null;
		current = null;
		lastHover = null;
		if (panel) panel.hidden = true;
		if (marks) { marks.remove(); marks = null; }
		hoverBox = tag = null;
		outline();
		document.documentElement.classList.remove('abt-insp');
		document.removeEventListener('click', onPageClick, true);
		document.removeEventListener('keydown', onKey);
		document.removeEventListener('mousemove', onMove, true);
		window.removeEventListener('scroll', queue, true);
		window.removeEventListener('resize', queue);
		window.removeEventListener('resize', applyUI);
		window.clearInterval(timer);
		if (window.location.hash === '#abt-a11y-inspect') history.replaceState(null, '', window.location.pathname + window.location.search);
	}

	/* ---------------- Admin bar ---------------- */

	function updateBarCount() {
		var list = on ? items : collect();
		var errors = list.filter(function (it) { return it.status === 'error'; }).length;
		var item = document.querySelector('#wp-admin-bar-abt-a11y > .ab-item');
		if (!item) return;
		var badge = item.querySelector('.abt-ab-count');
		if (!badge) { badge = document.createElement('span'); badge.className = 'abt-ab-count'; item.appendChild(badge); }
		badge.textContent = errors || list.length;
		badge.className = 'abt-ab-count' + (errors ? ' is-error' : '');
		badge.setAttribute('aria-label', errors ? errors + (errors === 1 ? ' σφάλμα' : ' σφάλματα') + ' σε αυτή τη σελίδα' : list.length + (list.length === 1 ? ' αλλαγή' : ' αλλαγές') + ' σε αυτή τη σελίδα');
		badge.title = badge.getAttribute('aria-label');
	}

	document.addEventListener('click', function (e) {
		var a = e.target.closest && e.target.closest('#wp-admin-bar-abt-a11y > .ab-item, #wp-admin-bar-abt-a11y-inspect a');
		if (!a) return;
		e.preventDefault();
		e.stopPropagation();
		if (on) stop(); else start();
	}, true);

	function boot() {
		window.setTimeout(function () {
			loadChecker().then(updateBarCount);
			if (window.location.hash === '#abt-a11y-inspect') start();
		}, 1800);
	}
	if (document.readyState === 'complete') boot(); else window.addEventListener('load', boot);

	window.abtA11yInspect = { start: start, stop: stop, refresh: refresh, edit: edit, items: function () { return items; }, uniqueSelector: uniqueSelector, similarSelector: similarSelector, selectorFor: similarSelector };
})(window, document);
