/*!
 * Aboutnet Accessibility – page checker used by the admin scanner.
 * Counts the WAVE (WebAIM) "Errors" and "Contrast Errors" classes in a rendered document,
 * following WebAIM's documented algorithms. Runs in wp-admin only.
 */
// WAVE-equivalent checker (errors + contrast), written from WebAIM's documented
// algorithms plus behaviour observed against the WAVE 3.3.3 engine.
window.abtCheck = function (doc, opts) {
  opts = opts || {};
  var win = doc.defaultView;
  var out = { error: {}, contrast: [] };
  function add(id, el, note) {
    (out.error[id] = out.error[id] || []).push({ el: el, note: note || '' });
  }
  function txt(el) { return (el.textContent || '').replace(/[\s ]+/g, ''); }
  function attrPresent(el, n) { return el.hasAttribute(n); }
  function attrNonEmpty(el, n) { var v = el.getAttribute(n); return v !== null && v.trim() !== ''; }
  function imgHasAlt(img) { return attrNonEmpty(img, 'alt'); }
  function svgNamed(svg) {
    if (attrNonEmpty(svg, 'aria-label') || attrPresent(svg, 'aria-labelledby')) return true;
    for (var i = 0; i < svg.children.length; i++) {
      if (svg.children[i].tagName.toLowerCase() === 'title' && txt(svg.children[i])) return true;
    }
    return false;
  }
  function svgExempt(svg) {
    if (svg.getAttribute('aria-hidden') === 'true') return true;
    if ((svg.getAttribute('role') || '').toLowerCase() === 'presentation') return true;
    if (attrPresent(svg, 'aria-label') || attrPresent(svg, 'aria-labelledby')) return true;
    for (var i = 0; i < svg.children.length; i++) if (svg.children[i].tagName.toLowerCase() === 'title') return true;
    return false;
  }
  // "Contains text" the way WAVE counts it for links/buttons/headings.
  function hasContent(el) {
    if (txt(el)) return true;
    var imgs = el.querySelectorAll('img, input[type=image], area');
    for (var i = 0; i < imgs.length; i++) if (imgHasAlt(imgs[i])) return true;
    var svgs = el.querySelectorAll('svg');
    for (var j = 0; j < svgs.length; j++) if (svgNamed(svgs[j])) return true;
    return false;
  }
  function namedByAttr(el) {
    return attrPresent(el, 'aria-label') || attrPresent(el, 'aria-labelledby') || attrNonEmpty(el, 'title');
  }

  // --- images / svg ---
  doc.querySelectorAll('img').forEach(function (img) {
    if (img.closest('.abt-check-ignore')) return;
    if (!img.hasAttribute('alt')) {
      if (img.getAttribute('aria-hidden') === 'true') return;
      var r = (img.getAttribute('role') || '').toLowerCase();
      if (r === 'presentation' || r === 'none') return;
      if (attrPresent(img, 'aria-label') || attrPresent(img, 'aria-labelledby')) return;
      add('alt_missing', img);
    }
    if (img.hasAttribute('longdesc') && !/^(https?:|\/|\.|#)/.test(img.getAttribute('longdesc'))) add('longdesc_invalid', img);
    if (img.hasAttribute('usemap') && !img.hasAttribute('alt')) add('alt_map_missing', img);
  });
  doc.querySelectorAll('svg').forEach(function (svg) {
    if (!svgExempt(svg)) add('alt_missing', svg);
  });
  doc.querySelectorAll('input[type=image]').forEach(function (i) { if (!imgHasAlt(i)) add('alt_input_missing', i); });
  doc.querySelectorAll('area[href]').forEach(function (a) { if (!a.hasAttribute('alt')) add('alt_area_missing', a); });

  // --- links ---
  doc.querySelectorAll('a[href]').forEach(function (a) {
    if (hasContent(a) || namedByAttr(a)) return;
    if (a.getAttribute('tabindex') === '-1') return;
    if (a.querySelector('img')) add('alt_link_missing', a); else add('link_empty', a);
  });
  // --- buttons ---
  doc.querySelectorAll('button').forEach(function (b) {
    if (hasContent(b) || namedByAttr(b)) return;
    if (b.getAttribute('tabindex') === '-1') return;
    add('button_empty', b);
  });
  doc.querySelectorAll('input[type=submit], input[type=button], input[type=reset]').forEach(function (i) {
    if (!attrNonEmpty(i, 'value') && !namedByAttr(i)) add('button_empty', i);
  });
  // --- headings / th ---
  doc.querySelectorAll('h1,h2,h3,h4,h5,h6').forEach(function (h) {
    if (!hasContent(h) && !attrPresent(h, 'aria-label') && !attrPresent(h, 'aria-labelledby')) add('heading_empty', h);
  });
  doc.querySelectorAll('th').forEach(function (th) {
    if (!hasContent(th) && !attrPresent(th, 'aria-label') && !attrPresent(th, 'aria-labelledby')) add('th_empty', th);
  });
  // --- form labels ---
  var controls = doc.querySelectorAll('input:not([type=image]):not([type=submit]):not([type=reset]):not([type=button]):not([type=hidden]), textarea, select');
  controls.forEach(function (c) {
    var labels = [];
    if (c.id) {
      doc.querySelectorAll('label[for]').forEach(function (l) { if (l.getAttribute('for') === c.id) labels.push(l); });
    }
    var wrap = c.parentElement ? c.parentElement.closest('label') : null;
    if (wrap && labels.indexOf(wrap) < 0 && (!wrap.hasAttribute('for') || wrap.getAttribute('for') === c.id)) labels.push(wrap);
    if (labels.length > 1) add('label_multiple', c);
    var visibleLabel = labels.some(function (l) {
      var cs = win.getComputedStyle(l);
      return cs.display !== 'none' && cs.visibility !== 'hidden';
    });
    var isSelect = c.tagName === 'SELECT';
    if (labels.length) {
      labels.forEach(function (l) {
        if (!hasContent(l)) add('label_empty', l);
      });
    }
    if (!visibleLabel && !attrNonEmpty(c, 'title') && !attrPresent(c, 'aria-labelledby') && !attrPresent(c, 'aria-label')) {
      if (!isSelect) add('label_missing', c);
    }
  });
  // --- ARIA ---
  doc.querySelectorAll('[aria-labelledby], [aria-describedby]').forEach(function (el) {
    ['aria-labelledby', 'aria-describedby'].forEach(function (n) {
      if (!el.hasAttribute(n)) return;
      var ids = el.getAttribute(n).trim().split(/\s+/).filter(Boolean);
      var broken = ids.length === 0 || ids.some(function (id) { return !doc.getElementById(id); });
      if (broken) add('aria_reference_broken', el, n + '=' + el.getAttribute(n));
    });
  });
  doc.querySelectorAll('[role=menu]').forEach(function (m) {
    if (!m.querySelector('[role=menuitem],[role=menuitemcheckbox],[role=menuitemradio]')) add('aria_menu_broken', m);
  });
  // --- page level ---
  var lang = doc.documentElement.getAttribute('lang');
  var langRe = /^[a-zA-Z]{2,3}(-[a-zA-Z0-9]{1,8})*$/;
  if (!lang || !langRe.test(lang.trim())) add('language_missing', doc.documentElement, 'html lang=' + lang);
  doc.querySelectorAll('body [lang]').forEach(function (el) {
    var v = el.getAttribute('lang');
    if (v !== '' && !langRe.test(v.trim())) add('language_missing', el, 'lang=' + v);
  });
  var t = (doc.title || '').trim();
  if (!t || /^untitled/i.test(t)) add('title_invalid', doc.documentElement);
  doc.querySelectorAll('meta[http-equiv]').forEach(function (m) { if (/refresh/i.test(m.getAttribute('http-equiv'))) add('meta_refresh', m); });
  doc.querySelectorAll('marquee').forEach(function (m) { add('marquee', m); });
  doc.querySelectorAll('blink').forEach(function (m) { add('blink', m); });
  doc.querySelectorAll('a[href^="#"]').forEach(function (a) {
    if (!/skip|jump/i.test(a.textContent || '')) return;
    var id = decodeURIComponent(a.getAttribute('href').slice(1));
    var target = id && (doc.getElementById(id) || doc.querySelector('a[name="' + id.replace(/"/g, '') + '"]'));
    var cs = win.getComputedStyle(a);
    if (!target || cs.display === 'none' || cs.visibility === 'hidden') add('link_skip_broken', a);
  });

  // --- contrast ---
  function parse(c) {
    var m = /rgba?\(([^)]+)\)/.exec(c || '');
    if (m) {
      var p = m[1].split(/[\s,\/]+/).filter(Boolean).map(parseFloat);
      return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
    }
    var sm = /color\(srgb\s+([^)]+)\)/.exec(c || '');
    if (!sm) return null;
    var v = sm[1].split(/[\s\/]+/).filter(Boolean).map(parseFloat);
    return { r: v[0] * 255, g: v[1] * 255, b: v[2] * 255, a: v.length > 3 ? v[3] : 1 };
  }
  function lum(c) {
    var f = function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
  }
  function ratio(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  function hidden(el) {
    for (var e = el; e && e.nodeType === 1; e = e.parentElement) {
      var cs = win.getComputedStyle(e);
      if (cs.display === 'none' || cs.visibility === 'hidden' || cs.visibility === 'collapse') return true;
      if (parseFloat(cs.fontSize) === 0) return true;
    }
    return false;
  }
  function background(el) {
    for (var e = el; e && e.nodeType === 1; e = e.parentElement) {
      var cs = win.getComputedStyle(e);
      if (cs.filter && cs.filter !== 'none') return null;
      if (/gradient/.test(cs.backgroundImage)) return null;
      var c = parse(cs.backgroundColor);
      if (c && c.a > 0 && c.a < 1) return null;
      if (c && c.a === 1) return c;
    }
    return { r: 255, g: 255, b: 255, a: 1 };
  }
  var seen = new Set();
  function checkEl(el) {
    if (seen.has(el)) return;
    seen.add(el);
    if (hidden(el)) return;
    var cs = win.getComputedStyle(el);
    var size = parseFloat(cs.fontSize);
    if (!size) return;
    var fg = parse(cs.color);
    if (!fg) return;
    // WAVE folds the element's own opacity (not its ancestors') into the text alpha.
    var op = parseFloat(cs.opacity);
    if (!isNaN(op)) fg.a *= op;
    var bg = background(el);
    if (!bg) return;
    if (fg.a < 1) fg = { r: fg.r * fg.a + bg.r * (1 - fg.a), g: fg.g * fg.a + bg.g * (1 - fg.a), b: fg.b * fg.a + bg.b * (1 - fg.a), a: 1 };
    var r = Math.floor(ratio(fg, bg) * 100) / 100;
    var weight = parseInt(cs.fontWeight, 10) || 400;
    var large = size >= 24 || (size >= 18.66 && weight >= 700);
    var need = large ? 3 : 4.5;
    if (r < need) out.contrast.push({ el: el, ratio: r, need: need, fg: cs.color, bg: 'rgb(' + bg.r + ',' + bg.g + ',' + bg.b + ')', size: size, weight: weight });
  }
  var walker = doc.createTreeWalker(doc.body, win.NodeFilter.SHOW_TEXT, null);
  var n;
  while ((n = walker.nextNode())) {
    if (!/[^\s ]/.test(n.nodeValue)) continue;
    var p = n.parentElement;
    if (!p) continue;
    var tag = p.tagName;
    if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT' || tag === 'TEMPLATE' || tag === 'OPTION' || tag === 'TITLE') continue;
    if (p.closest('svg')) continue;
    checkEl(p);
  }
  doc.querySelectorAll('input:not([type=hidden]):not([type=image]):not([type=checkbox]):not([type=radio]), textarea, select').forEach(function (i) {
    var v = i.tagName === 'SELECT' ? (i.options[i.selectedIndex] || {}).text : i.value;
    if (v && /[^\s ]/.test(v)) checkEl(i);
  });
  return out;
};

window.abtDescribe = function (el) {
  if (!el || !el.tagName) return String(el);
  var w = el.closest('[data-widget_type]');
  var e = el.closest('.elementor-element[data-id]');
  var t = el.closest('[data-elementor-id]');
  var tag = el.tagName.toLowerCase();
  var cls = (el.getAttribute('class') || '').split(/\s+/).slice(0, 3).join('.');
  var extra = '';
  if (tag === 'a') extra = ' href=' + (el.getAttribute('href') || '').slice(-50);
  if (tag === 'img') extra = ' src=' + (el.getAttribute('src') || '').split('/').pop().slice(0, 50);
  if (tag === 'input' || tag === 'select' || tag === 'textarea') extra = ' name=' + el.getAttribute('name') + ' id=' + el.id + ' type=' + el.getAttribute('type');
  return (t ? 'tpl' + t.getAttribute('data-elementor-id') : 'noTpl') + '/' + (e ? e.getAttribute('data-id') : '-') + '/' + (w ? w.getAttribute('data-widget_type') : '-') + ' ' + tag + (cls ? '.' + cls : '') + extra + ' "' + (el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 30) + '"';
};

window.abtSummary = function (res) {
  var s = { error: {}, errorTotal: 0, contrast: res.contrast.length };
  for (var k in res.error) { s.error[k] = res.error[k].length; s.errorTotal += res.error[k].length; }
  return s;
};
