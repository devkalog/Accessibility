/*!
 * Aboutnet Accessibility – front-end runtime.
 * Applies accessibility fixes to the rendered page according to the settings saved
 * in WordPress (window.abtA11yConfig). Every pass is idempotent and isolated.
 */
(function (window, document) {
	'use strict';

	if (window.abtA11y && window.abtA11y.version) {
		return;
	}

	var CFG = window.abtA11yConfig || {};
	var VERSION = String(CFG.version || '1.0.0');
	var MOD = CFG.modules || {};
	function on(name) { return MOD[name] !== false; }

	var root = document.documentElement;
	var T = CFG.strings || {};
	function t(key, fallback) { return (T[key] && String(T[key]).trim()) || fallback || ''; }

	var LEVEL_AAA = CFG.contrastLevel === 'AAA';
	var NEED_NORMAL = LEVEL_AAA ? 7 : 4.5;
	var NEED_LARGE = LEVEL_AAA ? 4.5 : 3;
	var MARGIN = typeof CFG.contrastMargin === 'number' ? Math.max(0, Math.min(1, CFG.contrastMargin)) : 0.2;
	var EXCLUDE = Array.isArray(CFG.exclude) ? CFG.exclude.filter(Boolean).join(',') : '';
	var KEEP = Array.isArray(CFG.keep) ? CFG.keep.filter(Boolean).join(',') : '';
	var IMAGE_MODE = CFG.textOverImage === 'recolor' ? 'recolor' : 'keep';
	var A = 'data-abt-a11y';

	var SOCIAL = {
		'facebook.com': 'Facebook', 'fb.com': 'Facebook', 'instagram.com': 'Instagram', 'linkedin.com': 'LinkedIn',
		'youtube.com': 'YouTube', 'youtu.be': 'YouTube', 'tiktok.com': 'TikTok', 'x.com': 'X', 'twitter.com': 'X',
		'pinterest.com': 'Pinterest', 'vimeo.com': 'Vimeo', 'threads.net': 'Threads', 'wa.me': 'WhatsApp',
		'whatsapp.com': 'WhatsApp', 'viber.com': 'Viber', 'maps.google.com': 'Google Maps', 'goo.gl': 'Google Maps',
		'tripadvisor.com': 'Tripadvisor', 'spotify.com': 'Spotify', 'behance.net': 'Behance', 'dribbble.com': 'Dribbble',
		'github.com': 'GitHub', 'telegram.me': 'Telegram', 't.me': 'Telegram', 'messenger.com': 'Messenger'
	};
	var GENERIC_TEXT = /^(περισσότερα|μάθετε περισσότερα|δείτε (περισσότερα|εδώ)|διαβάστε (περισσότερα|εδώ)|εδώ|read more|learn more|more|click here|here|see more|view more|details|λεπτομέρειες|→|»|>)$/i;

	/* ------------------------------------------------------------------ *
	 * Helpers
	 * ------------------------------------------------------------------ */

	function each(list, fn) { for (var i = 0; i < list.length; i++) fn(list[i], i); }
	function q(scope, sel) {
		var out = [];
		if (!scope || !sel) return out;
		if (scope.nodeType === 1 && scope.matches && scope.matches(sel)) out.push(scope);
		each(scope.querySelectorAll(sel), function (n) { out.push(n); });
		return EXCLUDE ? out.filter(function (n) { return !excluded(n); }) : out;
	}
	function excluded(el) {
		if (!EXCLUDE || !el || !el.closest) return false;
		try { return !!el.closest(EXCLUDE); } catch (e) { return false; }
	}
	function clean(s) { return String(s == null ? '' : s).replace(/[\s ]+/g, ' ').trim(); }
	function compact(s) { return String(s == null ? '' : s).replace(/[\s ]+/g, ''); }
	function has(el, a) { return el.hasAttribute(a); }
	function nonEmpty(el, a) { var v = el.getAttribute(a); return v !== null && v.trim() !== ''; }
	function css(el, pseudo) { return window.getComputedStyle(el, pseudo || null); }
	function cap(s) { s = clean(s); return s ? s.charAt(0).toUpperCase() + s.slice(1) : s; }
	function mark(el, what) { el.setAttribute(A, what); }

	function svgNamed(svg) {
		if (nonEmpty(svg, 'aria-label') || has(svg, 'aria-labelledby')) return true;
		for (var i = 0; i < svg.children.length; i++) {
			if (svg.children[i].tagName.toLowerCase() === 'title' && compact(svg.children[i].textContent)) return true;
		}
		return false;
	}
	function hasContent(el) {
		if (compact(el.textContent)) return true;
		var imgs = el.querySelectorAll('img, input[type=image], area');
		for (var i = 0; i < imgs.length; i++) if (nonEmpty(imgs[i], 'alt')) return true;
		var svgs = el.querySelectorAll('svg');
		for (var j = 0; j < svgs.length; j++) if (svgNamed(svgs[j])) return true;
		return false;
	}
	function hasName(el) {
		return hasContent(el) || nonEmpty(el, 'aria-label') || nonEmpty(el, 'aria-labelledby') || nonEmpty(el, 'title');
	}

	function humanize(s) {
		s = String(s || '');
		try { s = decodeURIComponent(s); } catch (e) { /* keep raw */ }
		s = s.replace(/\?.*$/, '').replace(/#.*$/, '');
		s = s.split('/').filter(Boolean).pop() || '';
		s = s.replace(/\.[a-z0-9]{2,5}$/i, '')
			.replace(/-\d+x\d+$/i, '')
			.replace(/-(scaled|min|removebg-preview|copy|e\d{10,})$/i, '')
			.replace(/[-_+]+/g, ' ')
			.replace(/\s\d{1,2}$/, '');
		return cap(s);
	}

	function normUrl(href) {
		if (!href) return '';
		try {
			var u = new URL(href, document.baseURI);
			var path = u.pathname;
			try { path = decodeURI(path); } catch (e) { /* keep */ }
			path = path.replace(/\/+$/, '') || '/';
			var params = [];
			u.searchParams.forEach(function (v, key) { params.push(key + '=' + v); });
			params.sort();
			return (u.host.replace(/^www\./, '') + path + (params.length ? '?' + params.join('&') : '')).toLowerCase();
		} catch (e) {
			return String(href).toLowerCase();
		}
	}

	var LABELS = {};
	(function () {
		var src = CFG.labels || {};
		for (var key in src) {
			if (Object.prototype.hasOwnProperty.call(src, key) && clean(src[key])) LABELS[normUrl(key)] = clean(src[key]);
		}
	})();

	function socialName(host) {
		host = String(host || '').toLowerCase().replace(/^www\./, '');
		for (var d in SOCIAL) {
			if (host === d || host.slice(-(d.length + 1)) === '.' + d) return SOCIAL[d];
		}
		return '';
	}

	// Names that are certain from the address alone (e-mail, phone, known social networks).
	function sureUrlLabel(href) {
		if (!href) return '';
		var low = href.toLowerCase();
		if (low.indexOf('mailto:') === 0) return t('email', 'Email') + ': ' + href.slice(7).split('?')[0];
		if (low.indexOf('tel:') === 0) return t('phone', 'Phone') + ': ' + href.slice(4);
		try { return socialName(new URL(href, document.baseURI).host); } catch (e) { return ''; }
	}

	function labelFromUrl(href) {
		if (!href) return '';
		var key = normUrl(href);
		if (LABELS[key]) return LABELS[key];
		var low = href.toLowerCase();
		if (low.indexOf('mailto:') === 0) return t('email', 'Email') + ': ' + href.slice(7).split('?')[0];
		if (low.indexOf('tel:') === 0) return t('phone', 'Phone') + ': ' + href.slice(4);
		var u;
		try { u = new URL(href, document.baseURI); } catch (e) { return ''; }
		var social = socialName(u.host);
		if (social) return social;
		if (/\.pdf($|\?)/i.test(u.pathname)) return humanize(u.pathname) + ' (PDF)';
		var path = u.pathname.replace(/\/+$/, '');
		var sameSite = u.host === window.location.host;
		if (!path || path === '/' || (sameSite && /^\/[a-z]{2}(-[a-z]{2})?$/i.test(path))) {
			return sameSite ? (CFG.siteName || document.title) : u.host.replace(/^www\./, '');
		}
		var name = humanize(path);
		return sameSite ? name : (name ? name + ' – ' : '') + u.host.replace(/^www\./, '');
	}

	function controlLabel(el) {
		var bits = [
			el.id, el.getAttribute('class'), el.getAttribute('name'), el.getAttribute('data-action'),
			el.getAttribute('aria-controls'), el.parentElement ? el.parentElement.getAttribute('class') : ''
		].join(' ').toLowerCase();
		var svg = el.querySelector('svg, i');
		if (svg) bits += ' ' + String(svg.getAttribute('class') || '').toLowerCase();
		var expanded = el.getAttribute('aria-expanded') === 'true';
		if (/close|dismiss|κλεισ/.test(bits)) return t('close', 'Close');
		if (/search|αναζ|magnif/.test(bits)) return /submit/.test(bits) || el.type === 'submit' ? t('submitSearch', 'Submit search') : t('openSearch', 'Open search');
		if (/pause|play/.test(bits)) return /pause/.test(bits) ? t('pause', 'Pause') : t('play', 'Play');
		if (/swiper-button-prev|slick-prev|slider-prev|carousel-prev|arrow-prev|owl-prev|splide__arrow--prev/.test(bits)) return t('prevSlide', 'Previous slide');
		if (/swiper-button-next|slick-next|slider-next|carousel-next|arrow-next|owl-next|splide__arrow--next/.test(bits)) return t('nextSlide', 'Next slide');
		if (/flex-prev/.test(bits)) return t('prevImage', 'Previous image');
		if (/flex-next/.test(bits)) return t('nextImage', 'Next image');
		if (/(^|[\s_-])(prev|previous|left)([\s_-]|$)/.test(bits)) return t('prev', 'Previous');
		if (/(^|[\s_-])(next|right)([\s_-]|$)/.test(bits)) return t('next', 'Next');
		if (/menu|toggle|hamburger|burger|navbar|nav-/.test(bits)) return expanded ? t('closeMenu', 'Close menu') : t('menu', 'Menu');
		if (/scroll-?top|back-?to-?top|go-?top|to-?top/.test(bits)) return t('backToTop', 'Back to top');
		if (/cart|basket|καλαθ/.test(bits)) return t('cart', 'Cart');
		if (/wishlist|favou?rite/.test(bits)) return t('wishlist', 'Wishlist');
		if (/share/.test(bits)) return t('share', 'Share');
		if (/expand|accordion|collapse/.test(bits)) return t('expand', 'Expand');
		if (/account|user|login|profile/.test(bits)) return t('account', 'Account');
		if (el.type === 'submit' || (el.form && (!el.type || el.type === 'submit'))) return t('submit', 'Submit');
		return '';
	}

	/* ------------------------------------------------------------------ *
	 * Passes
	 * ------------------------------------------------------------------ */

	var LANG_RE = /^[a-zA-Z]{2,3}(-[a-zA-Z0-9]{1,8})*$/;
	function fixLang(scope) {
		if (scope === document.body) {
			var l = root.getAttribute('lang');
			if (!l || !LANG_RE.test(l.trim())) {
				var fixed = String(l || '').replace(/_/g, '-').trim();
				root.setAttribute(A + '-lang', l || '');
				root.setAttribute('lang', LANG_RE.test(fixed) ? fixed : (CFG.lang || 'el'));
			}
		}
		each(q(scope, '[lang]'), function (el) {
			if (el === root) return;
			var v = el.getAttribute('lang');
			if (v === '' || LANG_RE.test(v.trim())) return;
			var fixed2 = v.replace(/_/g, '-').trim();
			el.setAttribute(A + '-lang', v);
			if (LANG_RE.test(fixed2)) el.setAttribute('lang', fixed2); else el.removeAttribute('lang');
		});
	}

	function fixAria(scope) {
		each(q(scope, '[aria-labelledby],[aria-describedby]'), function (el) {
			['aria-labelledby', 'aria-describedby'].forEach(function (attr) {
				if (!el.hasAttribute(attr)) return;
				var ids = el.getAttribute(attr).trim().split(/\s+/).filter(Boolean);
				var ok = ids.filter(function (id) { return !!document.getElementById(id); });
				if (ok.length === ids.length && ids.length) return;
				el.setAttribute(A + '-aria', attr + '=' + el.getAttribute(attr));
				if (ok.length) el.setAttribute(attr, ok.join(' ')); else el.removeAttribute(attr);
			});
		});
		each(q(scope, '[role="menu"]'), function (m) {
			if (!m.querySelector('[role="menuitem"],[role="menuitemcheckbox"],[role="menuitemradio"]')) {
				m.setAttribute('data-abt-role', 'menu');
				m.removeAttribute('role');
			}
		});
	}

	function svgExempt(svg) {
		if (svg.getAttribute('aria-hidden') === 'true') return true;
		if ((svg.getAttribute('role') || '').toLowerCase() === 'presentation') return true;
		if (has(svg, 'aria-label') || has(svg, 'aria-labelledby')) return true;
		for (var i = 0; i < svg.children.length; i++) if (svg.children[i].tagName.toLowerCase() === 'title') return true;
		return false;
	}
	function fixSvgs(scope) {
		each(q(scope, 'svg'), function (svg) {
			if (svgExempt(svg)) return;
			svg.setAttribute('aria-hidden', 'true');
			svg.setAttribute('focusable', 'false');
			mark(svg, 'svg-hidden');
		});
	}

	var ICON_WORDS = [
		[/directions?_car|driving/i, 'car', 'Driving directions'], [/directions?_walk|walking/i, 'walking', 'Walking directions'],
		[/directions?_transit|transit/i, 'transit', 'Transit directions'], [/directions?_bike|bicycl|cycling/i, 'bike', 'Cycling directions']
	];
	function fixImages(scope) {
		each(q(scope, 'img:not([alt])'), function (img) {
			if (img.getAttribute('aria-hidden') === 'true') return;
			var role = (img.getAttribute('role') || '').toLowerCase();
			if (role === 'presentation' || role === 'none') return;
			if (has(img, 'aria-label') || has(img, 'aria-labelledby')) return;
			var src = img.getAttribute('src') || img.getAttribute('data-src') || '';
			for (var i = 0; i < ICON_WORDS.length; i++) {
				if (ICON_WORDS[i][0].test(src)) { img.setAttribute('alt', t(ICON_WORDS[i][1], ICON_WORDS[i][2])); mark(img, 'alt-icon'); return; }
			}
			var ctl = img.closest('a, button, label');
			if (ctl) {
				var clone = ctl.cloneNode(true);
				each(clone.querySelectorAll('img'), function (x) { x.remove(); });
				if (compact(clone.textContent)) { img.setAttribute('alt', ''); mark(img, 'alt-empty'); return; }
			}
			if (nonEmpty(img, 'title')) { img.setAttribute('alt', clean(img.getAttribute('title'))); mark(img, 'alt-title'); return; }
			var fig = img.closest('figure');
			if (fig && fig.querySelector('figcaption') && compact(fig.querySelector('figcaption').textContent)) { img.setAttribute('alt', ''); mark(img, 'alt-empty'); return; }
			var w = img.getAttribute('width'), h = img.getAttribute('height');
			if ((w && parseInt(w, 10) <= 3) || (h && parseInt(h, 10) <= 3) || /(^|\/)(spacer|space|blank|pixel)\./i.test(src)) { img.setAttribute('alt', ''); mark(img, 'alt-empty'); return; }
			if (ctl && ctl.tagName === 'A') { img.setAttribute('alt', ''); mark(img, 'alt-empty'); return; }
			img.setAttribute('alt', humanize(src));
			mark(img, 'alt-filename');
		});
		each(q(scope, 'input[type="image"]'), function (i) {
			if (nonEmpty(i, 'alt')) return;
			i.setAttribute('alt', clean(i.getAttribute('value')) || clean(i.getAttribute('title')) || t('submit', 'Submit'));
			mark(i, 'named');
		});
		each(q(scope, 'area[href]:not([alt])'), function (a) {
			a.setAttribute('alt', clean(a.getAttribute('title')) || labelFromUrl(a.getAttribute('href')));
			mark(a, 'named');
		});
		each(q(scope, 'img[usemap]:not([alt])'), function (img) { img.setAttribute('alt', ''); });
	}

	var twinCache = null;
	function twinText(href) {
		var key = normUrl(href);
		if (!key) return '';
		if (!twinCache) {
			twinCache = {};
			each(document.querySelectorAll('a[href]'), function (a) {
				var tx = clean(a.textContent);
				if (!tx || tx.length > 120 || GENERIC_TEXT.test(tx)) return;
				var k = normUrl(a.getAttribute('href'));
				if (k && !twinCache[k]) twinCache[k] = tx;
			});
		}
		return twinCache[key] || '';
	}
	function isRedundantImageLink(a) {
		if (!a.querySelector('img')) return false;
		var key = normUrl(a.getAttribute('href'));
		var box = a.parentElement;
		for (var depth = 0; box && depth < 5; depth++, box = box.parentElement) {
			var links = box.querySelectorAll('a[href]');
			if (links.length > 6) return false;
			for (var i = 0; i < links.length; i++) {
				if (links[i] !== a && normUrl(links[i].getAttribute('href')) === key && compact(links[i].textContent)) return true;
			}
		}
		return false;
	}
	function bgImageName(el) {
		var nodes = [el].concat(Array.prototype.slice.call(el.querySelectorAll('*'), 0, 20));
		for (var i = 0; i < nodes.length; i++) {
			var m = /url\(["']?([^"')]+)["']?\)/.exec(css(nodes[i]).backgroundImage || '');
			if (m) return humanize(m[1]);
		}
		return '';
	}
	function fixLinks(scope) {
		each(q(scope, 'a[href]'), function (a) {
			if (hasName(a)) return;
			var href = a.getAttribute('href');
			if (isRedundantImageLink(a)) {
				a.setAttribute('aria-hidden', 'true');
				a.setAttribute('tabindex', '-1');
				mark(a, 'duplicate-link');
				each(a.querySelectorAll('img:not([alt])'), function (img) { img.setAttribute('alt', ''); });
				return;
			}
			var label = '', source = 'named';
			var img = a.querySelector('img');
			if (img && nonEmpty(img, 'title')) label = clean(img.getAttribute('title'));
			if (!label) { label = LABELS[normUrl(href)] || ''; if (label) source = 'named-setting'; }
			if (!label && (href === '#' || /^javascript:/i.test(href) || has(a, 'role'))) label = controlLabel(a);
			if (!label) label = twinText(href);
			if (!label && /^#./.test(href)) {
				var target = null;
				try { target = document.getElementById(href.slice(1)); } catch (e) { /* ignore */ }
				var hd = target && (target.matches('h1,h2,h3,h4,h5,h6') ? target : target.querySelector('h1,h2,h3,h4,h5,h6'));
				if (hd) label = clean(hd.textContent);
			}
			if (!label) { label = sureUrlLabel(href); }
			if (!label) { label = labelFromUrl(href); source = 'named-url'; }
			if (!label) { label = controlLabel(a) || bgImageName(a) || t('link', 'Link'); source = 'named-guess'; }
			if (img) {
				img.setAttribute('alt', label);
				each(a.querySelectorAll('img:not([alt])'), function (x) { x.setAttribute('alt', ''); });
			} else {
				a.setAttribute('aria-label', label);
			}
			mark(a, source);
		});
	}

	function fixButtons(scope) {
		each(q(scope, 'button'), function (b) {
			if (hasName(b)) return;
			var label = controlLabel(b);
			if (!label) {
				var id = (b.getAttribute('aria-controls') || '').split(' ')[0];
				var target = id && document.getElementById(id);
				if (target) {
					var h = target.querySelector('h1,h2,h3,h4,h5,h6,legend');
					label = h ? clean(h.textContent) : clean(target.getAttribute('aria-label'));
				}
			}
			b.setAttribute('aria-label', label || t('button', 'Button'));
			mark(b, label ? 'named' : 'named-guess');
		});
		each(q(scope, 'input[type="submit"],input[type="button"],input[type="reset"]'), function (i) {
			if (nonEmpty(i, 'value') || nonEmpty(i, 'aria-label') || nonEmpty(i, 'aria-labelledby') || nonEmpty(i, 'title')) return;
			i.setAttribute('aria-label', i.type === 'reset' ? t('reset', 'Reset') : (controlLabel(i) || t('submit', 'Submit')));
			mark(i, 'named');
		});
	}

	var CONTROL_SEL = 'input:not([type="image"]):not([type="submit"]):not([type="reset"]):not([type="button"]):not([type="hidden"]), textarea, select';
	var uid = 0;
	function labelsFor(c) {
		var list = [];
		if (c.id) each(document.querySelectorAll('label[for]'), function (l) { if (l.getAttribute('for') === c.id) list.push(l); });
		var wrap = c.parentElement ? c.parentElement.closest('label') : null;
		if (wrap && list.indexOf(wrap) < 0 && (!wrap.hasAttribute('for') || wrap.getAttribute('for') === c.id)) list.push(wrap);
		return list;
	}
	function visible(el) { var s = css(el); return s.display !== 'none' && s.visibility !== 'hidden'; }
	function srSpan(text) {
		var s = document.createElement('span');
		s.className = 'abt-a11y-sr';
		s.setAttribute(A, 'label-text');
		s.textContent = text;
		return s;
	}
	function fieldName(c, labels) {
		var tx = '';
		for (var i = 0; i < labels.length && !tx; i++) tx = clean(labels[i].textContent);
		if (!tx) tx = clean(c.getAttribute('placeholder'));
		if (!tx) tx = clean(c.getAttribute('aria-placeholder'));
		if (!tx && c.tagName === 'SELECT' && c.options.length) {
			var first = clean(c.options[0].text);
			if (first && (c.options[0].value === '' || c.options[0].value === '0')) tx = first;
		}
		if (!tx && (c.type === 'search' || c.getAttribute('name') === 's' || (c.form && c.form.getAttribute('role') === 'search'))) tx = t('searchField', 'Search');
		if (!tx) {
			var n = String(c.getAttribute('name') || c.id || '').replace(/^form_fields\[|\]$/g, '').replace(/^field_[0-9a-f]+$/i, '').replace(/\[\]$/, '');
			if (n && !/^\d+$/.test(n)) tx = humanize(n);
		}
		if (!tx) {
			var prev = c.previousElementSibling;
			if (prev && !prev.matches(CONTROL_SEL) && compact(prev.textContent) && clean(prev.textContent).length < 80) tx = clean(prev.textContent);
		}
		return tx || (c.tagName === 'SELECT' ? t('select', 'Select') : t('field', 'Form field'));
	}
	function fixDuplicateIds() {
		var seen = {};
		each(document.querySelectorAll(CONTROL_SEL), function (c) {
			if (!c.id || excluded(c)) return;
			if (!seen[c.id]) { seen[c.id] = c; return; }
			var form = c.closest('form') || c.parentElement;
			var oldId = c.id;
			var newId = oldId + '-abt' + (++uid);
			while (document.getElementById(newId)) newId = oldId + '-abt' + (++uid);
			c.setAttribute(A + '-id', oldId);
			c.id = newId;
			each(form.querySelectorAll('label[for]'), function (l) { if (l.getAttribute('for') === oldId) l.setAttribute('for', newId); });
			each(form.querySelectorAll('[aria-controls],[aria-describedby],[aria-labelledby]'), function (el) {
				['aria-controls', 'aria-describedby', 'aria-labelledby'].forEach(function (a) {
					var v = el.getAttribute(a);
					if (v && (' ' + v + ' ').indexOf(' ' + oldId + ' ') > -1) el.setAttribute(a, (' ' + v + ' ').replace(' ' + oldId + ' ', ' ' + newId + ' ').trim());
				});
			});
		});
	}
	function fixForms(scope) {
		fixDuplicateIds();
		each(q(scope, CONTROL_SEL), function (c) {
			var labels = labelsFor(c);
			if (labels.length > 1) {
				var keep = null;
				labels.forEach(function (l) { if (!keep && hasContent(l) && visible(l)) keep = l; });
				keep = keep || labels[0];
				labels.forEach(function (l) {
					if (l === keep || l.getAttribute('for') !== c.id) return;
					l.setAttribute('data-abt-for', c.id);
					l.removeAttribute('for');
					l.addEventListener('click', function () { try { c.focus(); } catch (e) { /* ignore */ } });
				});
				labels = [keep];
			}
			var name = fieldName(c, labels);
			labels.forEach(function (l) {
				if (!hasContent(l) && !l.querySelector('[' + A + '="label-text"]')) l.appendChild(srSpan(name));
			});
			var named = labels.some(visible) || nonEmpty(c, 'title') || nonEmpty(c, 'aria-labelledby') || nonEmpty(c, 'aria-label');
			if (!named) { c.setAttribute('aria-label', name); mark(c, 'named'); }
		});
		each(q(scope, 'label'), function (l) {
			var ctl = l.getAttribute('for') ? document.getElementById(l.getAttribute('for')) : l.querySelector(CONTROL_SEL);
			if (!ctl || hasContent(l) || l.querySelector('[' + A + '="label-text"]')) return;
			l.appendChild(srSpan(fieldName(ctl, [])));
		});
	}

	function fixHeadings(scope) {
		each(q(scope, 'h1,h2,h3,h4,h5,h6'), function (h) {
			if (hasContent(h) || nonEmpty(h, 'aria-label') || has(h, 'aria-labelledby')) return;
			var div = document.createElement('div');
			for (var i = 0; i < h.attributes.length; i++) div.setAttribute(h.attributes[i].name, h.attributes[i].value);
			div.setAttribute(A, 'empty-' + h.tagName.toLowerCase());
			var cs = css(h);
			div.style.margin = cs.margin;
			div.style.minHeight = cs.height;
			while (h.firstChild) div.appendChild(h.firstChild);
			h.parentNode.replaceChild(div, h);
		});
		each(q(scope, 'th'), function (th) {
			if (hasContent(th) || nonEmpty(th, 'aria-label') || has(th, 'aria-labelledby')) return;
			th.setAttribute('aria-label', t('column', 'Column') + ' ' + (th.cellIndex + 1));
			mark(th, 'named');
		});
	}

	function fixSkipLinks() {
		each(document.querySelectorAll('a[href^="#"]'), function (a) {
			if (!/skip|jump|μετάβαση|παράλειψη/i.test(a.textContent || '')) return;
			var id = a.getAttribute('href').slice(1);
			var target = null;
			try { target = id && (document.getElementById(decodeURIComponent(id)) || document.querySelector('a[name="' + id.replace(/"/g, '') + '"]')); } catch (e) { /* bad id */ }
			if (target) return;
			var main = document.querySelector('main, [role="main"], #content, #main, .site-main, .site-content') ||
				// Elementor full-width templates (Hello Elementor and others): the page's own content.
				document.querySelector('[data-elementor-type="wp-page"], [data-elementor-type="wp-post"], [data-elementor-type="single-page"], [data-elementor-type="single-post"], [data-elementor-type="single"], [data-elementor-type="product"], [data-elementor-type="archive"], [data-elementor-type="product-archive"]');
			if (!main) return;
			if (!main.id) main.id = 'abt-main';
			a.setAttribute(A + '-skip', a.getAttribute('href'));
			a.setAttribute('href', '#' + main.id);
		});
	}

	/* ------------------------------------------------------------------ *
	 * Contrast
	 * ------------------------------------------------------------------ */

	function parseColor(c) {
		var m = /rgba?\(([^)]+)\)/.exec(c || '');
		if (m) {
			var p = m[1].split(/[\s,\/]+/).filter(Boolean).map(parseFloat);
			return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 };
		}
		// Browsers report colours made with color-mix() or relative colours as color(srgb r g b / a), 0–1.
		var sm = /color\(srgb\s+([^)]+)\)/.exec(c || '');
		if (sm) {
			var v = sm[1].split(/[\s\/]+/).filter(Boolean).map(parseFloat);
			return { r: v[0] * 255, g: v[1] * 255, b: v[2] * 255, a: v.length > 3 ? v[3] : 1 };
		}
		var h = /^#?([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(c || '').trim());
		if (!h) return null;
		var s = h[1].length === 3 ? h[1].replace(/(.)/g, '$1$1') : h[1];
		var n = parseInt(s, 16);
		return { r: n >> 16 & 255, g: n >> 8 & 255, b: n & 255, a: 1 };
	}
	function lum(c) {
		function f(v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }
		return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
	}
	function ratio(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
	function toHex(c) {
		function h(v) { v = Math.max(0, Math.min(255, Math.round(v))).toString(16); return v.length < 2 ? '0' + v : v; }
		return '#' + h(c.r) + h(c.g) + h(c.b);
	}
	function blend(fg, bg) {
		if (fg.a >= 1) return fg;
		return { r: fg.r * fg.a + bg.r * (1 - fg.a), g: fg.g * fg.a + bg.g * (1 - fg.a), b: fg.b * fg.a + bg.b * (1 - fg.a), a: 1 };
	}
	function rgbToHsl(c) {
		var r = c.r / 255, g = c.g / 255, b = c.b / 255;
		var max = Math.max(r, g, b), min = Math.min(r, g, b), h = 0, s = 0, l = (max + min) / 2;
		if (max !== min) {
			var d = max - min;
			s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
			h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4;
			h /= 6;
		}
		return { h: h, s: s, l: l };
	}
	function hslToRgb(h, s, l) {
		function hue(p, q2, x) { if (x < 0) x += 1; if (x > 1) x -= 1; if (x < 1 / 6) return p + (q2 - p) * 6 * x; if (x < 1 / 2) return q2; if (x < 2 / 3) return p + (q2 - p) * (2 / 3 - x) * 6; return p; }
		var r, g, b;
		if (s === 0) { r = g = b = l; } else {
			var q2 = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q2;
			r = hue(p, q2, h + 1 / 3); g = hue(p, q2, h); b = hue(p, q2, h - 1 / 3);
		}
		return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255), a: 1 };
	}
	function adjust(fg, bg, need) {
		var hsl = rgbToHsl(fg);
		var darker = lum(bg) > 0.18;
		for (var step = 1; step <= 100; step++) {
			var l = darker ? hsl.l - step / 100 : hsl.l + step / 100;
			if (l < 0 || l > 1) break;
			var c = hslToRgb(hsl.h, hsl.s, l);
			if (ratio(c, bg) >= need) return c;
		}
		return darker ? { r: 0, g: 0, b: 0, a: 1 } : { r: 255, g: 255, b: 255, a: 1 };
	}

	var PALETTE = {};
	each(Array.isArray(CFG.palette) ? CFG.palette : [], function (row) {
		var from = parseColor(row && row.from), to = parseColor(row && row.to);
		if (!from || !to) return;
		var k = toHex(from);
		(PALETTE[k] = PALETTE[k] || []).push(to);
	});
	function preferred(fgHex, bg, need) {
		var list = PALETTE[fgHex];
		if (!list) return null;
		for (var i = 0; i < list.length; i++) if (ratio(list[i], bg) >= need) return list[i];
		return null;
	}

	var hiddenCache = null, bgCache = null;
	function resetCaches() {
		hiddenCache = typeof Map === 'function' ? new Map() : null;
		bgCache = typeof Map === 'function' ? new Map() : null;
	}
	function waveHidden(el) {
		if (!el || el.nodeType !== 1) return false;
		if (hiddenCache && hiddenCache.has(el)) return hiddenCache.get(el);
		var s = css(el);
		var v = s.display === 'none' || s.visibility === 'hidden' || s.visibility === 'collapse' || parseFloat(s.fontSize) === 0 || waveHidden(el.parentElement);
		if (hiddenCache) hiddenCache.set(el, v);
		return v;
	}
	var WHITE = { color: { r: 255, g: 255, b: 255, a: 1 }, el: null };
	function waveBg(el) {
		if (!el || el.nodeType !== 1) return WHITE;
		if (bgCache && bgCache.has(el)) return bgCache.get(el);
		var s = css(el), v;
		var c = parseColor(s.backgroundColor);
		if ((s.filter && s.filter !== 'none') || /gradient/.test(s.backgroundImage) || (c && c.a > 0 && c.a < 1)) v = null;
		else if (c && c.a === 1) v = { color: c, el: el };
		else v = waveBg(el.parentElement);
		if (bgCache) bgCache.set(el, v);
		return v;
	}
	function solidLayer(s) {
		if (!s || parseFloat(s.opacity) < 1) return null;
		if (s.backgroundImage && s.backgroundImage !== 'none') return null;
		var c = parseColor(s.backgroundColor);
		return c && c.a === 1 ? c : null;
	}
	function overlayBg(el, stopAt) {
		for (var e = el; e && e.nodeType === 1; e = e.parentElement) {
			var pick = null;
			['::before', '::after'].forEach(function (p) {
				if (pick) return;
				var s = css(e, p);
				if (!s || s.content === 'none' || s.content === 'normal') return;
				if (s.position !== 'absolute' && s.position !== 'fixed') return;
				pick = solidLayer(s);
			});
			if (!pick) {
				for (var i = 0; i < e.children.length && !pick; i++) {
					var ch = e.children[i];
					if (!ch.classList || !ch.classList.contains('elementor-background-overlay')) continue;
					var cs = css(ch);
					if (cs.position === 'absolute' && cs.display !== 'none') pick = solidLayer(cs);
				}
			}
			if (pick) return { color: pick, el: e };
			if (e === stopAt) break;
		}
		return null;
	}
	function imageHost(el, stopAt) {
		for (var e = el; e && e.nodeType === 1 && e !== stopAt; e = e.parentElement) {
			if (/url\(/.test(css(e).backgroundImage)) return e;
		}
		return null;
	}

	// Photos are often a sibling layer rather than an ancestor of the text: slider slides
	// (Elementor Slides .swiper-slide-bg, WoodMart .wd-slide-bg, Revolution Slider),
	// Elementor background slideshows and videos, an <img> positioned behind a caption.
	// Returns the closest common container of the text and such a layer, plus whether the
	// layer covers that container (only then can a colour go under it without showing).
	function overlap(a, b) {
		var w = Math.min(a.right, b.right) - Math.max(a.left, b.left);
		var h = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
		return w > 0 && h > 0 ? w * h : 0;
	}
	function paintsImage(node) {
		if (node.matches('img, picture, video, canvas, iframe')) return true;
		return /url\(/.test(css(node).backgroundImage);
	}
	function visibleLayer(node) {
		var s = css(node);
		return s.display !== 'none' && s.visibility !== 'hidden' && parseFloat(s.opacity) > 0.1;
	}
	// Lazy-loaded photos are recognised before they load.
	var LAZY_ATTRS = ['data-bg', 'data-background', 'data-background-image', 'data-bg-image', 'data-src', 'data-lazy-src', 'data-srcset', 'data-wood-src'];
	function willPaintImage(node) {
		if (paintsImage(node)) return true;
		for (var k = 0; k < LAZY_ATTRS.length; k++) if (node.hasAttribute(LAZY_ATTRS[k])) return true;
		return false;
	}
	// A layer positioned to fill its container (inset: 0, width/height 100%) that holds a
	// photo. Layout sizes (offsetWidth/Height) are used on purpose: they ignore transforms,
	// so parallax and slide animations in progress do not change the answer.
	function fullPhotoLayer(layer, host) {
		var pos = css(layer).position;
		if (pos !== 'absolute' && pos !== 'fixed') return false;
		var w = layer.offsetWidth, h = layer.offsetHeight;
		if (!w || !h || !host.offsetWidth || !host.offsetHeight) return false;
		if (w < host.offsetWidth * 0.85 || h < host.offsetHeight * 0.85) return false;
		if (willPaintImage(layer)) return true;
		var nodes = layer.querySelectorAll('*');
		for (var i = 0; i < nodes.length && i < 40; i++) {
			var n = nodes[i];
			if (!willPaintImage(n)) continue;
			if (n.tagName === 'SOURCE') return true;
			if (n.offsetWidth >= w * 0.5 && n.offsetHeight >= h * 0.5) return true;
		}
		return false;
	}
	function imageBehind(el, stopAt) {
		var tr = el.getBoundingClientRect();
		var area = tr.width * tr.height;
		if (!area) return null;
		for (var child = el, host = el.parentElement; host && host.nodeType === 1 && host !== document.documentElement; child = host, host = host.parentElement) {
			for (var f = 0; f < host.children.length; f++) {
				var layer = host.children[f];
				if (layer !== child && visibleLayer(layer) && fullPhotoLayer(layer, host)) return { host: host, covers: true };
			}
			for (var i = 0; i < host.children.length; i++) {
				var sib = host.children[i];
				if (sib === child || !visibleLayer(sib) || overlap(sib.getBoundingClientRect(), tr) < area * 0.5) continue;
				var nodes = [sib].concat(Array.prototype.slice.call(sib.querySelectorAll('img, picture, video, canvas, iframe'), 0, 10), Array.prototype.slice.call(sib.querySelectorAll('*'), 0, 30));
				for (var j = 0; j < nodes.length; j++) {
					var n = nodes[j];
					if (!paintsImage(n) || !visibleLayer(n)) continue;
					var nr = n.getBoundingClientRect();
					if (overlap(nr, tr) < area * 0.5) continue;
					var hr = host.getBoundingClientRect();
					var hostArea = hr.width * hr.height;
					return { host: host, covers: !!hostArea && overlap(nr, hr) >= hostArea * 0.85 };
				}
			}
			if (host === stopAt) break;
		}
		return null;
	}
	function photoUnder(el, stopAt) {
		var h = imageHost(el, stopAt);
		if (h) return { host: h, covers: true };
		return imageBehind(el, stopAt);
	}
	function isLarge(s) {
		var size = parseFloat(s.fontSize), weight = parseInt(s.fontWeight, 10) || 400;
		return size >= 24 || (size >= 18.66 && weight >= 700);
	}
	var DARK_FALLBACK = parseColor(CFG.imageFallbackDark || '#1a1a1a') || { r: 26, g: 26, b: 26, a: 1 };
	var LIGHT_FALLBACK = parseColor(CFG.imageFallbackLight || '#ffffff') || { r: 255, g: 255, b: 255, a: 1 };
	function setBg(el, color, why) {
		el.style.setProperty('--abt-a11y-bg', toHex(color));
		el.setAttribute('data-abt-a11y-bg', why || '');
		if (bgCache) bgCache.clear();
	}
	function fallbackFor(fg, need) {
		if (lum(fg) > 0.4) return ratio(fg, DARK_FALLBACK) >= need ? DARK_FALLBACK : { r: 0, g: 0, b: 0, a: 1 };
		return ratio(fg, LIGHT_FALLBACK) >= need ? LIGHT_FALLBACK : { r: 255, g: 255, b: 255, a: 1 };
	}
	function isKept(el) {
		if (!KEEP || !el.closest) return false;
		try { return !!el.closest(KEEP); } catch (e) { return false; }
	}
	function applyKeep(scope) {
		if (!KEEP) return;
		var list;
		try { list = q(scope.nodeType === 1 ? scope : document.body, KEEP); } catch (e) { return; }
		each(list, function (el) {
			var fg = parseColor(css(el).color);
			if (!fg) return;
			var photo = photoUnder(el, null);
			if (photo && photo.covers) setBg(photo.host, fallbackFor(fg, NEED_NORMAL + MARGIN), 'keep');
		});
	}

	function contrastOne(el) {
		if (isKept(el) || excluded(el)) return;
		if (el.closest('[' + A + '-u]')) return; // Colour chosen by the administrator.
		if (waveHidden(el)) { rememberHidden(el); return; }
		var s = css(el);
		if (!parseFloat(s.fontSize)) return;
		var op = parseFloat(s.opacity);
		if (!isNaN(op) && op < 0.05) return;
		var fg = parseColor(s.color);
		if (!fg) return;
		var bgInfo = waveBg(el);
		if (!bgInfo) return;
		var bg = bgInfo.color;
		if (!isNaN(op)) fg.a *= op;
		var need = isLarge(s) ? NEED_LARGE : NEED_NORMAL;
		if (Math.floor(ratio(blend(fg, bg), bg) * 100) / 100 >= need) return;

		var why = toHex(bg) + '|' + (Math.floor(ratio(blend(fg, bg), bg) * 100) / 100) + '|' + need;
		// Text over a photo: give the photo's box a solid colour underneath it. If the photo
		// does not cover its box, that colour would show, so the text is left as it is.
		var photo = IMAGE_MODE === 'keep' ? photoUnder(el, bgInfo.el) : null;
		if (photo) {
			if (photo.covers) setBg(photo.host, fallbackFor(blend(fg, bg), need + MARGIN), 'image');
			else el.setAttribute(A + '-why', 'photo-partial|' + why);
			return;
		}
		// Text over an overlay that is drawn by a pseudo-element or overlay div.
		var target = bg;
		var ov = overlayBg(el, bgInfo.el);
		if (ov) {
			setBg(ov.el, ov.color, 'overlay');
			target = ov.color;
			if (ratio(blend(fg, target), target) >= need + MARGIN) return;
		}
		var solid = blend(fg, target);
		var c = preferred(toHex(solid), target, need + MARGIN) || adjust(solid, target, need + MARGIN);
		el.style.setProperty('--abt-a11y-c', toHex(c));
		el.setAttribute('data-abt-a11y-c', toHex(solid));
		el.setAttribute(A + '-why', (ov ? toHex(target) + '|' + (Math.floor(ratio(solid, target) * 100) / 100) + '|' + need : why));
		if (!isNaN(op) && op < 1) el.setAttribute('data-abt-a11y-op', '');
	}

	function textElements(scope) {
		var list = [];
		var seen = typeof Set === 'function' ? new Set() : null;
		var start = scope.nodeType === 1 ? scope : document.body;
		var walker = document.createTreeWalker(start, NodeFilter.SHOW_TEXT, null);
		var n;
		while ((n = walker.nextNode())) {
			if (!/[^\s ]/.test(n.nodeValue)) continue;
			var p = n.parentElement;
			if (!p) continue;
			var tag = p.tagName;
			if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT' || tag === 'TEMPLATE' || tag === 'OPTION' || tag === 'TITLE') continue;
			if (p.closest('svg')) continue;
			if (seen) { if (seen.has(p)) continue; seen.add(p); }
			list.push(p);
		}
		each(q(start, 'input:not([type=hidden]):not([type=image]):not([type=checkbox]):not([type=radio]), textarea, select'), function (i) {
			var v = i.tagName === 'SELECT' ? (i.options[i.selectedIndex] || {}).text : i.value;
			if (v && /[^\s ]/.test(v)) list.push(i);
		});
		return list;
	}

	// Colours are read with CSS transitions switched off. Otherwise a theme that animates
	// link colours (Twenty Twenty, many others) is measured half-way through the animation,
	// and a recheck sees the fix itself fading in or out.
	var freezeStyle = null, frozen = 0;
	function freeze() {
		if (frozen++) return;
		if (!freezeStyle) {
			freezeStyle = document.createElement('style');
			freezeStyle.setAttribute('data-abt-ui', '');
			freezeStyle.textContent = 'html[data-abt-a11y-measure] *,html[data-abt-a11y-measure] *::before,html[data-abt-a11y-measure] *::after{transition:none!important}';
			(document.head || document.documentElement).appendChild(freezeStyle);
		}
		document.documentElement.setAttribute('data-abt-a11y-measure', '');
	}
	function unfreeze() {
		if (--frozen > 0) return;
		frozen = 0;
		document.documentElement.removeAttribute('data-abt-a11y-measure');
	}

	function fixContrast(scope, recheck) {
		freeze();
		try { fixContrastNow(scope, recheck); } finally { unfreeze(); }
	}
	function fixContrastNow(scope, recheck) {
		resetCaches();
		var els = textElements(scope);
		if (recheck) {
			each(q(scope, '[data-abt-a11y-c], [data-abt-a11y-why]'), function (el) { el.removeAttribute('data-abt-a11y-c'); el.removeAttribute('data-abt-a11y-op'); el.removeAttribute('data-abt-a11y-why'); el.style.removeProperty('--abt-a11y-c'); });
			each(q(scope, '[data-abt-a11y-bg]'), function (el) { el.removeAttribute('data-abt-a11y-bg'); el.style.removeProperty('--abt-a11y-bg'); });
			resetCaches();
		}
		applyKeep(scope);
		for (var i = 0; i < els.length; i++) {
			try { contrastOne(els[i]); } catch (e) { /* keep going */ }
		}
		resetCaches();
	}

	/* ------------------------------------------------------------------ *
	 * Pause control for auto-playing carousels (WCAG 2.2.2)
	 * ------------------------------------------------------------------ */

	var ICON_PAUSE = '<svg viewBox="0 0 14 14" aria-hidden="true" focusable="false"><rect x="2" y="1" width="3.5" height="12"/><rect x="8.5" y="1" width="3.5" height="12"/></svg>';
	var ICON_PLAY = '<svg viewBox="0 0 14 14" aria-hidden="true" focusable="false"><path d="M3 1l10 6-10 6z"/></svg>';
	var reduceMotion = !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

	function makePauseButton(host, isPaused, onToggle) {
		if (css(host).position === 'static') host.style.position = 'relative';
		var paused = isPaused;
		var btn = document.createElement('button');
		btn.type = 'button';
		btn.className = 'abt-a11y-pause';
		function render() {
			btn.innerHTML = (paused ? ICON_PLAY : ICON_PAUSE) + '<span class="abt-a11y-sr">' + (paused ? t('play', 'Play slideshow') : t('pause', 'Pause slideshow')) + '</span>';
			btn.setAttribute('aria-pressed', paused ? 'true' : 'false');
		}
		btn.addEventListener('click', function () { paused = !paused; onToggle(paused); render(); });
		render();
		host.appendChild(btn);
		return { isPaused: function () { return paused; } };
	}

	function addPauseButtons() {
		// Swiper (Elementor, many themes)
		each(document.querySelectorAll('.swiper, .swiper-container'), function (container) {
			var sw = container.swiper;
			if (excluded(container) || !sw || sw.destroyed || !sw.autoplay || container.getAttribute('data-abt-pause')) return;
			var enabled = sw.autoplay.running || (sw.params && sw.params.autoplay && sw.params.autoplay.enabled);
			if (!enabled) return;
			if (container.parentElement && container.parentElement.closest('[data-abt-pause]')) return;
			container.setAttribute('data-abt-pause', '1');
			var host = container.closest('.elementor-widget') || container.parentElement;
			var ctl = makePauseButton(host, reduceMotion, function (p) { if (p) sw.autoplay.stop(); else sw.autoplay.start(); });
			function stopSoon() { window.setTimeout(function () { if (ctl.isPaused() && sw.autoplay && sw.autoplay.running) sw.autoplay.stop(); }, 0); }
			sw.on('autoplayStart', function () { if (ctl.isPaused()) stopSoon(); });
			sw.on('autoplayResume', function () { if (ctl.isPaused()) stopSoon(); });
			if (reduceMotion) sw.autoplay.stop();
		});
		// Slick (jQuery)
		if (window.jQuery) {
			var $ = window.jQuery;
			each(document.querySelectorAll('.slick-initialized'), function (el) {
				if (excluded(el) || el.getAttribute('data-abt-pause')) return;
				var inst = $(el).slick && $(el).slick('getSlick');
				if (!inst || !inst.options || !inst.options.autoplay) return;
				el.setAttribute('data-abt-pause', '1');
				makePauseButton(el.parentElement || el, reduceMotion, function (p) { $(el).slick(p ? 'slickPause' : 'slickPlay'); });
				if (reduceMotion) $(el).slick('slickPause');
			});
		}
	}

	/* ------------------------------------------------------------------ *
	 * Orchestration
	 * ------------------------------------------------------------------ */

	// Changes the administrator made with the on-page editor. They run
	// first, so the automatic fixes see those elements as already done.
	var RULES = Array.isArray(CFG.rules) ? CFG.rules : [];
	function applyRules(scope) {
		RULES.forEach(function (r) {
			var list;
			try { list = q(scope, r.sel); } catch (e) { return; }
			each(list, function (el) {
				var tag = el.tagName.toLowerCase();
				if (r.kind === 'name') {
					if (tag === 'svg') { el.removeAttribute('aria-hidden'); el.setAttribute('role', 'img'); }
					el.setAttribute('aria-label', r.value);
				} else if (r.kind === 'alt') {
					var img = tag === 'img' || tag === 'area' || (tag === 'input' && el.type === 'image') ? el : el.querySelector('img');
					if (img) img.setAttribute('alt', r.value);
				} else if (r.kind === 'hide') {
					el.setAttribute('aria-hidden', 'true');
					if (tag === 'img') el.setAttribute('alt', '');
					if (el.matches('a[href], button, input, select, textarea, [tabindex]')) el.setAttribute('tabindex', '-1');
				} else if (r.kind === 'color') {
					el.style.setProperty('--abt-a11y-u', r.value);
					el.setAttribute(A + '-u', r.value);
				} else if (r.kind === 'plate') {
					if (applyPlate(el, r.value)) el.setAttribute(A + '-plate', r.value);
				}
				el.setAttribute(A + '-rule', r.kind);
			});
		});
	}

	// Backing behind text over a photo: "#1a1a1a@0.6" is that colour at 60% opacity, and
	// "#1a1a1a@0.4/8" adds an 8px blur of the photo behind it (glass). A single text gets a
	// thin ring around it; a frame holding several texts gets rounded corners.
	var PLATE_RE = /^(#[0-9a-f]{6})@([01](?:\.\d+)?)(?:\/(\d{1,2}))?$/i;
	function parsePlate(v) {
		var m = PLATE_RE.exec(String(v || '').trim());
		var c = m && parseColor(m[1]);
		return c ? { color: c, alpha: Math.min(1, parseFloat(m[2])), blur: m[3] ? Math.min(40, parseInt(m[3], 10)) : 0 } : null;
	}
	function isTextBox(el) {
		for (var n = el.firstChild; n; n = n.nextSibling) {
			if (n.nodeType === 3 && /[^\s\u00a0]/.test(n.nodeValue)) return true;
			if (n.nodeType === 1 && !/^(inline|inline-block|contents)$/.test(css(n).display)) return false;
		}
		return true;
	}
	function applyPlate(el, value) {
		var p = parsePlate(value);
		if (!p) return false;
		var rgba = 'rgba(' + p.color.r + ',' + p.color.g + ',' + p.color.b + ',' + p.alpha + ')';
		el.style.setProperty('background-color', rgba, 'important');
		if (isTextBox(el)) {
			el.style.setProperty('box-shadow', '0 0 0 .25em ' + rgba, 'important');
			el.style.setProperty('border-radius', '2px', 'important');
		} else if (!parseFloat(css(el).borderTopLeftRadius)) {
			el.style.setProperty('border-radius', '8px', 'important');
		}
		var blur = p.blur ? 'blur(' + p.blur + 'px)' : '';
		['backdrop-filter', '-webkit-backdrop-filter'].forEach(function (k) {
			if (blur) el.style.setProperty(k, blur, 'important'); else el.style.removeProperty(k);
		});
		return true;
	}

	// Text that was hidden when it was checked (entrance animations, tabs, popups) is checked
	// again when it shows. A photo layer that appears later (a background video that starts,
	// a slide that fades in) re-checks the texts above it.
	var hiddenTexts = typeof Set === 'function' ? new Set() : null;
	var revealTimer = null;
	function rememberHidden(el) { if (hiddenTexts && hiddenTexts.size < 400) hiddenTexts.add(el); }
	function checkRevealed() {
		revealTimer = null;
		if (!hiddenTexts || !hiddenTexts.size) return;
		resetCaches();
		var shown = [];
		hiddenTexts.forEach(function (t) {
			if (!t.isConnected) hiddenTexts.delete(t);
			else if (!waveHidden(t)) { hiddenTexts.delete(t); shown.push(t); }
		});
		resetCaches();
		shown.forEach(function (t) { schedule(t); });
	}
	function textScope(node) {
		for (var p = node; p && p.nodeType === 1 && p !== document.body; p = p.parentElement) {
			if (!p.matches('video, audio, img, picture, canvas, iframe') && /[^\s\u00a0]/.test(p.textContent || '')) return p;
		}
		return null;
	}
	function recheckAbove(node) {
		var scope = textScope(node);
		if (scope) scheduleRecheck(scope);
	}

	var PASSES = [
		['rules', applyRules], ['lang', fixLang], ['aria', fixAria], ['svg', fixSvgs], ['images', fixImages],
		['links', fixLinks], ['buttons', fixButtons], ['forms', fixForms], ['headings', fixHeadings]
	];
	var stats = { runs: 0, ms: 0, errors: [] };

	function runAll(scope, recheckContrast) {
		var t0 = window.performance ? performance.now() : 0;
		scope = scope || document.body;
		if (!scope) return;
		twinCache = null;
		for (var i = 0; i < PASSES.length; i++) {
			if (!on(PASSES[i][0])) continue;
			try { PASSES[i][1](scope); } catch (e) { if (stats.errors.length < 20) stats.errors.push(PASSES[i][0] + ': ' + (e && e.message)); }
		}
		if (on('skip')) { try { fixSkipLinks(); } catch (e) { stats.errors.push('skip: ' + e.message); } }
		if (on('contrast')) { try { fixContrast(scope, recheckContrast); } catch (e) { stats.errors.push('contrast: ' + e.message); } }
		if (on('pause')) { try { addPauseButtons(); } catch (e) { stats.errors.push('pause: ' + e.message); } }
		stats.runs++;
		if (window.performance) stats.ms += performance.now() - t0;
	}

	var pending = [], rechecks = [];
	var queued = false;
	function schedule(node) {
		if (node) pending.push(node);
		if (queued) return;
		queued = true;
		window.setTimeout(function () {
			queued = false;
			var nodes = pending.splice(0), again = rechecks.splice(0);
			if (nodes.length > 40 || nodes.indexOf(document.body) > -1) { runAll(document.body, false); nodes = []; }
			nodes.forEach(function (n) {
				if (!n.isConnected) return;
				for (var p = n.parentElement; p; p = p.parentElement) if (nodes.indexOf(p) > -1) return;
				runAll(n, false);
			});
			again.forEach(function (n) {
				if (n.isConnected && on('contrast')) { try { fixContrast(n, true); } catch (e) { /* ignore */ } }
			});
		}, 120);
	}
	function scheduleRecheck(node) {
		if (rechecks.indexOf(node) < 0) rechecks.push(node);
		schedule(null);
	}

	function observe() {
		if (!window.MutationObserver) return;
		new MutationObserver(function (records) {
			for (var i = 0; i < records.length; i++) {
				for (var j = 0; j < records[i].addedNodes.length; j++) {
					var n = records[i].addedNodes[j];
					if (n.nodeType !== 1) continue;
					if (n.classList && (n.classList.contains('abt-a11y-sr') || n.classList.contains('abt-a11y-pause'))) continue;
					if (n.closest && n.closest('[data-abt-ui], #wpadminbar')) continue;
					schedule(n);
				}
			}
		}).observe(document.body, { childList: true, subtree: true });
		new MutationObserver(function () {
			if (hiddenTexts && hiddenTexts.size && !revealTimer) revealTimer = window.setTimeout(checkRevealed, 200);
		}).observe(document.body, { attributes: true, attributeFilter: ['class', 'style', 'hidden'], subtree: true });
	}

	var resizeTimer = null;
	function start() {
		// Permanent mode: the server has fixed the page already. Run once, when the browser
		// is idle after the page has loaded, then only for content added later.
		if (CFG.lazy) {
			var go = function () { runAll(document.body, true); observe(); listen(); };
			var idle = function () {
				if (window.requestIdleCallback) window.requestIdleCallback(go, { timeout: 3000 }); else window.setTimeout(go, 50);
			};
			if (document.readyState === 'complete') idle(); else window.addEventListener('load', idle);
			return;
		}
		runAll(document.body, false);
		observe();
		window.addEventListener('load', function () {
			runAll(document.body, true);
			window.setTimeout(function () { runAll(document.body, true); }, 1500);
		});
		listen();
	}
	function listen() {
		window.addEventListener('resize', function () {
			window.clearTimeout(resizeTimer);
			resizeTimer = window.setTimeout(function () { if (on('contrast')) { try { fixContrast(document.body, true); } catch (e) { /* ignore */ } } }, 300);
		});
		document.addEventListener('animationend', function (e) { if (e.target && e.target.nodeType === 1) schedule(e.target); }, true);
		document.addEventListener('transitionend', function (e) {
			var t = e.target;
			if (!t || t.nodeType !== 1 || e.propertyName !== 'opacity') return;
			if (/[^\s\u00a0]/.test(t.textContent || '')) schedule(t); else recheckAbove(t);
		}, true);
		['playing', 'loadeddata'].forEach(function (type) {
			document.addEventListener(type, function (e) { if (e.target && e.target.nodeType === 1) recheckAbove(e.target); }, true);
		});
		if (window.jQuery) {
			try { window.jQuery(document).on('elementor/popup/show ajaxComplete', function () { schedule(document.body); }); } catch (e) { /* ignore */ }
		}
	}

	window.abtA11y = {
		version: VERSION,
		run: function () { runAll(document.body, true); return stats; },
		stats: stats,
		util: { ratio: ratio, parseColor: parseColor, toHex: toHex, adjust: adjust, blend: blend, lum: lum },
		plate: applyPlate,
		parsePlate: parsePlate,
		setRules: function (rules) { RULES = Array.isArray(rules) ? rules : []; },
		contrastInfo: function (el) {
			freeze();
			try { return contrastInfoNow(el); } finally { unfreeze(); }
		}
	};

	// What the WAVE contrast check sees for one text element (used by the page editor).
	function contrastInfoNow(el) {
		resetCaches();
		var s = css(el), bgInfo = waveBg(el);
		var fg = parseColor(s.color);
		if (!fg) return null;
		var op = parseFloat(s.opacity);
		if (!isNaN(op)) fg.a *= op;
		var large = isLarge(s);
		var out = { fg: fg, large: large, need: large ? NEED_LARGE : NEED_NORMAL, margin: MARGIN, bg: bgInfo ? bgInfo.color : null, bgEl: bgInfo ? bgInfo.el : null };
		out.ratio = out.bg ? Math.floor(ratio(blend(fg, out.bg), out.bg) * 100) / 100 : null;
		out.photo = photoUnder(el, bgInfo ? bgInfo.el : null);
		resetCaches();
		return out;
	}

	if (CFG.enabled === false) return;
	if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})(window, document);
