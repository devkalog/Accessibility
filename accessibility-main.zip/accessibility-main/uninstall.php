<?php
/**
 * Runs when the plugin is deleted from Plugins → Delete (not when it is deactivated).
 *
 * With "remove every trace of the plugin" ticked in the settings, it removes everything the
 * plugin stored in the database. Otherwise the settings stay, for a later reinstall.
 * Either way the page caches are emptied, since cached pages still load the plugin's files,
 * and WordPress then deletes the plugin's folder from the server.
 *
 * Alt texts saved to the Media Library from the page editor stay: they are the site's
 * content now, and removing them would bring the accessibility errors back.
 *
 * @package Aboutnet_A11y
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/includes/cache.php';

/**
 * Cleans one site. Returns whether everything was removed.
 *
 * @return bool
 */
function abt_a11y_uninstall_site() {
	$settings = get_option( 'abt_a11y_settings', array() );
	if ( ! is_array( $settings ) || empty( $settings['delete_data'] ) ) {
		return false;
	}
	delete_option( 'abt_a11y_settings' );
	// Colour fixes stored for the permanent mode: one option for the site, one per page.
	global $wpdb;
	$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( 'abt_a11y_bk_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- the plugin's own options.
	foreach ( (array) $names as $name ) {
		delete_option( $name );
	}
	delete_option( 'abt_a11y_baked_site' );
	delete_option( 'abt_a11y_baked' );
	// WordPress remembers recently deactivated plugins for the Plugins screen.
	$recent = get_option( 'recently_activated', array() );
	if ( is_array( $recent ) && isset( $recent[ WP_UNINSTALL_PLUGIN ] ) ) {
		unset( $recent[ WP_UNINSTALL_PLUGIN ] );
		update_option( 'recently_activated', $recent );
	}
	return true;
}

$abt_a11y_clean = false;
if ( is_multisite() ) {
	foreach ( get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	) as $abt_a11y_site ) {
		switch_to_blog( $abt_a11y_site );
		$abt_a11y_clean = abt_a11y_uninstall_site() || $abt_a11y_clean;
		abt_a11y_purge_page_caches();
		restore_current_blog();
	}
	if ( $abt_a11y_clean ) {
		$abt_a11y_recent = get_site_option( 'recently_activated', array() );
		if ( is_array( $abt_a11y_recent ) && isset( $abt_a11y_recent[ WP_UNINSTALL_PLUGIN ] ) ) {
			unset( $abt_a11y_recent[ WP_UNINSTALL_PLUGIN ] );
			update_site_option( 'recently_activated', $abt_a11y_recent );
		}
	}
} else {
	$abt_a11y_clean = abt_a11y_uninstall_site();
	abt_a11y_purge_page_caches();
}

// The update check also keeps a list of installed plugins.
if ( $abt_a11y_clean ) {
	$abt_a11y_updates = get_site_transient( 'update_plugins' );
	if ( is_object( $abt_a11y_updates ) ) {
		foreach ( array( 'checked', 'response', 'no_update' ) as $abt_a11y_key ) {
			if ( isset( $abt_a11y_updates->$abt_a11y_key ) && is_array( $abt_a11y_updates->$abt_a11y_key ) ) {
				unset( $abt_a11y_updates->{$abt_a11y_key}[ WP_UNINSTALL_PLUGIN ] );
			}
		}
		set_site_transient( 'update_plugins', $abt_a11y_updates );
	}
}
