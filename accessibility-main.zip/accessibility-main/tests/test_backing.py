"""Text over a background video or photo (Elementor-like hero): the runtime keeps the text's
colour, and the page editor measures the real contrast on the photo and offers a backing
behind the text (colour, opacity, glass, text or frame) with a live WAVE status.
Also checks that theme CSS for buttons and inputs does not break the editor panel."""
import re
import sys

from playwright.sync_api import sync_playwright

from common import BASE, OUTPUT, Results, check, login, option, reset_settings

R = Results('backing')
ok = R.ok
reset_settings()

# Typical theme / page builder styles for buttons, inputs and labels.
HOSTILE = """
html body button, html body [type=button] { padding: 12px 30px; min-height: 46px; min-width: 120px; text-transform: uppercase; letter-spacing: 3px; background: #c00; color: #fff; border: 0; border-radius: 0; font-size: 18px; line-height: 2; box-shadow: 0 4px 0 #900; margin: 6px; }
html body input:not([type=checkbox]):not([type=radio]) { height: 48px; padding: 0 20px; border: 2px solid #0a0; background: #ffe; border-radius: 30px; width: 100%; font-size: 18px; }
html body input[type=checkbox], html body input[type=radio] { width: 24px; height: 24px; margin: 0 12px; }
html body label { display: block; font-size: 20px; text-transform: uppercase; margin-bottom: 14px; }
html body legend { font-size: 26px; float: left; }
"""


def live(pg):
    return pg.inner_text('.abt-ed-live').replace('\n', ' ')


def on_photo(pg):
    m = re.search(r'Πάνω στη φωτογραφία:\s*([\d,]+):1', live(pg))
    return float(m.group(1).replace(',', '.')) if m else None


def set_range(pg, sel, value):
    pg.evaluate("([s, v]) => { const r = document.querySelector(s); r.value = v; r.dispatchEvent(new Event('input', { bubbles: true })); }", [sel, str(value)])
    pg.wait_for_timeout(150)


def open_title(pg):
    pg.click('#wp-admin-bar-abt-a11y > .ab-item')
    pg.wait_for_selector('.abt-insp-row, .abt-insp-lead', timeout=8000)
    pg.wait_for_timeout(400)
    pg.click('.t-hero-title', force=True)
    pg.wait_for_selector('.abt-ed-real', timeout=8000)
    pg.wait_for_function("() => document.querySelector('.abt-ed-real').textContent !== ''", timeout=8000)
    pg.wait_for_timeout(800)


def plate_index(pg):
    return pg.evaluate("() => [...document.querySelectorAll('input[name=abt-color]')].findIndex(i => i.closest('label').textContent.includes('φόντο πίσω'))")


with sync_playwright() as p:
    b = p.chromium.launch(); c = b.new_context(viewport={'width': 1440, 'height': 900}); pg = c.new_page()
    errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    login(pg)

    # ---- runtime: the video container appears late, the title is hidden at first ----
    pg.goto(BASE + '/hero-test/', wait_until='load'); pg.wait_for_timeout(5000)
    st = pg.evaluate("() => { const h = document.querySelector('.t-hero-title'); return { color: getComputedStyle(h).color, c: h.getAttribute('data-abt-a11y-c'), host: document.querySelector('.t-hero').getAttribute('data-abt-a11y-bg'), loading: document.querySelector('.elementor-background-video-container').classList.contains('elementor-loading') }; }")
    ok('video plays and the title is shown', not st['loading'], st)
    ok('title over the video keeps its white colour', st['color'] == 'rgb(255, 255, 255)' and not st['c'], st)
    ok('dark colour goes under the video, where it does not show', st['host'] in ('keep', 'image'), st)
    s = check(pg)
    ok('hero page: no WAVE errors', s['errorTotal'] == 0 and s['contrast'] == 0, s['items'][:5])

    # ---- editor: real contrast and the backing controls ----
    open_title(pg)
    t = pg.inner_text('.abt-insp-body')
    ok('status says what the plugin did under the video', 'έβαλε σκούρο χρώμα κάτω από τη φωτογραφία' in t, t[:200])
    keep = pg.inner_text('.abt-ed-real[data-i="0"]')
    m = re.search(r'([\d,]+):1', keep)
    real0 = float(m.group(1).replace(',', '.')) if m else None
    ok('measures the video frame and the overlay, not the colour under the video', real0 is not None and 1.5 < real0 < 6, keep)
    ok('nothing is shown on the page before choosing', not pg.evaluate("() => document.querySelector('.t-hero-title').style.backgroundColor"))
    i = plate_index(pg)
    pg.check('input[name="abt-color"][value="%d"]' % i); pg.wait_for_timeout(300)
    ok('backing controls appear for the backing option', pg.is_visible('.abt-ed-plate') and not pg.is_visible('.abt-ed-palette'))
    ok('live status sits right under the backing controls', pg.evaluate("() => !!document.querySelector('.abt-ed-live-slot .abt-ed-live')"))
    set_range(pg, '#abt-plate-a', 5); r5 = on_photo(pg)
    set_range(pg, '#abt-plate-a', 60); r60 = on_photo(pg)
    ok('opacity changes the measured contrast live', r5 and r60 and r60 > r5, (r5, r60))
    ok('WAVE: no error with a semi-transparent backing', 'χωρίς σφάλμα' in live(pg), live(pg)[:160])
    set_range(pg, '#abt-plate-a', 100)
    ok('at 100% WAVE measures the text on the backing', re.search(r'WAVE:\s*[\d,]+:1', live(pg)) is not None and 'με αδιαφάνεια 100%' in live(pg), live(pg)[:160])
    en = pg.inner_text('.abt-ed-enough')
    m = re.search(r'από (\d+)%', en)
    tick = pg.evaluate("() => (document.querySelector('#abt-plate-ticks option') || {}).value")
    ok('shows from which opacity the text reads on the photo, with a tick on the slider', m is not None and tick == m.group(1), (en, tick))
    pg.click('.abt-ed-enough [data-plate="min"]'); pg.wait_for_timeout(150)
    ok('"Ορισμός" sets the slider to that value', m is not None and pg.input_value('#abt-plate-a') == m.group(1), pg.input_value('#abt-plate-a'))
    set_range(pg, '#abt-plate-a', 40)
    pg.check('input[name="abt-plate-glass"]'); pg.wait_for_timeout(150)
    set_range(pg, '#abt-plate-b', 12)
    ok('glass blurs the video behind the title', pg.evaluate("() => getComputedStyle(document.querySelector('.t-hero-title')).backdropFilter") == 'blur(12px)')
    pg.screenshot(path=str(OUTPUT / 'backing-glass.png'))
    pg.check('input[name="abt-plate-on"][value="1"]'); pg.wait_for_timeout(300)
    st = pg.evaluate("() => ({ frame: getComputedStyle(document.querySelector('.t-copy')).backgroundColor, title: document.querySelector('.t-hero-title').style.backgroundColor })")
    ok('frame option moves the backing to the frame', st['frame'].startswith('rgba(') and not st['title'], st)
    ok('frame: the hardest text is measured', 'χρειάζεται' in live(pg), live(pg)[:200])
    pg.click('[data-act="save"]'); pg.wait_for_timeout(1500)
    rules = option()['rules']
    ok('backing saved as a page rule with opacity and glass', len(rules) == 1 and rules[0]['kind'] == 'plate' and re.match(r'^#[0-9a-f]{6}@0\.4/12$', rules[0]['value']) and rules[0]['scope'] == '/hero-test/', rules)
    pg.reload(wait_until='load'); pg.wait_for_timeout(4500)
    st = pg.evaluate("() => { const s = getComputedStyle(document.querySelector('.t-copy')); return { bg: s.backgroundColor, blur: s.backdropFilter, title: getComputedStyle(document.querySelector('.t-hero-title')).color }; }")
    ok('backing applies after reload', st['bg'] == 'rgba(26, 26, 26, 0.4)' and st['blur'] == 'blur(12px)' and st['title'] == 'rgb(255, 255, 255)', st)
    s = check(pg)
    ok('hero page with the backing: no WAVE errors', s['errorTotal'] == 0 and s['contrast'] == 0, s['items'][:5])

    # ---- theme CSS does not break the panel ----
    pg.add_style_tag(content=HOSTILE)
    open_title(pg)
    pg.check('input[name="abt-color"][value="%d"]' % plate_index(pg)); pg.wait_for_timeout(200)
    sz = pg.evaluate("""() => { const q = s => document.querySelector(s).getBoundingClientRect();
        return { move: Math.round(q('.abt-insp-move').width), title: Math.round(q('.abt-insp-title').width), close: [Math.round(q('.abt-insp-close').width), Math.round(q('.abt-insp-close').height)],
            radio: Math.round(q('input[name=abt-color]').width), palette: getComputedStyle(document.querySelector('.abt-ed-palette')).display,
            upper: getComputedStyle(document.querySelector('.abt-insp-btn')).textTransform }; }""")
    ok('theme button styles do not squeeze the panel header', sz['move'] == 16 and sz['title'] > 100 and sz['close'] == [30, 30], sz)
    ok('theme input and label styles do not leak in', sz['radio'] == 16 and sz['palette'] == 'none' and sz['upper'] == 'none', sz)
    pg.screenshot(path=str(OUTPUT / 'backing-theme-css.png'))
    ok('no JS errors', not errs, errs[:3])
    b.close()
reset_settings()
sys.exit(R.done())
