"""The plugin's own admin screens must pass WAVE (an accessibility tool that fails
accessibility would be awkward)."""
import sys

from playwright.sync_api import sync_playwright

from common import BASE, CHECKER, Results, login

R = Results('admin-a11y')

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_context(viewport={'width': 1280, 'height': 1000}).new_page()
    login(pg)
    for url in ['/wp-admin/admin.php?page=abt-a11y', '/wp-admin/admin.php?page=abt-a11y-scan']:
        pg.goto(BASE + url, wait_until='load')
        pg.wait_for_timeout(500)
        if 'scan' in url:
            pg.check('input[name="abt-source"][value="list"]')
            pg.fill('#abt-url-list', BASE + '/a11y-test/')
            pg.click('#abt-scan-start')
            pg.wait_for_function("() => /Ολοκληρώθηκε/.test(document.getElementById('abt-progress-text').textContent)", timeout=120000)
        pg.add_script_tag(content=CHECKER)
        issues = pg.evaluate('''() => { const r = abtCheck(document); const out = []; const wrap = document.querySelector('.wrap');
            for (const k in r.error) r.error[k].forEach(i => { if (wrap.contains(i.el)) out.push(k + ' ' + abtDescribe(i.el)); });
            r.contrast.forEach(c => { if (wrap.contains(c.el)) out.push('contrast ' + abtDescribe(c.el) + ' ' + c.ratio); }); return out; }''')
        R.ok('no WAVE errors on ' + url, not issues, issues[:5])
    b.close()

sys.exit(R.done())
