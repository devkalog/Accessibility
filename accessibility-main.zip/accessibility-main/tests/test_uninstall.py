"""Deleting the plugin. With «Να σβήνεται κάθε ίχνος του plugin» unticked the settings stay
for a reinstall; ticked, nothing of the plugin is left in the database. Page caches are
emptied on activation, deactivation and deletion.

Uses `wp plugin uninstall --skip-delete`: it runs uninstall.php like Plugins → Delete does,
but never deletes the plugin's files (in a dev setup they are often a symlink to this repo).
"""
import json
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

from common import BASE, Results, login, option, reset_settings, wp

R = Results('uninstall')
ok = R.ok
PLUGIN = 'aboutnet-a11y'
BASENAME = 'aboutnet-a11y/aboutnet-a11y.php'
reset_settings()
wp('plugin', 'activate', PLUGIN)

# A must-use plugin that counts the cache purges the plugin asks for (as LiteSpeed would).
SPY = Path(wp('eval', 'echo WPMU_PLUGIN_DIR;')) / 'abt-test-cache-spy.php'
SPY.parent.mkdir(parents=True, exist_ok=True)
SPY.write_text("<?php\n// Test only (tests/test_uninstall.py).\nadd_action( 'litespeed_purge_all', function () { update_option( 'abt_test_purges', (int) get_option( 'abt_test_purges', 0 ) + 1, false ); } );\n", encoding='utf-8')


def purges():
    return int(wp('option', 'get', 'abt_test_purges') or 0)


def set_settings(**changes):
    s = option()
    s.update(changes)
    wp('option', 'update', 'abt_a11y_settings', json.dumps(s, ensure_ascii=False), '--format=json')


def traces():
    """Options, user meta and post meta that mention the plugin."""
    out = wp('eval', '''global $wpdb;
        $o = $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE '%abt%a11y%' OR option_value LIKE '%aboutnet-a11y%' OR option_value LIKE '%abt_a11y%'" );
        $u = $wpdb->get_col( "SELECT meta_key FROM {$wpdb->usermeta} WHERE meta_key LIKE '%abt%a11y%' OR meta_value LIKE '%aboutnet-a11y%' OR meta_value LIKE '%abt_a11y%'" );
        $p = $wpdb->get_col( "SELECT meta_key FROM {$wpdb->postmeta} WHERE meta_key LIKE '%abt%a11y%'" );
        echo wp_json_encode( array_merge( $o, $u, $p ) );''')
    return json.loads(out or '[]')


def seed_wordpress_lists():
    """What WordPress itself keeps about a plugin: recently deactivated, update check."""
    wp('eval', '''update_option( 'recently_activated', array( '%s' => time(), 'hello.php' => time() ) );
        $t = get_site_transient( 'update_plugins' ); if ( ! is_object( $t ) ) { $t = new stdClass(); }
        $t->checked = array( '%s' => '1.6.0', 'hello.php' => '1.7.2' ); set_site_transient( 'update_plugins', $t );''' % (BASENAME, BASENAME))


try:
    # ---- the setting ----
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={'width': 1300, 'height': 900})
        login(pg)
        pg.goto(BASE + '/wp-admin/admin.php?page=abt-a11y', wait_until='load')
        box = 'input[type="checkbox"][name="abt_a11y_settings[delete_data]"]'
        ok('setting is in Γενικά and off by default', pg.locator('#abt-general ' + box).count() == 1 and not pg.is_checked(box))
        ok('help says what stays and what goes', 'Βιβλιοθήκη Πολυμέσων' in pg.inner_text('.abt-row[data-key="delete_data"]'))
        pg.check(box); pg.click('#submit'); pg.wait_for_load_state('load')
        ok('ticking it saves', option().get('delete_data') is True, option().get('delete_data'))
        pg.uncheck(box); pg.click('#submit'); pg.wait_for_load_state('load')
        ok('unticking it saves', option().get('delete_data') is False, option().get('delete_data'))
        b.close()

    # ---- caches ----
    wp('option', 'update', 'abt_test_purges', '0')
    wp('plugin', 'deactivate', PLUGIN)
    ok('deactivation empties the page caches', purges() == 1, purges())
    wp('plugin', 'activate', PLUGIN)
    ok('activation empties the page caches', purges() == 2, purges())

    # ---- delete, unticked: settings stay ----
    set_settings(delete_data=False, rules=[{'sel': 'h1', 'kind': 'color', 'value': '#000000', 'scope': 'site', 'label': 'Δοκιμή'}])
    seed_wordpress_lists()
    out = wp('plugin', 'uninstall', PLUGIN, '--deactivate', '--skip-delete')
    ok('uninstall runs', 'Success' in out or 'Uninstalled' in out, out)
    s = option()
    ok('unticked: settings and page changes stay for a reinstall', s.get('rules') and s['rules'][0]['sel'] == 'h1', s.get('rules'))
    ok('deleting empties the page caches', purges() == 4, purges())  # deactivate + uninstall

    # ---- delete, ticked: nothing left ----
    wp('plugin', 'activate', PLUGIN)
    set_settings(delete_data=True)
    seed_wordpress_lists()
    wp('plugin', 'uninstall', PLUGIN, '--deactivate', '--skip-delete')
    ok('ticked: settings removed', not option(), option())
    left = [t for t in traces() if t != 'abt_test_purges']
    ok('ticked: no trace of the plugin in the database', not left, left)
    rest = json.loads(wp('eval', "echo wp_json_encode( array( array_keys( (array) get_option( 'recently_activated' ) ), array_keys( (array) get_site_transient( 'update_plugins' )->checked ) ) );") or '[[],[]]')
    ok('other plugins stay in WordPress lists', rest == [['hello.php'], ['hello.php']], rest)
finally:
    SPY.unlink(missing_ok=True)
    wp('option', 'delete', 'abt_test_purges')
    wp('option', 'delete', 'recently_activated')
    wp('plugin', 'activate', PLUGIN)
    reset_settings()

ok('plugin active again after the test', 'active' == wp('plugin', 'get', PLUGIN, '--field=status'))
sys.exit(R.done())
