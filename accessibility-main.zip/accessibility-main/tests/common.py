"""Shared settings for the end-to-end tests.

Everything that depends on the local test site comes from environment variables,
so the same tests run on any machine:

    ABT_BASE         URL of the test site            (default http://127.0.0.1:8080)
    ABT_WP_CLI       command that runs WP-CLI         (default "wp")
    ABT_ADMIN_USER   administrator user name          (default admin)
    ABT_ADMIN_PASS   administrator password           (default Test-Pass-123)
    ABT_DEBUG_LOG    path of WordPress debug.log      (optional)
"""
import json
import os
import shlex
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT / 'tests'
FIXTURES = TESTS / 'fixtures'
OUTPUT = TESTS / 'output'
OUTPUT.mkdir(exist_ok=True)

BASE = os.environ.get('ABT_BASE', 'http://127.0.0.1:8080').rstrip('/')
WP = shlex.split(os.environ.get('ABT_WP_CLI', 'wp'))
ADMIN_USER = os.environ.get('ABT_ADMIN_USER', 'admin')
ADMIN_PASS = os.environ.get('ABT_ADMIN_PASS', 'Test-Pass-123')
DEBUG_LOG = os.environ.get('ABT_DEBUG_LOG', '')
CHECKER = (ROOT / 'assets' / 'checker.js').read_text(encoding='utf-8')


def wp(*args):
    """Run WP-CLI and return its output."""
    return subprocess.run(WP + list(args), capture_output=True, text=True).stdout.strip()


def option():
    out = wp('option', 'get', 'abt_a11y_settings', '--format=json')
    return json.loads(out) if out else {}


def reset_settings():
    wp('option', 'delete', 'abt_a11y_settings')


def site():
    """Details written by setup_site.py (post URL, media id)."""
    path = OUTPUT / 'site.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}


def login(page):
    page.goto(BASE + '/wp-login.php')
    page.fill('#user_login', ADMIN_USER)
    page.fill('#user_pass', ADMIN_PASS)
    page.click('#wp-submit')
    page.wait_for_load_state('load')


def check(page, finish_animations=True):
    """Run the WAVE-calibrated checker in the page and return a summary."""
    if finish_animations:
        page.evaluate('() => { try { document.getAnimations().forEach(a => { const t = a.effect && a.effect.getComputedTiming(); if (t && isFinite(t.endTime)) a.finish(); }); } catch (e) {} }')
    page.add_script_tag(content=CHECKER)
    return page.evaluate('''() => { const r = window.abtCheck(document); const s = window.abtSummary(r);
        s.items = []; for (const k in r.error) r.error[k].forEach(i => s.items.push(k + ' ' + window.abtDescribe(i.el)));
        r.contrast.forEach(c => s.items.push('contrast ' + window.abtDescribe(c.el) + ' ' + c.fg + '/' + c.bg + ' ' + c.ratio)); return s; }''')


class Results:
    """Tiny PASS/FAIL collector so each script prints a readable report."""

    def __init__(self, name):
        self.name = name
        self.items = []

    def ok(self, label, cond, extra=''):
        self.items.append(bool(cond))
        print(('PASS ' if cond else 'FAIL ') + label + (' :: ' + str(extra) if extra != '' else ''))

    def done(self):
        passed = sum(self.items)
        print('\n%s: %d passed, %d failed' % (self.name, passed, len(self.items) - passed))
        return 0 if passed == len(self.items) else 1
