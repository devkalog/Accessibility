"""«Επεξεργασία στη σελίδα»: marks, element editors, saving rules, Media Library alt,
link labels, removing a change, and the dashboard list of page changes."""
import sys

from playwright.sync_api import sync_playwright

from common import BASE, CHECKER, OUTPUT, Results, check, login, option, reset_settings, site, wp

R = Results('page-editor')
ok = R.ok
MID = str(site().get('media_id', ''))
reset_settings()
if MID:
    wp('post', 'meta', 'delete', MID, '_wp_attachment_image_alt')


def open_panel(pg):
    pg.click('#wp-admin-bar-abt-a11y > .ab-item')
    pg.wait_for_selector('.abt-insp-row, .abt-insp-lead >> text=σφάλμα', timeout=8000)
    pg.wait_for_timeout(300)


def body(pg):
    return pg.inner_text('.abt-insp-body').replace('\n', ' / ')


with sync_playwright() as p:
    b=p.chromium.launch(); c=b.new_context(viewport={'width':1440,'height':900}); pg=c.new_page()
    errs=[]; pg.on('pageerror', lambda e: errs.append(str(e)))
    login(pg)

    # ---- remaining error on the slider page ----
    pg.goto(BASE+'/slider-test/', wait_until='load'); pg.wait_for_timeout(2600)
    badge = pg.locator('#wp-admin-bar-abt-a11y .abt-ab-count')
    ok('admin bar shows remaining errors in red', badge.inner_text() == '1' and 'is-error' in badge.get_attribute('class'), (badge.inner_text(), badge.get_attribute('class')))
    open_panel(pg)
    ok('list starts with "Σφάλματα που μένουν"', 'Σφάλματα που μένουν' in body(pg), body(pg)[:160])
    pg.screenshot(path=str(OUTPUT / 'editor-list.png'))
    pg.mouse.move(700, 450); pg.wait_for_timeout(200)
    ok('hover shows element box and tag', pg.is_visible('.abt-insp-hover') and pg.is_visible('.abt-insp-tag'), pg.inner_text('.abt-insp-tag') if pg.is_visible('.abt-insp-tag') else '')
    pg.click('.ptext'); pg.wait_for_timeout(300)
    t = body(pg)
    ok('click on text opens the text editor with WAVE error', 'Σφάλμα WAVE' in t and 'Χρώμα κειμένου' in t, t[:200])
    pg.screenshot(path=str(OUTPUT / 'editor-text.png'))
    ok('opening the editor changes nothing on the page', pg.evaluate("() => { const s = document.querySelector('.ptext').style; return !s.getPropertyValue('color') && !s.getPropertyValue('background-color'); }"))
    ok('text over a photo: explains WAVE and offers a backing first', 'Το WAVE δεν βλέπει τη φωτογραφία' in t and pg.is_checked('input[name="abt-color"][value="0"]') and 'φόντο πίσω από το κείμενο' in pg.inner_text('.abt-ed-color >> nth=0'))
    pg.check('input[name="abt-color"][value="1"]'); pg.wait_for_timeout(100)
    pg.check('input[name="abt-color"][value="0"]'); pg.wait_for_timeout(100)
    live = pg.inner_text('.abt-ed-live'); print('LIVE:', live)
    ok('preview applies the backing on the page', pg.evaluate("() => document.querySelector('.ptext').style.getPropertyValue('background-color') !== ''"))
    pg.click('[data-act="save"]'); pg.wait_for_timeout(1200)
    ok('saved backing applies without reload, text stays white', pg.evaluate("() => { const e = document.querySelector('.ptext'); return e.hasAttribute('data-abt-a11y-plate') && getComputedStyle(e).color === 'rgb(255, 255, 255)'; }"), body(pg)[:120])
    ok('error count drops to 0', badge.inner_text() != '1' or 'is-error' not in badge.get_attribute('class'), (badge.inner_text(), badge.get_attribute('class')))
    rules = option()['rules']; ok('rule stored for this page', len(rules) == 1 and rules[0]['kind'] == 'plate' and rules[0]['scope'] == '/slider-test/', rules)
    pg.reload(wait_until='load'); pg.wait_for_timeout(2400)
    ok('rule applies on reload', pg.evaluate("() => { const e = document.querySelector('.ptext'); return e.hasAttribute('data-abt-a11y-plate') && getComputedStyle(e).backgroundColor.indexOf('rgba') === 0; }"))
    s = check(pg)
    ok('slider page: no WAVE errors left', s['errorTotal'] == 0 and s['contrast'] == 0, s['items'])

    # ---- media library image ----
    pg.goto(BASE+'/media-test/', wait_until='load'); pg.wait_for_timeout(2400)
    open_panel(pg)
    pg.click('img.wp-image-'+MID); pg.wait_for_timeout(1200)
    t = body(pg); print('IMG EDITOR:', t[:400])
    ok('image editor finds the Media Library item', 'Βιβλιοθήκη Πολυμέσων, ώστε' in t)
    pg.fill('#abt-ed-alt', 'Εσωτερικό μουσείου με έργα τέχνης')
    pg.click('[data-act="save"]'); pg.wait_for_timeout(1200)
    ok('alt saved to the Media Library', wp('post','meta','get',MID,'_wp_attachment_image_alt') == 'Εσωτερικό μουσείου με έργα τέχνης')
    ok('alt applied live', pg.get_attribute('img.wp-image-'+MID, 'alt') == 'Εσωτερικό μουσείου με έργα τέχνης')
    # icon
    pg.click('.abt-insp-back'); pg.wait_for_timeout(200)
    pg.click('svg.t-icon', force=True); pg.wait_for_timeout(300)
    ok('icon editor opens', 'Τι είναι το εικονίδιο' in body(pg), body(pg)[:150])
    pg.check('input[name="abt-icon"][value="name"]'); pg.fill('#abt-ed-name', 'Τετράγωνο σήμα'); pg.click('[data-act="save"]'); pg.wait_for_timeout(1200)
    ok('icon now has a name', pg.get_attribute('svg.t-icon','aria-label') == 'Τετράγωνο σήμα' and pg.get_attribute('svg.t-icon','role') == 'img')

    # ---- a11y test page: button, link, image, unrule ----
    pg.goto(BASE+'/a11y-test/', wait_until='load'); pg.wait_for_timeout(2400)
    open_panel(pg)
    pg.click('.menu-toggle'); pg.wait_for_timeout(300)
    ok('button editor with suggestions', 'Τι κάνει το κουμπί' in body(pg) and pg.locator('.abt-ed-chip').count() > 2)
    pg.fill('#abt-ed-name', 'Άνοιγμα μενού'); pg.click('[data-act="save"]'); pg.wait_for_timeout(1200)
    ok('button renamed live', pg.get_attribute('.menu-toggle','aria-label') == 'Άνοιγμα μενού')
    pg.click('.t-noalt'); pg.wait_for_timeout(1200)
    t = body(pg); ok('theme image: no library item, saves via plugin', 'δεν βρέθηκε στη Βιβλιοθήκη' in t, t[:300])
    pg.check('input[name="abt-img"][value="decorative"]'); pg.click('[data-act="save"]'); pg.wait_for_timeout(1200)
    ok('image made decorative', pg.get_attribute('.t-noalt','alt') == '')
    pg.click('.t-bglink', force=True); pg.wait_for_timeout(800)
    t = body(pg); ok('link editor: url scope offered', 'Σε όλους τους συνδέσμους προς αυτή τη διεύθυνση' in t, t[:250])
    pg.fill('#abt-ed-name', 'HD Corner – υπέρταση και διαβήτης'); pg.click('[data-act="save"]')
    pg.wait_for_url('**#abt-a11y-inspect', timeout=10000); pg.wait_for_load_state('load'); pg.wait_for_timeout(2800)
    ok('link label saved and used after reload', pg.get_attribute('.t-bglink','aria-label') == 'HD Corner – υπέρταση και διαβήτης')
    ok('editor re-opens after reload', pg.is_visible('.abt-insp-panel'))
    pg.click('.t-teal'); pg.wait_for_timeout(300)
    pg.check('input[name="abt-color"][value="%d"]' % (pg.locator('input[name="abt-color"]').count()-1))
    pg.evaluate("() => { const p = document.querySelector('.abt-ed-picker'); p.value = '#000000'; p.dispatchEvent(new Event('input', {bubbles:true})); }")
    pg.click('[data-act="save"]'); pg.wait_for_timeout(1200)
    ok('custom colour saved', pg.evaluate("() => getComputedStyle(document.querySelector('.t-teal')).color") == 'rgb(0, 0, 0)')
    pg.click('.abt-insp-back'); pg.wait_for_timeout(200)
    ok('"Δικές σας" group in list', 'Δικές σας αλλαγές' in body(pg))
    pg.click('.t-teal'); pg.wait_for_timeout(300)
    pg.click('[data-act="unrule"]'); pg.wait_for_load_state('load'); pg.wait_for_timeout(2800)
    ok('own change removed', pg.evaluate("() => getComputedStyle(document.querySelector('.t-teal')).color") != 'rgb(0, 0, 0)')
    # page not navigating
    pg.click('.t-teal-link'); pg.wait_for_timeout(300); ok('clicks do not navigate while editing', '/a11y-test/' in pg.url)

    # ---- the panel moves out of the way: drag, resize, dock, collapse, keyboard ----
    def box():
        return pg.evaluate("() => { const p = document.querySelector('.abt-insp-panel'), r = p.getBoundingClientRect(); return {l: Math.round(r.left), t: Math.round(r.top), w: Math.round(r.width), h: Math.round(r.height), r: Math.round(r.right), vw: document.documentElement.clientWidth, cls: p.className}; }")

    def drag_head(x, y, hold=None):
        h = pg.locator('.abt-insp-title').bounding_box()
        pg.mouse.move(h['x'] + 30, h['y'] + 8); pg.mouse.down(); pg.mouse.move(x, y, steps=10)
        seen = hold() if hold else None
        pg.mouse.up(); pg.wait_for_timeout(100)
        return seen

    p0 = box(); ok('panel starts docked on the right', 'is-float' not in p0['cls'] and 'is-left' not in p0['cls'] and p0['r'] == p0['vw'] and p0['w'] == 400, p0)
    h0 = pg.locator('.abt-insp-title').bounding_box()
    drag_head(h0['x'] + 30 - 400, h0['y'] + 8 + 150)
    p1 = box(); ok('dragging the header leaves it floating where dropped', 'is-float' in p1['cls'] and p1['l'] == p0['l'] - 400 and p1['t'] == p0['t'] + 150 and p1['h'] < p0['h'], p1)
    g = pg.locator('.abt-insp-grip').bounding_box()
    pg.mouse.move(g['x'] + 9, g['y'] + 9); pg.mouse.down(); pg.mouse.move(g['x'] + 89, g['y'] - 91, steps=6); pg.mouse.up()
    p2 = box(); ok('the corner resizes the floating panel', p2['w'] == p1['w'] + 80 and p2['h'] == p1['h'] - 100, (p1, p2))
    pg.evaluate("location.hash = 'abt-a11y-inspect'"); pg.reload(wait_until='load'); pg.wait_for_selector('.abt-insp-row', timeout=8000); pg.wait_for_timeout(300)
    p3 = box(); ok('position and size are kept after reload', (p3['l'], p3['t'], p3['w'], p3['h']) == (p2['l'], p2['t'], p2['w'], p2['h']), (p2, p3))
    pg.screenshot(path=str(OUTPUT / 'editor-panel-float.png'))
    pg.click('.abt-insp-min'); pg.wait_for_timeout(100)
    p4 = box(); ok('collapse leaves only the title bar', 'is-min' in p4['cls'] and p4['h'] < 60 and not pg.is_visible('.abt-insp-body') and pg.get_attribute('.abt-insp-min', 'aria-expanded') == 'false', p4)
    pg.click('.t-teal'); pg.wait_for_timeout(300)
    ok('clicking on the page opens it again with the editor', 'is-min' not in box()['cls'] and 'Χρώμα κειμένου' in body(pg))
    cover = "() => { const a = document.querySelector('.abt-insp-panel').getBoundingClientRect(), b = document.querySelector('%s').getBoundingClientRect(); const x = Math.max(0, Math.min(a.right, b.right) - Math.max(a.left, b.left)), y = Math.max(0, Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top)); return x * y / (b.width * b.height); }"
    ok('the panel moves so the edited element stays visible', pg.evaluate(cover % '.t-teal') < 0.5, (box(), pg.evaluate(cover % '.t-teal')))
    seen = drag_head(8, 400, lambda: pg.is_visible('.abt-insp-dock.is-left'))
    p5 = box(); ok('dropping at the left edge docks it on the left', seen and 'is-left' in p5['cls'] and 'is-float' not in p5['cls'] and p5['l'] == 0 and p5['t'] == 32 and not pg.is_visible('.abt-insp-dock'), (seen, p5))
    pg.click('.abt-insp-side'); p6 = box()
    ok('⇆ docks it on the other side', 'is-left' not in p6['cls'] and p6['r'] == p6['vw'], p6)
    g = pg.locator('.abt-insp-grip').bounding_box()
    pg.mouse.move(g['x'] + 4, g['y'] + 300); pg.mouse.down(); pg.mouse.move(g['x'] + 104, g['y'] + 300, steps=6); pg.mouse.up()
    ok('the inner edge resizes the docked panel', box()['w'] == p6['w'] - 100, box())
    pg.evaluate("() => { const a = document.createElement('a'); a.href = '#'; a.id = 'abt-test-right'; a.textContent = 'Δεξιά'; a.style.cssText = 'position:fixed;right:40px;top:300px;z-index:1'; document.body.appendChild(a); abtA11yInspect.edit(a); }")
    ok('editing an element under the docked panel moves it to the other side', 'is-left' in box()['cls'] and pg.evaluate(cover % '#abt-test-right') == 0, box())
    pg.evaluate("document.getElementById('abt-test-right').remove()"); pg.click('.abt-insp-back')
    pg.focus('.abt-insp-move'); pg.keyboard.press('ArrowDown'); pg.keyboard.press('ArrowRight')
    p7 = box(); ok('arrow keys on the move handle move the panel', 'is-float' in p7['cls'] and (p7['l'], p7['t']) == (20, 52), p7)
    pg.set_viewport_size({'width': 600, 'height': 800}); pg.wait_for_timeout(300)
    p8 = box(); ok('small screen: bottom sheet, not floating', 'is-float' not in p8['cls'] and p8['w'] == p8['vw'] and p8['t'] + p8['h'] == 800, p8)
    pg.set_viewport_size({'width': 1440, 'height': 900}); pg.wait_for_timeout(300)
    ok('back on desktop it floats again', 'is-float' in box()['cls'], box())
    # a11y of the panel
    pg.add_script_tag(content=CHECKER)
    r = pg.evaluate("""() => { const r = abtCheck(document); const out = []; const z = [...document.querySelectorAll('[data-abt-ui]')];
        const inZ = el => z.some(x => x.contains(el));
        for (const k in r.error) r.error[k].forEach(i => { if (inZ(i.el)) out.push(k + ' ' + abtDescribe(i.el)); });
        r.contrast.forEach(c => { if (inZ(c.el)) out.push('contrast ' + abtDescribe(c.el) + ' ' + c.ratio); }); return out; }""")
    ok('editor UI has no WAVE errors', not r, r[:5])
    pg.keyboard.press('Escape'); pg.keyboard.press('Escape'); pg.wait_for_timeout(200)
    pg.evaluate("localStorage.removeItem('abt-a11y-panel')")
    ok('Escape closes everything', not pg.is_visible('.abt-insp-panel') and pg.evaluate("() => !document.querySelector('[data-abt-insp]')"))

    # ---- dashboard lists the changes ----
    pg.goto(BASE+'/wp-admin/admin.php?page=abt-a11y#abt-page-changes', wait_until='load')
    n = pg.locator('.abt-rule-row').count(); ok('settings page lists page changes', n >= 4, n)
    pg.screenshot(path=str(OUTPUT / 'editor-dashboard.png'))
    pg.locator('.abt-rule-row .abt-remove-row').first.click(); pg.click('#submit'); pg.wait_for_load_state('load')
    ok('removing a change in the dashboard saves', len(option()['rules']) == n - 1, len(option()['rules']))
    ok('no JS errors', not errs, errs[:3])
    b.close()
reset_settings()
sys.exit(R.done())
