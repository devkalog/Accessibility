"""Text over photos: sliders (Elementor Slides, WoodMart with parallax), background
slideshows, lazy-loaded photos. The text must keep its colour and WAVE must find no
contrast error, except where a photo covers only part of its box."""
import sys

from playwright.sync_api import sync_playwright

from common import BASE, Results, check, reset_settings

R = Results('photo-text')
reset_settings()

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={'width': 1440, 'height': 900})
    errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))

    pg.goto(BASE + '/slider-test/', wait_until='load')
    pg.wait_for_timeout(2500)
    color = lambda s: pg.evaluate('(s) => { const e = document.querySelector(s); return e ? getComputedStyle(e).color : null; }', s)
    R.ok('Elementor Slides heading keeps its colour', color('.elementor-slide-heading') == 'rgb(244, 248, 255)', color('.elementor-slide-heading'))
    R.ok('Elementor Slides description keeps its colour', color('.elementor-slide-description') == 'rgb(244, 248, 255)')
    R.ok('WoodMart slide title stays white', color('.wd-slide .title') == 'rgb(255, 255, 255)')
    R.ok('background slideshow title stays white', color('.t-slideshow-title') == 'rgb(255, 255, 255)')
    bgs = pg.evaluate("() => [...document.querySelectorAll('[data-abt-a11y-bg=\"image\"]')].map(e => e.className.split(' ')[0])")
    R.ok('a dark colour goes under each photo', set(['swiper-slide', 'wd-slide', 'e-con']) <= set(bgs), bgs)
    R.ok('half-covered photo: text left as it is', pg.evaluate("() => (document.querySelector('.ptext').getAttribute('data-abt-a11y-why') || '').indexOf('photo-partial') === 0"))
    s = check(pg)
    R.ok('only the half-covered text remains as a contrast error', s['errorTotal'] == 0 and s['contrast'] == 1 and 'ptext' in s['items'][0], s['items'])

    pg.goto(BASE + '/parallax-test/', wait_until='load')
    pg.wait_for_timeout(2500)
    cols = pg.evaluate("() => [...document.querySelectorAll('.wdp h4, .wdp p.big')].map(e => getComputedStyle(e).color)")
    R.ok('parallax slider titles keep their colour in every slide', cols and all(c == 'rgb(244, 250, 255)' for c in cols), cols)
    R.ok('lazy-loaded photo is recognised', color('.lazy-text') == 'rgb(255, 255, 255)')
    s = check(pg)
    R.ok('parallax page: 0 errors, 0 contrast', s['errorTotal'] == 0 and s['contrast'] == 0, s['items'])
    R.ok('no JS errors', not errs, errs[:3])
    b.close()

sys.exit(R.done())
