"""Creates the test content on a local WordPress site (run once).

Needs: WP-CLI, the plugin active, the Twenty Twenty-Four theme installed (the fixtures
use its images), pretty permalinks (/%postname%/) and an administrator account.
"""
import json
import re
import sys

from common import FIXTURES, OUTPUT, wp

PAGES = [
    ('a11y-test', 'Δοκιμή προσβασιμότητας', 'a11y-test.html'),
    ('slider-test', 'Δοκιμή slider', 'slider-test.html'),
    ('parallax-test', 'Δοκιμή parallax', 'parallax-test.html'),
]


def page(slug, title, html):
    existing = wp('post', 'list', '--post_type=page', '--name=' + slug, '--field=ID')
    for pid in existing.split():
        wp('post', 'delete', pid, '--force')
    path = OUTPUT / ('_' + slug + '.html')
    path.write_text(html, encoding='utf-8')
    return wp('post', 'create', str(path), '--post_type=page', '--post_status=publish', '--post_title=' + title, '--post_name=' + slug, '--porcelain')


def main():
    if 'aboutnet-a11y' not in wp('plugin', 'list', '--status=active', '--field=name').split():
        print('Activate the plugin first: wp plugin activate aboutnet-a11y')
        return 1
    wp('rewrite', 'structure', '/%postname%/')
    wp('rewrite', 'flush')

    term = wp('term', 'list', 'category', '--slug=symplhromata', '--field=term_id')
    if not term:
        term = wp('term', 'create', 'category', 'Συμπληρώματα', '--slug=symplhromata', '--porcelain')
    post_id = wp('post', 'list', '--post_type=post', '--name=arthro-dokimis', '--field=ID')
    if not post_id:
        post_id = wp('post', 'create', '--post_type=post', '--post_status=publish', '--post_title=Άρθρο δοκιμής', '--post_name=arthro-dokimis', '--post_category=' + term, '--porcelain')

    for slug, title, fixture in PAGES:
        page(slug, title, (FIXTURES / fixture).read_text(encoding='utf-8'))

    media_id = wp('media', 'import', str(FIXTURES / 'gallery-photo.jpg'), '--title=Φωτογραφία γκαλερί', '--porcelain')
    media_url = wp('post', 'get', media_id, '--field=guid')
    page('media-test', 'Δοκιμή media', (
        '<!-- wp:html -->\n<p>Σελίδα με εικόνα της βιβλιοθήκης.</p>\n'
        '<img class="wp-image-%s" src="%s" width="300" height="200">\n'
        '<svg class="t-icon" viewBox="0 0 10 10" width="20" height="20"><path d="M0 0h10v10H0z"/></svg>\n'
        '<!-- /wp:html -->\n' % (media_id, media_url)))

    video_id = wp('media', 'import', str(FIXTURES / 'hero-video.webm'), '--title=Βίντεο hero', '--porcelain')
    video_url = wp('post', 'get', video_id, '--field=guid')
    page('hero-test', 'Δοκιμή hero με βίντεο', (FIXTURES / 'hero-test.html').read_text(encoding='utf-8').replace('{{HERO_VIDEO}}', re.sub(r'^https?://[^/]+', '', video_url)))

    info = {'post_url': wp('eval', 'echo get_permalink(%d);' % int(post_id)), 'media_id': media_id}
    (OUTPUT / 'site.json').write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Test content ready:', json.dumps(info, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    sys.exit(main())
