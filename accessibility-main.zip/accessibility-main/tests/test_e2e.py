"""End-to-end test: visitor fixes, settings with suggestions, page scanner, tools."""
import json
import os
import re
import sys

from playwright.sync_api import sync_playwright

from common import BASE, DEBUG_LOG, OUTPUT, Results, check, login, option, reset_settings, site, wp

R = Results('e2e')
ok = R.ok
ENV_NOISE = ('status of 403', 'gravatar')  # avatars may be blocked on a local test site


def ours(errs):
    return [e for e in errs if not any(n in e for n in ENV_NOISE)]


reset_settings()
POST_URL = site().get('post_url') or BASE + '/'

with sync_playwright() as p:
    browser = p.chromium.launch()
    # ---------------- Visitor ----------------
    ctx = browser.new_context(viewport={'width': 1440, 'height': 900})
    page = ctx.new_page()
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' else None)
    page.goto(BASE + '/a11y-test/', wait_until='load')
    page.wait_for_timeout(2500)
    after = check(page)
    ok('visitor: 0 WAVE errors on test page', after['errorTotal'] == 0, after['items'][:10])
    ok('visitor: 0 contrast errors on test page', after['contrast'] == 0, after['items'][:10])
    ok('visitor: no JS errors', not ours(errors), ours(errors)[:5])
    st = page.evaluate('''() => ({
        cardTitle: getComputedStyle(document.querySelector('.t-card-title')).color,
        cardBg: getComputedStyle(document.querySelector('.t-card')).backgroundColor,
        teal: getComputedStyle(document.querySelector('.t-teal')).color,
        overlayBg: getComputedStyle(document.querySelector('.t-overlay')).backgroundColor,
        overlayLink: getComputedStyle(document.querySelector('.t-overlay-link')).color,
        fb: document.querySelector('.t-social a').getAttribute('aria-label'),
        insta: document.querySelectorAll('.t-social a')[1].getAttribute('aria-label'),
        menu: document.querySelector('.menu-toggle').getAttribute('aria-label'),
        search: document.querySelector('.search-toggle').getAttribute('aria-label'),
        imglinkAlt: document.querySelector('.t-imglink img').getAttribute('alt'),
        noalt: document.querySelector('.t-noalt').getAttribute('alt'),
        bglink: document.querySelector('.t-bglink').getAttribute('aria-label'),
        catlink: document.querySelector('.t-catlink').getAttribute('aria-label'),
        mail: document.querySelector('.t-mail').getAttribute('aria-label'),
        dupIds: [...document.querySelectorAll('input[type=email]')].map(i => i.id),
        phone: document.querySelector('input[name=phone_number]').getAttribute('aria-label'),
        skip: document.querySelector('.skip-test').getAttribute('href'),
        emptyH: !!document.querySelector('h2.t-empty-h'),
        lang: document.querySelector('[lang^="el"]:not(html)').getAttribute('lang'),
        stats: window.abtA11y && window.abtA11y.stats,
        strings: (window.abtA11yConfig || {}).strings || {}
    })''')
    print(json.dumps(st, ensure_ascii=False))
    ok('white title on photo stays white', st['cardTitle'] == 'rgb(255, 255, 255)', st['cardTitle'])
    ok('photo card gets dark fallback bg', st['cardBg'] == 'rgb(26, 26, 26)', st['cardBg'])
    ok('teal text recoloured darker', st['teal'] not in ('rgb(24, 152, 150)',), st['teal'])
    ok('overlay colour made explicit, link stays white', st['overlayBg'] == 'rgb(0, 64, 128)' and st['overlayLink'] == 'rgb(255, 255, 255)', st['overlayBg'])
    ok('social icon links named', st['fb'] == 'Facebook' and st['insta'] == 'Instagram')
    ok('icon buttons named', st['menu'] == st['strings'].get('menu') and st['search'] == st['strings'].get('openSearch'), (st['menu'], st['search']))
    ok('linked image named from its destination', bool(st['imglinkAlt']) and 'abstract' not in st['imglinkAlt'].lower(), st['imglinkAlt'])
    ok('category bg link named from term', st['catlink'] == 'Συμπληρώματα', st['catlink'])
    ok('mailto link named', st['mail'] == st['strings'].get('email', 'Email') + ': info@example.test', st['mail'])
    ok('duplicate ids made unique', len(set(st['dupIds'])) == 2, st['dupIds'])
    ok('skip link retargeted', st['skip'] != '#nonexistent-target', st['skip'])
    ok('empty heading demoted', st['emptyH'] is False)
    ok('lang fixed', st['lang'] == 'el-GR', st['lang'])
    ok('runtime ran without internal errors', st['stats'] and not st['stats']['errors'], st['stats'])
    # mobile width
    mpage = browser.new_context(viewport={'width': 390, 'height': 844}).new_page()
    mpage.goto(BASE + '/a11y-test/', wait_until='load'); mpage.wait_for_timeout(2000)
    m = check(mpage)
    ok('visitor mobile: 0 errors, 0 contrast', m['errorTotal'] == 0 and m['contrast'] == 0, m['items'][:6])
    # visitor cannot switch fixes off (kill switch = admins)
    page.goto(BASE + '/a11y-test/?abt-a11y=off', wait_until='load'); page.wait_for_timeout(1500)
    ok('visitor cannot use ?abt-a11y=off', page.evaluate('() => !!window.abtA11y'))

    # ---------------- Admin ----------------
    actx = browser.new_context(viewport={'width': 1440, 'height': 900})
    ap = actx.new_page()
    aerrors = []
    ap.on('pageerror', lambda e: aerrors.append(str(e) + ' ' + (e.stack or '')))
    login(ap)
    ap.goto(BASE + '/a11y-test/?abt-a11y=off&abt-a11y-scan=1', wait_until='load'); ap.wait_for_timeout(1500)
    before = check(ap)
    ok('admin ?abt-a11y=off shows the unfixed page', before['errorTotal'] > 10 and not ap.evaluate('() => !!window.abtA11y'), (before['errorTotal'], before['contrast']))
    ok('scan mode hides the admin bar', ap.evaluate("() => !document.getElementById('wpadminbar')"))
    print('BEFORE', before['errorTotal'], before['contrast'], json.dumps(before['error'], ensure_ascii=False))

    # Settings page
    ap.goto(BASE + '/wp-admin/admin.php?page=abt-a11y', wait_until='load'); ap.wait_for_timeout(800)
    summary = ap.inner_text('.abt-summary-count')
    ok('settings page renders, all compliant by default', re.match(r'^(\d+) από \1$', summary), summary)
    ap.screenshot(path=str(OUTPUT / 'settings-default.png'), full_page=True)
    # make things non-compliant
    ap.uncheck('input[type=checkbox][name="abt_a11y_settings[modules][svg]"]')
    ap.fill('input[name="abt_a11y_settings[contrast_margin]"]', '0.05')
    ap.fill('input[name="abt_a11y_settings[pause_fg]"]', '#333333'); ap.dispatch_event('input[name="abt_a11y_settings[pause_fg]"]', 'change')
    ap.fill('input[name="abt_a11y_settings[pause_size]"]', '20')
    ap.fill('textarea[name="abt_a11y_settings[palette_backgrounds]"]', '#ffffff\n#f2f2f2')
    ap.click('.abt-add-palette')
    rows = ap.locator('.abt-palette-row')
    rows.last.locator('.abt-color-text').nth(1).fill('#20a0a0'); rows.last.locator('.abt-color-text').nth(1).dispatch_event('change')
    ap.wait_for_timeout(400)
    summary2 = ap.inner_text('.abt-summary-count')
    bad = ap.eval_on_selector_all('.abt-badge.is-bad', 'els => els.length')
    sugg = ap.eval_on_selector_all('.abt-suggest:not([hidden]) .abt-suggest-text', 'els => els.map(e => e.textContent)')
    ok('non-compliant values are flagged', bad >= 4, (summary2, bad))
    print('SUGGESTIONS', json.dumps(sugg, ensure_ascii=False))
    ap.screenshot(path=str(OUTPUT / 'settings-flagged.png'), full_page=True)
    ap.click('.abt-apply-all'); ap.wait_for_timeout(400)
    summary3 = ap.inner_text('.abt-summary-count')
    ok('"apply all suggestions" restores compliance', re.match(r'^(\d+) από \1$', summary3), summary3)
    ap.click('#submit'); ap.wait_for_load_state('load'); ap.wait_for_timeout(500)
    saved = option()
    ok('saved: svg module back on', saved['modules']['svg'] is True)
    ok('saved: pause size 36, margin 0.2', saved['pause_size'] == 36 and abs(saved['contrast_margin'] - 0.2) < 1e-9, (saved['pause_size'], saved['contrast_margin']))
    pal = saved['palette']
    ok('saved: palette row fixed to a passing colour', len(pal) == 1 and pal[0]['to'] != '#20a0a0', pal)
    ok('saved: two site backgrounds', saved['palette_backgrounds'] == ['#ffffff', '#f2f2f2'], saved['palette_backgrounds'])
    ok('saved: pause icon colour fixed', saved['pause_fg'] != '#333333', saved['pause_fg'])
    ok('no JS errors on settings page', not ours(aerrors), ours(aerrors)[:3])

    # Scanner
    ap.goto(BASE + '/wp-admin/admin.php?page=abt-a11y-scan', wait_until='load')
    ap.check('input[name="abt-source"][value="list"]')
    ap.fill('#abt-url-list', '\n'.join([BASE + '/a11y-test/', BASE + '/', BASE + '/category/symplhromata/', POST_URL]))
    ap.check('#abt-vp-mobile')
    ap.click('#abt-scan-start')
    ap.wait_for_function("() => /Ολοκληρώθηκε/.test(document.getElementById('abt-progress-text').textContent)", timeout=240000)
    totals = ap.inner_text('#abt-totals')
    rows_txt = ap.eval_on_selector_all('#abt-results tbody tr', 'trs => trs.map(t => [...t.cells].map(c => c.innerText.split("\\n")[0]).join(" | "))')
    print('TOTALS', totals.replace('\n', ' · '))
    print('\n'.join(rows_txt))
    ok('scanner: 8 checks done', len(rows_txt) == 8, len(rows_txt))
    ok('scanner: every page ends at 0 / 0', all(r.split(' | ')[3] == '0 / 0' for r in rows_txt), rows_txt)
    ok('scanner: before-numbers recorded', any(r.split(' | ')[2] not in ('0 / 0', '—') for r in rows_txt))
    sugg_html = ap.inner_text('#abt-suggestions') if ap.is_visible('#abt-suggestions') else ''
    print('SCANNER SUGGESTIONS:', sugg_html[:900].replace('\n', ' / '))
    ap.screenshot(path=str(OUTPUT / 'scanner.png'), full_page=True)
    btn = ap.locator('.abt-add-color').first
    if btn.count():
        frm, to = btn.get_attribute('data-from'), btn.get_attribute('data-to')
        btn.click(); ap.wait_for_timeout(1200)
        saved2 = option()
        ok('scanner: "add colour mapping" saves to settings', any(r['from'] == frm and r['to'] == to for r in saved2['palette']), saved2['palette'])
    ok('scanner: certain names (social, e-mail) are not listed for review', 'facebook.com' not in sugg_html and 'mailto:' not in sugg_html)
    ok('scanner: hdcorner link listed for review', 'hdcorner.gr' in sugg_html)
    lbtn = ap.locator('.abt-add-link[data-url*="hdcorner"]').first
    if lbtn.count():
        inp = ap.locator('#' + lbtn.get_attribute('data-input'))
        inp.fill('HD Corner – υπέρταση και διαβήτης'); lbtn.click(); ap.wait_for_timeout(1200)
        saved3 = option()
        ok('scanner: "save link label" saves to settings', any('υπέρταση' in r['label'] and 'hdcorner' in r['url'] for r in saved3['link_labels']), saved3['link_labels'])
        page.goto(BASE + '/a11y-test/', wait_until='load'); page.wait_for_timeout(1500)
        ok('saved link label used on the front end', page.get_attribute('.t-bglink', 'aria-label') == 'HD Corner – υπέρταση και διαβήτης', page.get_attribute('.t-bglink', 'aria-label'))
    # sample mode URL list
    r = ap.evaluate('''async () => { const fd = new FormData(); fd.append('action','abt_a11y_urls'); fd.append('nonce', abtA11yAdmin.nonce); fd.append('mode','sample'); fd.append('per_type','3');
        const j = await (await fetch(abtA11yAdmin.ajax, {method:'POST', body: fd, credentials:'same-origin'})).json(); return j; }''')
    ok('AJAX URL list (sample)', r.get('success') and len(r['data']) >= 4, [u['type'] + ':' + u['url'] for u in r.get('data', [])][:10])
    # AJAX without nonce is refused
    r2 = ap.evaluate('''async () => { const fd = new FormData(); fd.append('action','abt_a11y_add'); fd.append('type','palette'); fd.append('from','#000000'); fd.append('to','#111111');
        const res = await fetch(abtA11yAdmin.ajax, {method:'POST', body: fd, credentials:'same-origin'}); return res.status + ' ' + (await res.text()).slice(0, 60); }''')
    ok('AJAX without nonce refused', r2.startswith('403'), r2)
    ok('no JS errors in admin', not ours(aerrors), ours(aerrors)[:3])
    # ---- Tools: export / import / reset ----
    ap.goto(BASE + '/wp-admin/admin.php?page=abt-a11y', wait_until='load')
    with ap.expect_download() as dl:
        ap.click('.abt-export')
    exported = json.loads(open(dl.value.path()).read())
    ok('export downloads JSON with settings', exported.get('plugin') == 'aboutnet-a11y' and 'palette' in exported['settings'], list(exported)[:5])
    ap.once('dialog', lambda d: d.accept())
    ap.click('#abt-tools form[action$="admin-post.php"] >> nth=1 >> button[type=submit]')
    ap.wait_for_load_state('load')
    after_reset = option()
    ok('reset restores defaults', after_reset['palette'] == [] and after_reset['link_labels'] == [], (after_reset['palette'], after_reset['link_labels']))
    ok('reset shows a notice', ap.locator('.notice').filter(has_text='επανήλθαν').count() > 0, ap.locator('.notice').all_inner_texts()[:3])
    exported['settings']['modules']['contrast'] = False
    ap.fill('#abt-import-json', json.dumps(exported, ensure_ascii=False))
    ap.click('#abt-tools form[action$="admin-post.php"] >> nth=0 >> button[type=submit]')
    ap.wait_for_load_state('load')
    imp = option()
    ok('import restores the exported settings', len(imp['palette']) == len(exported['settings']['palette']) and imp['modules']['contrast'] is False and any('hdcorner' in r['url'] for r in imp['link_labels']), (imp['palette'], imp['modules']['contrast']))
    ap.fill('#abt-import-json', '{not json')
    ap.click('#abt-tools form[action$="admin-post.php"] >> nth=0 >> button[type=submit]')
    ap.wait_for_load_state('load')
    ok('bad import is rejected with a message', 'import-error' in ap.url, ap.url)
    # module off => that fix does not run
    page.goto(BASE + '/a11y-test/', wait_until='load'); page.wait_for_timeout(1500)
    ok('disabled contrast module leaves colours alone', page.evaluate("() => getComputedStyle(document.querySelector('.t-teal')).color") == 'rgb(24, 152, 150)')
    ok('other modules still run', bool(page.get_attribute('.menu-toggle', 'aria-label')))
    wp('option', 'patch', 'update', 'abt_a11y_settings', 'enabled', '0')
    page.goto(BASE + '/a11y-test/', wait_until='load'); page.wait_for_timeout(1200)
    ok('master switch off: nothing loads', page.evaluate('() => !window.abtA11y && !window.abtA11yConfig'))
    reset_settings()
    browser.close()

if DEBUG_LOG and os.path.exists(DEBUG_LOG):
    mine = [l for l in open(DEBUG_LOG, encoding='utf-8', errors='replace').read().splitlines() if 'aboutnet-a11y' in l]
    ok('no PHP notices/warnings from the plugin', not mine, mine[:5])
sys.exit(R.done())
