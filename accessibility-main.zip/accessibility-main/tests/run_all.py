"""Runs every test script and prints one summary. Exit code 0 only if all pass.

    python tests/setup_site.py   # once, creates the test pages
    python tests/run_all.py
"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SCRIPTS = ['test_e2e.py', 'test_photo_text.py', 'test_page_editor.py', 'test_backing.py', 'test_admin_a11y.py', 'test_uninstall.py']

failed = []
for name in SCRIPTS:
    print('=' * 70 + '\n' + name + '\n' + '=' * 70, flush=True)
    code = subprocess.run([sys.executable, str(HERE / name)], cwd=str(HERE)).returncode
    if code:
        failed.append(name)

print('\n' + ('ΟΛΑ ΠΕΡΑΣΑΝ' if not failed else 'ΑΠΕΤΥΧΑΝ: ' + ', '.join(failed)))
sys.exit(1 if failed else 0)
