=== Aboutnet Accessibility ===
Contributors: aboutnet
Tags: accessibility, a11y, wcag, wave, contrast
Requires at least: 6.3
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.8.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Fixes the accessibility errors WAVE reports (Errors and Contrast Errors) automatically, with settings that suggest what compliance needs, a page checker and an on-page editor in the admin.

== Description ==

It works in one of two modes (Settings → General):

* **Fast:** the fixes are made in the visitor's browser, by a script, on the page as rendered.
* **Permanent:** the fixes are written into the HTML on the server, before the page is sent, so they are there without JavaScript and every checker sees them. Colour fixes are measured by the page checker and stored as a small stylesheet. An optional safety net script, which loads after the page and never delays it, fixes content that other scripts add later.

Either way it does not change posts, pages, templates or the theme, and deactivating it brings the site back exactly as it was.

The admin screens are in Greek. The texts it adds for screen readers come in Greek and English, picked by the language of the page.

What it fixes (each fix can be turned on or off):

* SVG icons without a text alternative.
* Images without alt.
* Links and buttons without a name (social icons, menu, search, slider arrows, banners with a background image).
* Form fields without a label, duplicate ids, labels pointing at two fields.
* Empty headings and empty table header cells.
* Broken ARIA references and empty role="menu" menus.
* Invalid language codes (e.g. el_GR).
* A "skip to content" link that leads nowhere.
* Colour contrast: darkens or lightens only as much as needed, using the shades of your palette where you set them. White titles over photos stay white.
* A pause button on sliders that move on their own (Swiper / Elementor, Slick).
* A visible focus outline for keyboard navigation.

On-page editor (like the Elementor panel): as an administrator, click "Προσβασιμότητα" (Accessibility) in the admin bar on the front end. The number next to it shows the remaining errors (red) or the changes (green). The page shows numbered marks, like WAVE: red for remaining errors, orange for fixes made by estimate that are worth a look, blue for your own changes, green for automatic fixes. Clicking any element opens a panel, which can be moved, resized or collapsed, with the changes that fit the element: image alt text (also saved to the Media Library), link or button name, field label, decorative or named icon, text colour with a live preview and contrast check. For text over a photo or video it measures the real contrast on the photo and offers a backing behind the text (colour, opacity, glass), with a live WAVE status. Every change comes with suggestions and applies here only, to all similar elements or to the whole site. All changes are also listed, and can be removed, under Settings → Changes made on the page.

Settings: every setting shows whether it is compliant and, if not, suggests a value. "Apply all suggestions" sets them all in one go.

Page checker: opens the site's pages in the background, counts errors and contrast errors with WAVE's rules, with and without the fixes, and suggests colour mappings and link names that can be saved with one click.

Multilingual sites: works with WPML, Polylang and TranslatePress. Changes made on a page apply to the same page in every language; names and alt texts apply only to the language they were written in.

== Installation ==

1. Plugins → Add New → Upload Plugin → choose aboutnet-a11y.zip → Install → Activate.
2. Προσβασιμότητα → Ρυθμίσεις (Settings): choose the mode under "Τρόπος λειτουργίας", click "Εφαρμογή όλων των προτάσεων" (apply all suggestions) and "Αποθήκευση" (save).
3. Προσβασιμότητα → Έλεγχος σελίδων (Page checker): "Έναρξη ελέγχου" (start), on desktop and mobile. In permanent mode this also stores the colour fixes; run it on all pages, and again when the design changes. Add the colour mappings and link names it suggests.
4. Confirm a few pages with WAVE itself.

If you have ready settings for the site (a JSON file), paste them under Settings → Tools → Import.

If the old mu-plugin karabinis-a11y-fixes is installed, the plugin applies no fixes (so they do not run twice) and says so in the admin until wp-content/mu-plugins/karabinis-a11y-fixes.php is deleted.

== Frequently Asked Questions ==

= Does it change anything permanently? =

No. In fast mode the fixes are made on the page as it loads; in permanent mode they are written into the page as it is sent. The posts, templates and theme are not changed. The settings are stored in one option (abt_a11y_settings); in permanent mode the colour fixes the page checker measures are stored in one small option per page (abt_a11y_bk_…, not autoloaded) and one for the whole site (abt_a11y_baked_site). When the plugin is deleted, these are removed if "remove every trace of the plugin" is ticked under Settings → General; otherwise they stay for a reinstall. Alt texts you save to the Media Library stay either way.

= Fast or permanent mode? =

Permanent mode, when the site must pass a check that may not run JavaScript, or when an optimisation plugin delays scripts. It adds a few milliseconds on the server per page (about 8 ms for a typical page, measured on PHP 7.4–8.4; nothing when the page comes from the page cache) and loads no script for visitors unless the safety net is on. Colour fixes need the page checker to have measured each page. Fast mode needs no checking run and fixes every page as it is viewed.

= How do I see what a visitor gets without JavaScript? =

In permanent mode, logged in as an administrator, choose "Η σελίδα χωρίς το script του plugin" under Προσβασιμότητα in the admin bar, or add ?abt-a11y-nojs=1 to the address.

= How do I see a page without the fixes? =

Logged in as an administrator, add ?abt-a11y=off to the address.

= Does it cover WAVE's Alerts? =

No. The plugin brings Errors and Contrast Errors to zero. Alerts are things for a person to review and are not violations in themselves.

= Does it work with caching and optimisation plugins? =

Yes. In fast mode, "Εξαίρεση από plugins βελτιστοποίησης" (exclude from optimisation plugins) asks WP Rocket, LiteSpeed Cache, Autoptimize and others not to delay the script. In permanent mode the fixes are in the HTML, which the page cache stores already fixed, and the safety net script may be delayed like any other. The page cache is emptied when the plugin is activated, deactivated or deleted, when its settings are saved and after a page check; clear a server or CDN cache yourself.

= Does it run in page builders? =

Not in their editors and previews (Elementor, Beaver Builder, Divi, Oxygen, Bricks, WPBakery, Thrive, Brizy, Breakdance), the Customizer or the TranslatePress translation editor. It runs on the published pages.

= Can I exclude part of a page? =

Yes, under Εξαιρέσεις (Exclusions), with a CSS selector or a page ID. Excluded parts are not fixed.

== Changelog ==

= 1.8.0 =
* New: two modes under Settings → General. "Γρήγορη" (fast) works as before, in the browser. "Μόνιμη" (permanent) writes the fixes into the HTML on the server, before the page is sent: names for links, buttons and fields, alt texts, SVG icons, ARIA, language, skip link, empty headings, duplicate ids and the changes made in the on-page editor. The page passes WAVE even when no script runs.
* Permanent mode, colours: the page checker measures the colour fixes on each page, desktop and mobile, and stores them as a short stylesheet in the page, with the theme's hover and focus colours kept on links and buttons. It then counts the page as the server sends it, without any plugin script. Colours and backings chosen in the on-page editor are CSS too.
* Permanent mode, safety net (on by default): the script loads with defer, runs once when the browser is idle after the page has loaded and may be delayed by optimisation plugins. It fixes content added later by other scripts (popups, filters, the WooCommerce block checkout), colours on pages not yet checked, and adds the slider pause buttons. Turned off, visitors load no plugin script at all.
* The server only rewrites the tags it fixes; the rest of the page is sent byte for byte as the theme made it. Checked on 12,000 randomly broken pages: the browser reads the same structure before and after. About 8 ms per typical page (150 KB) and 20–35 ms for a very heavy one (400 KB, 500 fixes), on PHP 7.4 to 8.4.
* The admin bar shows "the page without the plugin script" in permanent mode, for administrators.
* The runtime is now minified (runtime.min.js, 31 KB, 11 KB compressed); SCRIPT_DEBUG loads the readable file.
* Fix: Elementor full-width pages (Hello Elementor) — the "skip to content" link now leads to the page content instead of a missing #content.
* Fix: colours given as color(srgb …), as browsers report color-mix() and hover effects (e.g. WooCommerce buttons), were not read, which could produce a contrast error while the pointer was over a button.
* The page cache is now also emptied when the settings are saved and after a page check.
* Checked with WordPress 6.3 to 7.1, PHP 7.4 to 8.4, nine themes, Elementor 4.3 and WooCommerce 11.2, in both modes.

= 1.7.1 =
* Documentation (README, readme.txt) and all code comments are now in English, as is the plugin description. The admin screens stay in Greek.
* Multilingual sites (WPML, Polylang, TranslatePress): a change made on a page now applies to the same page in every language. Names and alt texts are saved with their language and apply only to pages in that language; before, a site-wide name written in Greek also appeared on the English pages. TranslatePress language directories are recognised. Page changes saved by older versions keep working.
* Fix: on themes that animate text colours (WoodMart, Twenty Twenty and many others), the contrast fix was measured half-way through the animation and could disappear a second after the page loaded, so WAVE showed errors on some page loads and none on others. Colours are now read with transitions switched off.
* Fix: a fixed text colour went back to the original while the pointer was over the text. Only links and buttons now show the theme's hover and focus colours.
* The fixes do not run in the TranslatePress translation editor or the Thrive, Brizy and Breakdance editors.
* Checked with WordPress 6.3 to 7.1, PHP 7.4 to 8.4, eight themes and WooCommerce 11.2.
* The tests and the site presets were removed from the repository.

= 1.6.0 =
* New setting under General: "remove every trace of the plugin". When ticked, deleting the plugin from Plugins removes its settings, the changes made on the page and what WordPress keeps about the plugin from the database. When not ticked, the settings stay for a reinstall. Note: until now the settings were always removed on deletion.
* The plugin empties the page cache (WP Rocket, LiteSpeed, W3 Total Cache and others) when it is activated, deactivated or deleted, so visitors see the site with or without it right away.

= 1.5.0 =
* On-page editor, text over a photo or video: two live readings for every option, "WAVE" (whether WAVE reports an error) and "on the photo" (the real contrast, measured on the photo's pixels or the video's frames, with the overlays).
* New "backing behind the text" option, only for text over a photo: colour, opacity slider, glass effect with adjustable blur, behind the text or behind the whole box. It shows from which opacity the text is readable.
* Fix: text with an entrance animation (hidden when it was checked) over an Elementor background video kept a contrast error or changed colour. It is now checked when it appears, and texts are checked again when the video starts.
* The editor panel keeps its look when the theme styles buttons and fields (e.g. WoodMart, Elementor kit).

= 1.4.0 =
* New name: Aboutnet Accessibility (was: Aboutnet Προσβασιμότητα). The aboutnet-a11y folder and the settings stay the same, so the update installs over the previous version.
* First release on Aboutnet's GitLab, with the changes of 1.3.1 and 1.3.2.

= 1.3.2 =
* On-page editor: the panel can be moved. Drag it by its top bar, resize it from its corner or edge, or drop it at the left or right edge to dock it there. "–" collapses it to its title bar. It remembers its position and size.
* When the element being edited is under the panel, the panel moves to the other side.
* Keyboard moving: arrow keys on the move handle.

= 1.3.1 =
* On-page editor, text over a photo: new option "your colour · semi-transparent backing behind the text", with contrast that holds however light the photo is. It is now the first option instead of a darker colour, and the panel explains that WAVE does not see the photo.
* The panel changes nothing on the page until you pick an option.

= 1.3.0 =
* On-page editor: click any element for a panel of changes that fit its kind (image, link, button, field, icon, text), with suggestions and a live preview.
* The marks also show the WAVE errors that remain, not only the fixes. The number in the admin bar turns red when errors remain.
* Image alt text is saved directly to the Media Library.
* New "Changes made on the page" section in the settings, with all the changes made on pages.

= 1.2.0 =
* "What changed on this page" with one click in the admin bar: the number of changes, numbered marks on the page, a list of all changes (including those only screen readers hear) and filters by kind.
* From the list: rename a link, "keep the original colour", "do not fix here".
* The page checker links to "what changed here" for each page.

= 1.1.1 =
* Sliders with parallax or motion (e.g. WoodMart): each slide's photo is recognised at every position of the slider, so all titles keep their colour and no contrast errors remain.
* Lazy-loaded photos are recognised before they load.

= 1.1.0 =
* Text over a photo that is a separate layer (Elementor Slides, background slideshow or video, WoodMart slider, an image behind a caption) now keeps its colour, as with a background photo.
* New: "What changed on this page" in the admin bar, explaining each change, with a "keep the original colour" button.
* The page checker reports the texts over photos that were left as they were.

= 1.0.0 =
* First version: a general plugin built from the karabinismedical.gr fix, with settings that suggest compliant values and a page checker.
