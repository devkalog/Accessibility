<?php
/**
 * Plugin Name:       Aboutnet Accessibility
 * Plugin URI:        https://www.aboutnet.gr/
 * Description:       Fixes common accessibility errors automatically (WCAG 2.1 AA): names for links, buttons and fields, SVG icons, alt text, ARIA, language, colour contrast, slider pause, visible focus. Two modes: fast (in the browser) or permanent (written into the HTML on the server, no JavaScript needed). Settings with compliance suggestions, a page checker that follows WAVE's rules and an on-page editor.
 * Version:           1.8.0
 * Requires at least: 6.3
 * Requires PHP:      7.4
 * Author:            Aboutnet
 * Author URI:        https://www.aboutnet.gr/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       aboutnet-a11y
 *
 * @package Aboutnet_A11y
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'ABT_A11Y_VERSION' ) ) {
	return; // Another copy is already loaded.
}

define( 'ABT_A11Y_VERSION', '1.8.0' );
define( 'ABT_A11Y_FILE', __FILE__ );
define( 'ABT_A11Y_DIR', plugin_dir_path( __FILE__ ) );
define( 'ABT_A11Y_URL', plugin_dir_url( __FILE__ ) );

require_once ABT_A11Y_DIR . 'includes/settings.php';
require_once ABT_A11Y_DIR . 'includes/cache.php';
require_once ABT_A11Y_DIR . 'includes/frontend.php';
require_once ABT_A11Y_DIR . 'includes/static.php';
require_once ABT_A11Y_DIR . 'includes/inspector.php';

if ( is_admin() ) {
	require_once ABT_A11Y_DIR . 'includes/admin.php';
	require_once ABT_A11Y_DIR . 'includes/editor.php';
}

register_activation_hook( __FILE__, 'abt_a11y_activate' );
function abt_a11y_activate() {
	if ( false === get_option( ABT_A11Y_OPTION, false ) ) {
		add_option( ABT_A11Y_OPTION, abt_a11y_defaults(), '', true );
	}
	abt_a11y_purge_page_caches();
}

// Settings change what pages contain (in permanent mode, the HTML itself): cached pages are emptied.
add_action( 'update_option_abt_a11y_settings', 'abt_a11y_purge_page_caches', 10, 0 );

// Deactivating keeps every setting; cached pages are emptied so they stop loading the plugin.
// Deleting the plugin runs uninstall.php.
register_deactivation_hook( __FILE__, 'abt_a11y_purge_page_caches' );
